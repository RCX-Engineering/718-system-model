# Wiring Knowledge Graph

Model electrical wiring as a knowledge graph and view it as an interactive, KiCad-style
schematic. The scope runs from a sensor board to the harness of a whole vehicle.

The graph is the single source of truth. It is an openCypher property graph of parts,
connectors, pins, conductors, splices, nets, buses and configuration options, and it carries its
own metadata and vocabulary. The viewer is a pure interpreter of that graph: it holds no project
knowledge, so any graph that follows the vocabulary draws without code changes.

This folder is also an agent skill. `SKILL.md` gives an AI assistant the complete method for
building, checking and delivering a model with these tools.

## Why a knowledge graph instead of a drawing

A wiring drawing is a picture. It is split into pages, drawn for one purpose, and holds its
connections only as lines that a person has to follow. A knowledge graph holds the connectivity
itself, which gives model-based engineering one authoritative model; every drawing, table and
report is derived from it.

- **Any view on demand:**
  - one system, or several together
  - every bus connection
  - every connection to one unit
  - one net alone
  - any configuration

  Each view is drawn from the same model, so views never disagree.
- **Analysis by query:**
  - what shares this ground or supply
  - what sits on this bus
  - what changes between two configurations
  - what a failed splice affects
- **Machine verification:** every conductor has two ends, every declared net is one connected
  piece, and every term is defined. The checks run on each view in each configuration.
- **Integration and simulation:** the graph converts to RDF and validates against a LinkML
  schema (with SHACL and OWL generated from it), so it can be linked with requirements, parts and
  maintenance data. Its nets and buses are the inputs that circuit, fault and network
  simulations take.

## Quick start

**No build or install is needed to use the viewer.** Open `index.html` in any modern browser. It
is one self-contained file (engine, layout, KiCad symbols and fonts inside it), works offline,
and makes no network requests. It opens on the sensor-node example; load your own model with
**Open graph…** in the Source pane, or drop a `.cypher` file onto the drawing. GitHub Pages can
serve `index.html` as is.

To make a page with your own model embedded, so it opens on that model, or to check and validate
models from the command line:

Requirements:

- Node 18 or later and Python 3. There are no npm dependencies.
- Optional:
  - `rdflib` and `pySHACL`, for RDF validation
  - `PyYAML`, for `tools/schema_terms.py`
  - Playwright with Chromium, for the visual check

```sh
# Once, before the first check or build: fetch the KiCad symbol libraries from their pinned
# upstream commit (needs network access once; viewing pages never does)
python3 tools/fetch_symbols.py

# Check an example in every configuration (must report 0 errors)
node tools/check.js examples/sensor_node.cypher

# Embed a model in its own page: writes out/sensor_node.standalone.html, one self-contained file
python3 tools/build.py examples/sensor_node.cypher "Sensor node" out/sensor_node.html

# Convert to RDF and validate against the schema
node tools/cypher2rdf.js examples/sensor_node.cypher > out/sensor_node.ttl
python3 tools/validate_rdf.py out/sensor_node.ttl schema/wiring_kg.shacl.ttl schema/wiring_kg.owl.ttl

# Engine regression tests (run after any change to src/)
node test/t_verify_mutants.js && node test/t_verify.js && node test/t_variants.js \
  && node test/t_conductors.js && node test/t_vocabulary.js
```

To start a model of your own, copy `examples/sensor_node.cypher`. It exercises every feature and
shows the metadata a model carries. `SKILL.md` documents the vocabulary, the rules and the
workflow.

## Contents

| Path | What it holds |
|---|---|
| `index.html` | The viewer, ready to open: self-contained, with the sensor-node example |
| `src/` | Viewer engine: Cypher reader, scene builder, layout (ELK), KiCad renderer, checks, tables, app, page template, `profile.json` rules |
| `lib/` | `symbols.json`: which KiCad symbols are used and the upstream commit they come from; `tools/fetch_symbols.py` fetches them as `.kicad_sym` files |
| `vendor/` | elkjs (the layout engine) and the IBM Plex fonts |
| `tools/` | Symbol fetch, build, check, visual check, RDF conversion, SHACL validation, vocabulary embedding, KiCad library conversion |
| `schema/` | The vocabulary as a LinkML schema, with generated SHACL shapes and OWL ontology |
| `examples/` | A compact template (sensor node) and a large real model (an RTK GNSS datalogger) |
| `test/` | Engine regression tests |

## Viewer

- Drawing and Tables views.
- Configuration pickers.
- Views by connection class (Power, Ground, Comms, Signals), by system, or by unit.
- Click-to-trace highlighting: wire, then net, then cable, then bus.
- Double-click to show one net or bus alone.
- An inspector with the source line of everything you select.
- A Model pane with the dataset, its sources and methods, and a glossary of every term.
- A live graph editor and live checks.
- Every page is one self-contained HTML file that works offline.

## Licences

- **Software** (the viewer and engine in `src/`, the tools in `tools/`, the tests, and the built
  pages' own code): Apache License 2.0; see `LICENSE`.
- **Documentation** (`README.md`, `SKILL.md`): Creative Commons Attribution 4.0 International
  (CC BY 4.0).
- **Models** carry their own licence in their `Dataset` node (`license`), shown in the viewer and
  in the guide at the top of every built page.

Third-party components keep their own licences, listed in `THIRD_PARTY_NOTICES.md`:

- elkjs, under EPL-2.0
- the IBM Plex fonts, under the SIL Open Font License 1.1
- the KiCad symbol libraries, under CC-BY-SA 4.0 with the KiCad libraries exception (see
  `lib/LICENSE.md`)
