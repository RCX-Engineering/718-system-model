"""Assemble the single-file viewer page.

Embeds, in this order: the graph source verbatim, the rules profile, the KiCad
symbol libraries, the engine modules and the application script. After writing
the page it reads the embedded graph back out and checks it is byte-identical
to the source file.

Usage: python build.py GRAPH.cypher GRAPH_NAME OUT.html
"""

from __future__ import annotations

import html
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "src"
LIB = ROOT / "lib"
ENGINE = ["cypher.js", "kicad.js", "scene.js", "layout.js", "render.js", "verify.js", "tables.js"]
# Every KiCad symbol library in lib/ is embedded; add a library by converting symbols into it.
LIBRARIES = sorted(p.stem for p in LIB.glob("*.kicad_sym"))
# The library's licence travels with every embedded copy: CC-BY-SA 4.0 requires attribution and a
# note of the change made, and the KiCad libraries exception frees drawings made with the symbols.
PROVENANCE = ("KiCad official symbol library (github.com/KiCad/kicad-symbols, commit 4e17d75), "
              "converted from the legacy .lib format to .kicad_sym; "
              "licensed CC-BY-SA-4.0 WITH KiCad-libraries-exception")


# IBM Plex as @font-face rules with the WOFF2 data inline (SIL OFL 1.1, vendor/fonts/LICENSE).
FONT_CSS = ROOT / "vendor" / "fonts" / "ibm-plex.css"
FONT_LINKS = ('<link rel="preconnect" href="https://fonts.googleapis.com">\n'
              '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>\n'
              '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600'
              '&family=IBM+Plex+Sans+Condensed:wght@500;600&family=IBM+Plex+Sans:wght@400;500;600&display=swap">')


def font_faces() -> str:
    return "<style>\n" + guard(FONT_CSS.read_text(encoding="utf-8"), "ibm-plex.css") + "</style>"


def compact_json(value, indent=""):
    inner = indent + "  "
    if isinstance(value, list):
        flat = json.dumps(value, ensure_ascii=False)
        if len(flat) <= 96 and all(not isinstance(v, (dict, list)) for v in value):
            return flat
        return "[\n" + ",\n".join(inner + compact_json(v, inner) for v in value) + "\n" + indent + "]"
    if isinstance(value, dict):
        flat = json.dumps(value, ensure_ascii=False)
        if len(flat) <= 88 and not any(isinstance(v, dict) for v in value.values()):
            return "{ " + ", ".join(f"{json.dumps(k)}: {compact_json(v, inner)}" for k, v in value.items()) + " }"
        return "{\n" + ",\n".join(f"{inner}{json.dumps(k)}: {compact_json(v, inner)}" for k, v in value.items()) + "\n" + indent + "}"
    return json.dumps(value, ensure_ascii=False)


def guard(text: str, what: str) -> str:
    if re.search(r"</script", text, re.I):
        raise SystemExit(f"{what} contains '</script' and cannot be embedded verbatim")
    return text


# The viewer's own licence, and the third-party components every built page carries inline.
VIEWER_LICENSE = ("Apache License 2.0", "https://www.apache.org/licenses/LICENSE-2.0")
THIRD_PARTY = [
    "elkjs 0.12.0, Eclipse Layout Kernel (Kiel University and others, github.com/kieler/elkjs): "
    "EPL-2.0 OR GPL-3.0-or-later, used here under EPL-2.0.",
    "KiCad symbol library (KiCad Library Team and contributors, github.com/KiCad/kicad-symbols), "
    "converted to .kicad_sym: CC-BY-SA-4.0 WITH KiCad-libraries-exception. Drawings made with the "
    "symbols are not bound by the share-alike terms.",
    "IBM Plex Sans, Sans Condensed and Mono (IBM Corp.), latin subset: SIL Open Font License 1.1.",
]


def dataset_props(graph: str) -> dict:
    """The string properties of the graph's Dataset node (name, description, rights, license, ...)."""
    m = re.search(r"^CREATE \(\w*:Dataset \{(.*)\}\)$", graph, re.M)
    if not m:
        return {}
    return {k: re.sub(r"\\(.)", r"\1", v) for k, v in re.findall(r"(\w+): '((?:[^'\\]|\\.)*)'", m.group(1))}


def wrap(text: str, indent: str = "  ", width: int = 98) -> str:
    out, line = [], indent
    for word in text.split():
        if len(line) + len(word) + 1 > width and line.strip():
            out.append(line.rstrip())
            line = indent
        line += word + " "
    out.append(line.rstrip())
    return "\n".join(out)


def bullet(text: str) -> str:
    return "  - " + wrap(text, "    ").lstrip()


# Licences known by URL, named in full where a graph states one.
LICENCE_NAMES = {
    "https://opendatacommons.org/licenses/by/1-0/": "Open Data Commons Attribution License 1.0 (ODC-By 1.0)",
    "https://opendatacommons.org/licenses/odbl/1-0/": "Open Data Commons Open Database License 1.0 (ODbL 1.0)",
    "https://opendatacommons.org/licenses/pddl/1-0/": "Open Data Commons Public Domain Dedication and License 1.0 (PDDL 1.0)",
    "https://creativecommons.org/licenses/by/4.0/": "Creative Commons Attribution 4.0 International (CC BY 4.0)",
    "https://creativecommons.org/licenses/by-sa/4.0/": "Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0)",
    "https://creativecommons.org/publicdomain/zero/1.0/": "CC0 1.0 Universal",
}

# Full licence texts carried in every built page, for the components whose licences ask that a
# copy travel with each copy: the viewer's own (Apache-2.0), elkjs (EPL-2.0) and the fonts (OFL).
LICENCE_TEXTS = [
    ("license-apache-2.0", "the viewer software", ROOT / "vendor" / "licenses" / "Apache-2.0.txt"),
    ("license-epl-2.0", "elkjs", ROOT / "vendor" / "package" / "LICENSE.md"),
    ("license-ofl-1.1", "the IBM Plex fonts", ROOT / "vendor" / "fonts" / "LICENSE"),
]


def licence_scripts() -> str:
    return "\n".join(
        f'<script type="text/plain" id="{sid}" data-applies-to="{what}">\n{guard(path.read_text(encoding="utf-8"), path.name)}</script>'
        for sid, what, path in LICENCE_TEXTS)


def about_comment(graph: str, graph_name: str) -> str:
    """A plain-text guide at the very top of the page: what the file holds, where the graph is,
    how to read it, and every licence that applies. Written for people and AI agents alike."""
    d = dataset_props(graph)
    labels = {}
    for lab in re.findall(r"^CREATE \(\w*:(\w+) \{", graph, re.M):
        labels[lab] = labels.get(lab, 0) + 1
    rels = len(re.findall(r"^MATCH .* CREATE \(\w+\)-\[:", graph, re.M))
    nodes = sum(labels.values())
    graph_licence = d.get("license")
    lines = [
        graph_name,
        "",
        "FOR AI AGENTS AND OTHER TOOLS: this file contains a complete openCypher knowledge graph (a labeled "
        "property graph) stored as plain text. It is the <script type=\"text/x-cypher\" id=\"graph-source\"> "
        "element near the end of the file, and it is the single source of everything this page draws. Read it "
        "directly rather than interpreting the drawing.",
        "",
        "To extract it, take the text between that opening tag and the next </script>; it is embedded verbatim, "
        "with no escaping. It is one openCypher statement per line: CREATE statements make the nodes, then "
        "MATCH ... CREATE statements add the relationships, matching their two ends by id. Lines starting with // "
        "are comments.",
        "",
        f"It holds {nodes} node statements and {rels} relationship statements. Labels: "
        + ", ".join(f"{k} ({v})" for k, v in sorted(labels.items(), key=lambda kv: -kv[1])) + ".",
        "",
        ("Some links are properties rather than relationships: a Pin's connector property holds the id of "
         "its Connector.\n\n" if re.search(r"^CREATE \(\w*:Pin \{[^\n]*connector: '", graph, re.M) else "")
        + "The graph describes itself: a Dataset node (DCAT) states what it covers and its license and rights, "
        "Method nodes (PROV) state how it was built, and a ConceptScheme of Term nodes (SKOS) defines every "
        "label, relationship type and property it uses, with mappings to KiCad, KBL (VDA 4964), VEC (VDA 4968) "
        "and other standards. The viewer's drawing rules are the JSON in <script id=\"rules-profile\">, and "
        "the KiCad symbol libraries are the <script type=\"application/x-kicad-sym\"> elements.",
    ]
    if d.get("description"):
        lines += ["", "About the model: " + d["description"]]
    lines += ["", "Licenses:"]
    lines.append("- Knowledge graph (the graph-source element): "
                 + (f"{LICENCE_NAMES[graph_licence]}, {graph_licence}" if graph_licence in LICENCE_NAMES
                    else graph_licence or "not stated in the graph") + ".")
    lines.append(f"- Viewer software (the application and engine scripts, page markup and styles): "
                 f"{VIEWER_LICENSE[0]}, {VIEWER_LICENSE[1]}.")
    lines += [f"- {t}" for t in THIRD_PARTY]
    lines += ["", "The full texts of the Apache-2.0, EPL-2.0 and SIL OFL 1.1 licenses are the "
              "<script type=\"text/plain\"> elements with ids license-apache-2.0, license-epl-2.0 and "
              "license-ofl-1.1 at the end of the file."]
    if d.get("rights"):
        lines += ["", "Notice: " + d["rights"]]
    # A paragraph break inside an entry becomes a blank line of its own.
    lines = [x for l in lines for i, part in enumerate(l.split("\n\n")) for x in (["", part] if i else [part])]
    body = "\n".join(bullet(l[2:]) if l.startswith("- ") else wrap(l) if l else "" for l in lines)
    # A comment may not contain two hyphens in a row.
    body = re.sub(r"-{2,}", lambda m: "- " * len(m.group(0)), body)
    return "<!--\n" + body + "\n-->\n"


def head_metadata(graph: str, graph_name: str) -> str:
    """A description meta tag and schema.org Dataset metadata for the embedded graph."""
    d = dataset_props(graph)
    meta = {"@context": "https://schema.org", "@type": "Dataset", "name": d.get("name") or graph_name,
            "encodingFormat": "text/x-cypher",
            "description": d.get("description") or graph_name}
    if d.get("license"):
        meta["license"] = d["license"]
    if d.get("issued"):
        meta["datePublished"] = d["issued"]
    data = json.dumps(meta, ensure_ascii=False).replace("</", "<\\/")
    desc = html.escape(f"{meta['description']} Contains its openCypher knowledge graph as plain text "
                       f"(script#graph-source).", quote=True)
    return (f'<meta name="description" content="{desc}">\n'
            f'<script type="application/ld+json">{data}</script>\n')


def require_symbols() -> None:
    """Every library lib/symbols.json lists must be present and match its recorded sha256, so a page
    is only built from the pinned upstream symbols (tools/fetch_symbols.py fetches them)."""
    sys.path.insert(0, str(ROOT / "tools"))
    import fetch_symbols
    state = fetch_symbols.status(json.loads(fetch_symbols.MANIFEST.read_text(encoding="utf-8")))
    bad = {n: s for n, s in state.items() if s != "ok"}
    if bad:
        raise SystemExit("KiCad symbol libraries " + ", ".join(f"{n} ({s})" for n, s in bad.items())
                         + ": run python3 tools/fetch_symbols.py first")


def main(graph_path: str, graph_name: str, out_path: str) -> None:
    require_symbols()
    graph = Path(graph_path).read_bytes().decode("utf-8")
    page = (SRC / "page.html").read_text()
    rules = compact_json(json.loads((SRC / "profile.json").read_text()))
    libs = "\n".join(
        f'<script type="application/x-kicad-sym" data-library="{name}" data-source="{PROVENANCE}">'
        f'{guard((LIB / f"{name}.kicad_sym").read_text(), name)}</script>'
        for name in LIBRARIES
    )
    engine = "\n".join(guard((SRC / f).read_text(), f) for f in ENGINE)
    app = guard((SRC / "app.js").read_text(), "app.js")

    parts = {
        # The page is titled with the graph's name.
        "{{PAGE_TITLE}}": html.escape(graph_name),
        "{{GRAPH_NAME}}": graph_name,
        "{{GRAPH_SOURCE}}": guard(graph, "graph"),
        "{{RULES}}": guard(rules, "rules"),
        "{{LIBRARIES}}": libs,
        "{{ENGINE}}": engine,
        "{{APP}}": app,
    }
    # Replace one placeholder at a time, splitting on the marker, so no content is reinterpreted.
    for key, value in parts.items():
        pieces = page.split(key)
        if len(pieces) != 2:
            raise SystemExit(f"template must contain {key} exactly once")
        page = pieces[0] + value + pieces[1]

    # elkjs is carried inline in every copy, so the page never depends on reaching a CDN.
    elk = guard((ROOT / "vendor/package/lib/elk.bundled.js").read_text(), "elkjs")
    # The id lets the page start the same engine in a worker (src/app.js, workerElk).
    elk_inline = "<script id=\"elk-source\">/* elkjs 0.12.0, Eclipse Layout Kernel, EPL-2.0 OR GPL-3.0-or-later (github.com/kieler/elkjs) */\n" + elk + "\n</script>"
    cdn_tag = re.search(r'<script src="https://cdn\.jsdelivr\.net/npm/elkjs[^>]*></script>', page).group(0)
    page = page.replace(cdn_tag, elk_inline)

    # The fonts are carried inline too, so the page makes no network request at all.
    if FONT_LINKS not in page:
        raise SystemExit("template's font links not found")
    page = page.replace(FONT_LINKS, font_faces())

    # What the file holds and every licence that applies, first in the file where a reader starts;
    # the same facts as page metadata after the title.
    about = about_comment(graph, graph_name)
    page = page.rstrip("\n") + "\n" + licence_scripts() + "\n"
    title_end = page.index("</title>") + len("</title>")
    page = page[:title_end] + "\n" + head_metadata(graph, graph_name) + page[title_end + 1:]

    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(about + page, encoding="utf-8")

    # Standalone copy: a complete document for opening straight from disk.
    head, body = page.split('<div class="app">', 1)
    standalone = ('<!doctype html>\n' + about + '<html lang="en">\n<head>\n<meta charset="utf-8">\n'
                  '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'
                  f'{head}</head>\n<body>\n<div class="app">{body}</body>\n</html>\n')
    standalone_path = out.with_name(out.stem + ".standalone.html")
    standalone_path.write_text(standalone, encoding="utf-8")

    match = re.search(r'<script type="text/x-cypher" id="graph-source" data-name="[^"]*">(.*?)</script>', page, re.S)
    if match is None or match.group(1) != graph:
        raise SystemExit("embedded graph does not match the source file")
    print(f"wrote {out} and {standalone_path.name} ({out.stat().st_size / 1024:.0f} KiB); embedded graph verified byte-identical "
          f"({len(graph.encode())} bytes, {graph.count(chr(10))} lines)")


if __name__ == "__main__":
    main(*sys.argv[1:4])
