// Convert a self-describing openCypher graph to RDF (Turtle).
//
// The graph's own Term nodes say what every label, relationship type and property means and
// give each one an IRI (see tools/schema_terms.py), so the conversion needs no outside mapping:
//   node          -> <base + id>, typed with its label's IRI, one triple per property
//   relationship  -> <base + rel/TYPE/start/end>, typed with the relationship type's IRI, with
//                    rdf:subject and rdf:object (the LinkML reading of a relationship class),
//                    one triple per property
//   values        -> literals typed by the property's value type, IRIs as resources (so a
//                    skos:closeMatch points at the standard's term); lists become repeated triples
//   names         -> each Term's IRI carries its label, definition, usage note and SKOS mappings,
//                    so the RDF explains itself without the schema file
// The base IRI is the Dataset node's base_iri, or the second argument.
//
// Usage: node tools/cypher2rdf.js GRAPH.cypher [BASE_IRI] > graph.ttl
// Validate: python3 tools/validate_rdf.py graph.ttl schema/wiring_kg.shacl.ttl schema/wiring_kg.owl.ttl

const path = require("path");
const fs = require("fs");
const ROOT = path.resolve(__dirname, "..");
const C = require(path.join(ROOT, "src/cypher.js"));
const S = require(path.join(ROOT, "src/scene.js"));

const XSD = "http://www.w3.org/2001/XMLSchema#";
const RDF = "http://www.w3.org/1999/02/22-rdf-syntax-ns#";
const DATATYPE = { integer: `${XSD}integer`, number: `${XSD}float`, boolean: `${XSD}boolean`, date: `${XSD}date` };

function convert(text, baseArg) {
  const { graph, diagnostics } = C.load(text);
  const errors = (diagnostics || []).filter((d) => d.level === "error");
  if (errors.length) throw new Error(`the graph does not parse: line ${errors[0].line}: ${errors[0].message}`);
  const profile = JSON.parse(fs.readFileSync(path.join(ROOT, "src/profile.json"), "utf8"));
  const model = S.readModel(graph, profile);
  if (!model || !model.scheme) throw new Error("the graph embeds no vocabulary (ConceptScheme and Term nodes); add one with tools/schema_terms.py");
  const base = baseArg || model.dataset?.props.base_iri;
  if (!base) throw new Error("no base IRI: give the Dataset node a base_iri, or pass one");
  const T = model.terms;
  const iri = (s) => `<${String(s).replace(/[\s<>"{}|^`\\]/g, (ch) => `%${ch.charCodeAt(0).toString(16).toUpperCase().padStart(2, "0")}`)}>`;
  const nodeIri = (n) => iri(base + encodeURIComponent(String(n.props.id)));
  const str = (v) => `"${String(v).replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\n/g, "\\n").replace(/\r/g, "\\r")}"`;
  const literal = (term, v) => {
    const vt = String(term.value_type || "text").replace(/^list of /, "");
    if (vt === "IRI") return iri(v);
    if (DATATYPE[vt]) return `${str(v)}^^<${DATATYPE[vt]}>`;
    return str(v);
  };
  const missing = new Set();
  const props = (el) => {
    const out = [];
    for (const [k, v] of Object.entries(el.props)) {
      if (k === "id") continue;
      const t = T.props.get(k);
      if (!t) { missing.add(`property ${k}`); continue; }
      for (const x of Array.isArray(v) ? v : [v]) out.push(`${iri(t.iri)} ${literal(t, x)}`);
    }
    return out;
  };
  const lines = [`# RDF form of the graph "${model.dataset?.props.name ?? "(unnamed)"}", converted with its own embedded vocabulary.`, ""];
  for (const n of graph.nodes.values()) {
    const types = n.labels.map((l) => T.labels.get(l)).filter(Boolean).map((t) => iri(t.iri));
    for (const l of n.labels) if (!T.labels.has(l)) missing.add(`label ${l}`);
    const po = [...types.map((t) => `a ${t}`), ...props(n)];
    lines.push(`${nodeIri(n)}\n    ${po.join(" ;\n    ")} .`);
  }
  const seen = new Map();
  for (const r of graph.rels.values()) {
    const t = T.rels.get(r.type);
    if (!t) { missing.add(`relationship type ${r.type}`); continue; }
    const a = graph.nodes.get(r.start), b = graph.nodes.get(r.end);
    // A relationship with an id of its own (a compact WIRE) keeps it as its IRI.
    let key = r.props.id !== undefined ? String(r.props.id) : `rel/${r.type}/${a.props.id}/${b.props.id}`;
    const k = (seen.get(key) || 0) + 1;
    seen.set(key, k);
    if (k > 1) key += `/${k}`;
    const po = [`a ${iri(t.iri)}`, `<${RDF}subject> ${nodeIri(a)}`, `<${RDF}object> ${nodeIri(b)}`, ...props(r)];
    lines.push(`${iri(base + key.split("/").map(encodeURIComponent).join("/"))}\n    ${po.join(" ;\n    ")} .`);
  }
  // What each name means, stated on the name's own IRI, so any RDF tool shows the definitions.
  const SKOS = "http://www.w3.org/2004/02/skos/core#", RDFS = "http://www.w3.org/2000/01/rdf-schema#";
  lines.push("", "# Definitions of the names used above, from the graph's embedded vocabulary.");
  for (const bucket of [T.labels, T.rels, T.props, T.valueSets]) for (const t of bucket.values()) {
    const po = [`<${RDFS}label> ${str(t.name)}`, `<${RDFS}isDefinedBy> ${nodeIri(model.scheme)}`];
    if (t.definition) po.push(`<${SKOS}definition> ${str(t.definition)}`);
    if (t.usage) po.push(`<${SKOS}scopeNote> ${str(t.usage)}`);
    for (const k of ["exact", "close", "broad", "narrow", "related"]) for (const u of t[`${k}_match`] || []) po.push(`<${SKOS}${k}Match> ${iri(u)}`);
    lines.push(`${iri(t.iri)}\n    ${po.join(" ;\n    ")} .`);
  }
  if (missing.size) throw new Error(`not defined in the embedded vocabulary: ${[...missing].join(", ")}`);
  return lines.join("\n") + "\n";
}

if (require.main === module) {
  const [file, base] = process.argv.slice(2);
  try {
    process.stdout.write(convert(fs.readFileSync(file, "utf8"), base));
  } catch (e) {
    console.error(e.message);
    process.exit(1);
  }
}

module.exports = { convert };
