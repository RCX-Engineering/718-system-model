"""Rendered-drawing checks on a built viewer page: measure what the browser actually drew.

The layout checks (tools/check.js) work from estimated text widths. This pass opens the built
page in Chromium, reads real bounding boxes from the SVG in every configuration the graph offers
(each combination of variation points, logical and physical, plus the default configuration with
unconnected pins and wire tags shown), and reports:
  text-on-part    text belonging to one part lying over another part's body or pins
  text-on-text    text of two different parts overlapping
  text-on-wire    part text crossed by a wire
  label-on-part   a net label, bus label or wire tag lying over a part
  label-on-wire   a label covering a wire of a different net
  label-ambiguous a label nearer another net's wire than its own
  label-cuts-wire a net label drawn over another run of its own net
  part-geometry   a part drawn with a position or size that is not a number
  leader-on-pin   an annotation leader passing through a pin end
Each configuration is saved as a screenshot with every finding outlined, for a visual review.

Usage: python3 tools/visual_check.py PAGE.html [--out DIR]
Exit status 1 when anything is reported, 2 when the page fails to load.
"""
import asyncio, itertools, json, sys
from pathlib import Path
from playwright.async_api import async_playwright

PROBE = r"""
() => {
  const svg = document.querySelector('#sheet svg');
  const boxOf = (el) => { const b = el.getBBox(); const m = el.getCTM(), r = svg.getCTM().inverse().multiply(m);
    const pts = [[b.x, b.y], [b.x + b.width, b.y], [b.x, b.y + b.height], [b.x + b.width, b.y + b.height]].map(([x, y]) => [r.a * x + r.c * y + r.e, r.b * x + r.d * y + r.f]);
    const xs = pts.map(p => p[0]), ys = pts.map(p => p[1]);
    return { x: Math.min(...xs), y: Math.min(...ys), w: Math.max(...xs) - Math.min(...xs), h: Math.max(...ys) - Math.min(...ys) }; };
  const shrink = (r, d) => ({ x: r.x + d, y: r.y + d, w: Math.max(0, r.w - 2 * d), h: Math.max(0, r.h - 2 * d) });
  const hit = (a, b) => a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;
  const texts = [], parts = [];
  for (const sym of svg.querySelectorAll('.symbol')) {
    const id = sym.dataset.sym;
    const name = sym.querySelector('.val')?.textContent || id;
    for (const t of sym.querySelectorAll('.val, .ref, .pin-cap, .sec-cap, .pin-name, .pin-num')) if (t.textContent.trim()) texts.push({ id, name, cls: t.getAttribute('class'), text: t.textContent, r: shrink(boxOf(t), 4) });
    const shapes = [...sym.querySelectorAll('.body, .lib-shape, .pin-line')];
    if (shapes.length) {
      const bs = shapes.map(boxOf);
      const x1 = Math.min(...bs.map(b => b.x)), y1 = Math.min(...bs.map(b => b.y)), x2 = Math.max(...bs.map(b => b.x + b.w)), y2 = Math.max(...bs.map(b => b.y + b.h));
      parts.push({ id, name, r: { x: x1, y: y1, w: x2 - x1, h: y2 - y1 } });
    }
  }
  // Wires: the visible strokes of every connection and bus, as straight segments.
  const segs = [];
  for (const p of svg.querySelectorAll('.conn path:not(.hit):not(.trace), .bus .bus-line')) {
    const d = p.getAttribute('d') || '';
    const nums = [...d.matchAll(/[ML]\s*(-?[\d.]+)[ ,](-?[\d.]+)/g)].map(m => [+m[1], +m[2]]);
    for (let i = 1; i < nums.length; i++) segs.push({ a: nums[i - 1], b: nums[i], net: p.closest('[data-net]')?.dataset.net || p.closest('[data-bundle]')?.dataset.bundle || '' });
  }
  const crosses = (s, r) => { // Liang-Barsky
    let t0 = 0, t1 = 1; const dx = s.b[0] - s.a[0], dy = s.b[1] - s.a[1];
    for (const [p, q] of [[-dx, s.a[0] - r.x], [dx, r.x + r.w - s.a[0]], [-dy, s.a[1] - r.y], [dy, r.y + r.h - s.a[1]]]) {
      if (p === 0) { if (q < 0) return false; continue; }
      const t = q / p; if (p < 0) { if (t > t1) return false; if (t > t0) t0 = t; } else { if (t < t0) return false; if (t < t1) t1 = t; }
    }
    return t1 - t0 > 1e-6; };
  const out = [];
  // Every drawn part needs a finite position and size; anything else cannot be drawn or measured.
  for (const r of svg.querySelectorAll('.symbol > .sym-hit')) {
    if (['x', 'y', 'width', 'height'].some(a => !isFinite(parseFloat(r.getAttribute(a))))) out.push({ kind: 'part-geometry', msg: `${r.parentNode.querySelector('.val')?.textContent || r.parentNode.dataset.sym}: position or size is not a number`, r: { x: 0, y: 0, w: 0, h: 0 } });
  }
  // Net labels, bus labels and wire tags belong to a net: they may sit on their own wire only.
  for (const g of svg.querySelectorAll('.net-label, .wire-tag, .bus')) {
    const t = g.classList.contains('bus') ? g.querySelector('.bus-label') : g.querySelector('text');
    if (!t) continue;
    const r = shrink(boxOf(g.classList.contains('bus') ? t : g), 4);
    const net = g.dataset.net || g.dataset.bundle || '';
    const label = `${g.classList.contains('bus') ? 'bus label' : g.classList.contains('net-label') ? 'net label' : 'wire tag'} "${t.textContent}"`;
    for (const p of parts) if (hit(r, p.r)) out.push({ kind: 'label-on-part', msg: `${label} lies over ${p.name}`, r });
    const s = segs.find(s => s.net !== net && crosses(s, r));
    if (s) out.push({ kind: 'label-on-wire', msg: `${label} covers a wire of another net`, r });
    for (const u of texts) if (hit(r, u.r)) out.push({ kind: 'text-on-text', msg: `${label} overlaps ${u.name} "${u.text}"`, r });
    // The wire nearest a label must be the one it names.
    if (!g.classList.contains('bus')) {
      const cx = r.x + r.w / 2, cy = r.y + r.h / 2;
      const dist = (s) => { const dx = s.b[0] - s.a[0], dy = s.b[1] - s.a[1], L = dx * dx + dy * dy || 1; const t = Math.max(0, Math.min(1, ((cx - s.a[0]) * dx + (cy - s.a[1]) * dy) / L)); return Math.hypot(cx - s.a[0] - t * dx, cy - s.a[1] - t * dy); };
      const nearest = segs.slice().sort((p, q) => dist(p) - dist(q))[0];
      if (nearest && nearest.net !== net) out.push({ kind: 'label-ambiguous', msg: `${label} sits nearer a wire of another net than its own`, r });
    }
  }
  for (const t of texts) {
    // Pin names and numbers sit on their own part; only another part's footprint is a collision.
    for (const p of parts) if (p.id !== t.id && hit(t.r, p.r)) out.push({ kind: 'text-on-part', msg: `${t.name}: "${t.text}" lies over ${p.name}`, r: t.r });
    if (/val|ref|pin-cap|sec-cap/.test(t.cls)) {
      const own = svg.querySelector(`.symbol[data-sym="${CSS.escape(t.id)}"]`);
      const ownNets = new Set([...own.querySelectorAll('[data-net]')].map(e => e.dataset.net));
      const s = segs.find(s => !(t.cls.includes('pin-cap') && ownNets.has(s.net)) && crosses(s, t.r));
      if (s) out.push({ kind: 'text-on-wire', msg: `${t.name}: "${t.text}" is crossed by a wire`, r: t.r });
    }
  }
  // A net label must not cut its own net's other runs either.
  for (const g of svg.querySelectorAll('.net-label')) {
    const r = shrink(boxOf(g), 4), net = g.dataset.net;
    const own = segs.filter(s => s.net === net && crosses(s, r) && !(Math.abs(s.a[1] - s.b[1]) < 0.5 && (s.a[1] < r.y || s.a[1] > r.y + r.h)));
    if (own.length) out.push({ kind: 'label-cuts-wire', msg: `net label "${g.textContent}" is drawn over its own wire`, r });
  }
  // Annotation leaders must not pass through a pin end, where they would read as a wire.
  const tips = [...svg.querySelectorAll('.pin .pin-line')].map(l => { const x1 = +l.getAttribute('x1'), y1 = +l.getAttribute('y1'); return [x1, y1]; });
  for (const p of svg.querySelectorAll('.callout .leader')) {
    const d = p.getAttribute('d') || '';
    const pts = [...d.matchAll(/[ML]\s*(-?[\d.]+)[ ,](-?[\d.]+)/g)].map(m => [+m[1], +m[2]]);
    for (let i = 1; i < pts.length; i++) {
      const s = { a: pts[i - 1], b: pts[i] };
      const hitTip = tips.find(t => crosses(s, { x: t[0] - 12, y: t[1] - 12, w: 24, h: 24 }));
      if (hitTip) { out.push({ kind: 'leader-on-pin', msg: `an annotation leader passes through a pin end`, r: { x: hitTip[0] - 20, y: hitTip[1] - 20, w: 40, h: 40 } }); break; }
    }
  }
  for (let i = 0; i < texts.length; i++) for (let j = i + 1; j < texts.length; j++) {
    const A = texts[i], B = texts[j];
    if (A.id !== B.id && hit(A.r, B.r)) out.push({ kind: 'text-on-text', msg: `${A.name} "${A.text}" overlaps ${B.name} "${B.text}"`, r: A.r });
  }
  // Mark each finding on the drawing.
  const ns = 'http://www.w3.org/2000/svg';
  for (const f of out) { const e = document.createElementNS(ns, 'rect'); for (const [k, v] of Object.entries({ x: f.r.x - 10, y: f.r.y - 10, width: f.r.w + 20, height: f.r.h + 20, fill: 'none', stroke: '#e0006a', 'stroke-width': 12 })) e.setAttribute(k, v); svg.appendChild(e); }
  return out.map(({ kind, msg }) => ({ kind, msg }));
}
"""

MEASURE_SCALE = 0.09   # screen pixels per mil while measuring
MAX_VIEW = 9000        # largest window side used for measuring, pixels
HIDE_CHROME = (".bar,.toolbar,.panel,.zoom,.draft{display:none!important}.work{grid-template-columns:1fr!important}"
               ".app{padding:0!important;gap:0!important;grid-template-rows:1fr!important}")


async def route(r):
    # The built page carries every script inline; nothing outside the file is fetched.
    await (r.continue_() if r.request.url.startswith("file://") else r.abort())


async def open_page(browser, url):
    page = await browser.new_page(viewport={"width": 1800, "height": 1000})
    errors = []
    page.on("pageerror", lambda e: errors.append(str(e)))
    await page.route("**/*", route)
    await page.goto(url)
    await page.wait_for_function("document.getElementById('status').hidden || document.getElementById('status').classList.contains('error')", timeout=30000)
    status = await page.eval_on_selector("#status", "e => e.hidden ? '' : e.textContent")
    if status or errors:
        raise SystemExit(f"page failed to load: {status or errors[0]}")
    return page


async def main():
    args = sys.argv[1:]
    out_dir = Path(args[args.index("--out") + 1]) if "--out" in args else Path("out")
    pages = [a for i, a in enumerate(args) if not a.startswith("--") and (i == 0 or args[i - 1] != "--out")]
    if not pages:
        raise SystemExit("usage: python3 tools/visual_check.py PAGE.html [--out DIR]")
    url = Path(pages[0]).resolve().as_uri()
    out_dir.mkdir(parents=True, exist_ok=True)
    total = 0
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await open_page(browser, url)
        points = await page.evaluate("() => (KGViewer.state.scene.variationPoints || []).map(p => ({ id: p.id, options: p.options.map(o => o.id) }))")
        has_pairs = await page.evaluate("() => !!KGViewer.state.scene.hasPairs")
        await page.close()
        combos = [dict(zip([pt["id"] for pt in points], sel)) for sel in itertools.product(*[pt["options"] for pt in points])] or [{}]
        # A graph with twisted pairs is checked with pairs routed together and apart.
        pair_views = (True, False) if has_pairs else (True,)
        configs = [(variants, physical, False, pairs) for pairs in pair_views for variants in combos for physical in (False, True)]
        configs += [({}, physical, True, True) for physical in (False, True)]
        for variants, physical, everything, pairs in configs:
            page = await open_page(browser, url)
            await page.add_style_tag(content=HIDE_CHROME)
            opts = {"physical": physical, "variants": variants, "pairs": pairs}
            if everything:
                opts.update({"wireTags": True, "showUnconnected": True})
            await page.evaluate("async (o) => { Object.assign(KGViewer.state.options, o); await KGViewer.run({ relayout: true }); KGViewer.fit(); }", opts)
            # Chromium quantises text metrics to screen pixels, so a large drawing fitted into a small
            # window reports inflated text boxes. Measure with the drawing at a legible scale.
            vb = await page.evaluate("() => (document.querySelector('#sheet svg').getAttribute('viewBox') || '0 0 0 0').split(/[ ,]+/).map(Number)")
            need = (min(MAX_VIEW, int(vb[2] * MEASURE_SCALE)), min(MAX_VIEW, int(vb[3] * MEASURE_SCALE)))
            if need[0] > 1800 or need[1] > 1000:
                await page.set_viewport_size({"width": max(1800, need[0]), "height": max(1000, need[1])})
                await page.evaluate("() => KGViewer.fit()")
            found = await page.evaluate(PROBE)
            tag = "-".join(["physical" if physical else "logical"] + (["all"] if everything else []) + ([] if pairs or not has_pairs else ["wires"]) + [v for v in variants.values()])
            await page.screenshot(path=str(out_dir / f"visual-{tag}.png"))
            await page.close()
            total += len(found)
            print(f"== {tag}: {len(found)} findings (screenshot {out_dir / f'visual-{tag}.png'})")
            for f in found:
                print(f"   {f['kind']}: {f['msg']}")
        await browser.close()
    print(f"total: {total} findings")
    sys.exit(1 if total else 0)


asyncio.run(main())
