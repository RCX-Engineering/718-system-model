// Drawing checks for one or more graphs, in every configuration each graph offers.
//
// Every combination of the graph's variation points is laid out both ways (logical and
// physical), and the default configuration again with unconnected pins shown. Each layout is
// checked by src/verify.js, and rendered to catch a twisted pair drawn untwisted. Exits 1
// when any check reports an error, 2 on a crash.
//
// Usage: node tools/check.js GRAPH.cypher [MORE.cypher ...] [--profile PROFILE.json] [--quiet]
const path = require('path');
const fs = require('fs');
const ROOT = path.resolve(__dirname, '..');
const C = require(path.join(ROOT, 'src/cypher.js'));
const K = require(path.join(ROOT, 'src/kicad.js'));
const S = require(path.join(ROOT, 'src/scene.js'));
const L = require(path.join(ROOT, 'src/layout.js'));
const V = require(path.join(ROOT, 'src/verify.js'));
const R = require(path.join(ROOT, 'src/render.js'));
const ELK = require(path.join(ROOT, 'vendor/package/lib/elk.bundled.js'));

const args = process.argv.slice(2);
const flag = (name) => { const i = args.indexOf(name); if (i < 0) return null; const v = args[i + 1]; args.splice(i, 2); return v; };
const profilePath = flag('--profile') || path.join(ROOT, 'src/profile.json');
const quiet = args.includes('--quiet') ? (args.splice(args.indexOf('--quiet'), 1), true) : false;
if (!args.length) { console.error('usage: node tools/check.js GRAPH.cypher [...] [--profile PROFILE.json] [--quiet]'); process.exit(2); }

// The libraries lib/symbols.json lists must be present and match their recorded sha256
// (tools/fetch_symbols.py fetches them from the pinned upstream commit).
const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, 'lib/symbols.json'), 'utf8'));
const badLibs = Object.entries(manifest.libraries).filter(([name, e]) => {
  const f = path.join(ROOT, 'lib', `${name}.kicad_sym`);
  return !fs.existsSync(f) || require('crypto').createHash('sha256').update(fs.readFileSync(f)).digest('hex') !== e.sha256;
}).map(([name]) => name);
if (badLibs.length) { console.error(`KiCad symbol libraries missing or changed: ${badLibs.join(', ')}; run python3 tools/fetch_symbols.py first`); process.exit(2); }

const lib = new K.Library();
for (const f of fs.readdirSync(path.join(ROOT, 'lib')).filter((f) => f.endsWith('.kicad_sym')).sort()) {
  lib.addText(path.basename(f, '.kicad_sym'), fs.readFileSync(path.join(ROOT, 'lib', f), 'utf8'));
}
const profile = JSON.parse(fs.readFileSync(profilePath, 'utf8'));
// Text is measured at a fixed advance, as the monospace drawing font sets it.
const measure = (t, size) => String(t).length * size * 0.6;
const combos = (points) => points.reduce((acc, pt) => acc.flatMap((sel) => pt.options.map((o) => ({ ...sel, [pt.id]: o.id }))), [{}]);

(async () => {
  let errors = 0, warnings = 0;
  for (const f of args) {
    const { graph, diagnostics } = C.load(fs.readFileSync(f, 'utf8'));
    for (const d of diagnostics || []) {
      if (d.level === 'error') errors++;
      console.log(`   [${d.level[0]}] parse line ${d.line}: ${d.message}`);
    }
    // A graph with views (systems) is checked view by view, as the viewer shows it; each in the
    // configuration it opens in and with each option of each choice it uses taken one at a time.
    // A small graph is checked whole, in every combination of its choices.
    const sheets = S.sheetsOf(graph, profile);
    // The whole graph is the viewer's default view; it is checked in its default configuration.
    const views = sheets.length > 1 ? [{ sheet: null, graph, defaultOnly: true }, ...sheets.map((sh) => ({ sheet: sh, graph: S.subgraph(graph, S.sheetIds(graph, profile, sh), profile) }))] : [{ sheet: null, graph }];
    // The class the viewer opens on (views.open), drawn across the whole graph in its default configuration.
    const openClass = profile.views?.open?.class;
    if (openClass && (profile.units?.classes || []).some((c) => c.name === openClass)) {
      const cv = S.classView(graph, profile, lib, openClass);
      if (cv.nets) views.push({ sheet: null, cls: openClass, graph: S.subgraph(graph, cv.ids, profile), netNames: cv.netNames, defaultOnly: true });
    }
    const runs = [];
    for (const view of views) {
      const g = view.graph;
      const points = S.configure(g, profile, {}).points;
      const used = new Set();
      for (const n of g.nodes.values()) for (const v of [].concat(n.props.variants || [])) used.add(String(v));
      const live = points.filter((pt) => pt.options.some((o) => used.has(String(o.id))));
      // a sheet opens in the configuration that shows it (S.sheetChoices), as in the viewer
      const base = view.sheet ? S.sheetChoices(graph, profile, view.sheet, {}) : {};
      const chosen = (pt) => base[pt.id] || pt.default;
      const configs = view.defaultOnly ? [{}] : view.sheet ? [base, ...live.flatMap((pt) => pt.options.filter((o) => o.id !== chosen(pt)).map((o) => ({ ...base, [pt.id]: o.id })))] : combos(points);
      view.base = base;
      // A graph with twisted pairs is checked in both views: pairs routed together, and apart.
      const pairViews = S.buildScene(g, profile, lib, {}).hasPairs ? [true, false] : [true];
      for (const pairs of pairViews) for (const variants of configs) for (const physical of [false, true]) runs.push({ view, points, variants, physical, showUnconnected: false, pairs, pairViews });
      if (!view.defaultOnly) for (const physical of [false, true]) runs.push({ view, points, variants: base, physical, showUnconnected: true, pairs: true, pairViews });
    }
    for (const { view, points, variants, physical, showUnconnected, pairs, pairViews } of runs) {
      const sc = S.buildScene(view.graph, profile, lib, { physical, showUnconnected, variants, pairs, partial: !!view.sheet, outsideNetNames: view.netNames });
      const out = await L.layoutScene(sc, new ELK(), { measure, physical });
      const { findings } = V.run(sc, out);
      // The drawing itself: a twisted pair the renderer could not twist is an error.
      const drawn = R.renderSvg(sc, out, { title: '' }, { wireColors: 'physical', netLabels: true, pairs }, measure);
      for (const fb of drawn.pairFallbacks || []) findings.push({ check: 'pair-drawn', level: 'error', message: `${fb.name} (${fb.id}): the twisted pair could not be drawn twisted and shows as a plain bus line.` });
      const e = findings.filter((x) => x.level === 'error').length, w = findings.length - e;
      errors += e; warnings += w;
      const config = points.map((pt) => pt.options.find((o) => o.id === (variants[pt.id] || pt.default))?.name).filter(Boolean).join(' · ');
      console.log(`== ${f}${view.sheet ? ` {${view.sheet}}` : ''}${view.cls ? ` {${view.cls} connections}` : ''} ${physical ? 'physical' : 'logical'}${showUnconnected ? ' +unconnected' : ''}${pairViews.length > 1 ? (pairs ? ' pairs' : ' wires') : ''}${config ? ` [${config}]` : ''}: ${e} errors, ${w} warnings`);
      for (const x of findings) if (!quiet || x.level === 'error') console.log(`   [${x.level[0]}] ${x.check}: ${x.message}`);
      for (const n of sc.notes || []) if (!quiet && n.level !== 'info') console.log(`   [note] ${n.message}`);
    }
  }
  console.log(`total: ${errors} errors, ${warnings} warnings`);
  process.exit(errors ? 1 : 0);
})().catch((e) => { console.error('crash:', e); process.exit(2); });
