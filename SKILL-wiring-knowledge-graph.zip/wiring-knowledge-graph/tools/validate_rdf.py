"""Validate the RDF form of a graph against the vocabulary's SHACL shapes.

The shapes and the OWL ontology are generated from schema/wiring_kg.yaml by LinkML:
    gen-shacl schema/wiring_kg.yaml > schema/wiring_kg.shacl.ttl
    gen-owl   schema/wiring_kg.yaml > schema/wiring_kg.owl.ttl
The ontology is loaded so class hierarchy (Pin and Splice are TerminationMixin) is inferred.

Usage: python3 tools/validate_rdf.py GRAPH.ttl SHAPES.ttl ONTOLOGY.ttl
Exit status 0 when the graph conforms, 1 when it does not. Requires pyshacl.
"""

import sys

from pyshacl import validate
from rdflib import Graph


def main(data_path: str, shapes_path: str, ontology_path: str) -> int:
    data = Graph().parse(data_path, format="turtle")
    shapes = Graph().parse(shapes_path, format="turtle")
    ontology = Graph().parse(ontology_path, format="turtle")
    conforms, _, text = validate(data, shacl_graph=shapes, ont_graph=ontology, inference="rdfs",
                                 abort_on_first=False, allow_warnings=True)
    print(f"{len(data)} triples; {'conforms' if conforms else 'does not conform'}")
    if not conforms:
        print(text)
    return 0 if conforms else 1


if __name__ == "__main__":
    sys.exit(main(*sys.argv[1:4]))
