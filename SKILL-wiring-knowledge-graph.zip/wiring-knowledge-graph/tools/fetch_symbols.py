"""Fetch the KiCad symbol libraries the viewer draws with, from their single upstream source.

lib/symbols.json names the upstream repository, the commit every file is taken from, and for each
library the legacy .lib file and the symbols used. For each library this script downloads that
.lib at the pinned commit, converts the listed symbols with tools/lib2kicadsym.py, checks the
result against the recorded sha256, and writes lib/<name>.kicad_sym. A file that does not match
is not written, so a page is never built from a library other than the one recorded.

The download uses the repository's raw file URL; where that is not reachable, it fetches the one
pinned commit with git instead.

Usage: python3 tools/fetch_symbols.py           fetch any library that is missing or differs
       python3 tools/fetch_symbols.py --check   report whether lib/ matches the manifest
       python3 tools/fetch_symbols.py --record  after editing a library's symbol list: fetch and
                                                convert every library, write it, and record its
                                                new sha256 in the manifest
"""

from __future__ import annotations

import hashlib
import json
import subprocess
import sys
import tempfile
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
LIB = ROOT / "lib"
MANIFEST = LIB / "symbols.json"
sys.path.insert(0, str(ROOT / "tools"))
import lib2kicadsym  # noqa: E402


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def status(manifest: dict) -> dict[str, str]:
    """Each library's state in lib/: ok, missing or differs."""
    out = {}
    for name, entry in manifest["libraries"].items():
        path = LIB / f"{name}.kicad_sym"
        out[name] = "missing" if not path.exists() else "ok" if sha256(path.read_bytes()) == entry["sha256"] else "differs"
    return out


def download(source: dict, file: str, work: Path) -> Path:
    """The legacy library file at the pinned commit: by raw URL, else by fetching that one commit."""
    target = work / file
    url = source["raw_url"].format(commit=source["commit"], file=file)
    try:
        with urllib.request.urlopen(url, timeout=60) as r:
            target.write_bytes(r.read())
        return target
    except OSError as e:
        print(f"  {url} not reachable ({e}); fetching the commit with git")
    repo = work / "repo"
    if not repo.exists():
        subprocess.run(["git", "init", "-q", str(repo)], check=True)
        subprocess.run(["git", "-C", str(repo), "fetch", "-q", "--depth", "1", source["repository"], source["commit"]], check=True)
    blob = subprocess.run(["git", "-C", str(repo), "show", f"{source['commit']}:{file}"], check=True, capture_output=True).stdout
    target.write_bytes(blob)
    return target


def convert(lib_path: Path, symbols: list[str]) -> bytes:
    library = lib2kicadsym.parse_library(lib_path)
    missing = [s for s in symbols if s not in library]
    if missing:
        raise SystemExit(f"{lib_path.name}: no symbol {', '.join(missing)} at the pinned commit")
    blocks = [lib2kicadsym.convert_symbol(s, library[s]) for s in symbols]
    return ("(kicad_symbol_lib (version 20211014) (generator lib2kicadsym)\n" + "\n".join(blocks) + "\n)\n").encode()


def main(argv: list[str]) -> int:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    state = status(manifest)
    if "--check" in argv:
        for name, s in state.items():
            print(f"{name}: {s}")
        return 0 if all(s == "ok" for s in state.values()) else 1
    record = "--record" in argv
    todo = list(state) if record else [n for n, s in state.items() if s != "ok"]
    if not todo:
        print("lib/ matches lib/symbols.json")
        return 0
    source = manifest["source"]
    print(f"fetching {', '.join(todo)} from {source['repository']} at {source['commit'][:12]}")
    with tempfile.TemporaryDirectory() as tmp:
        work = Path(tmp)
        for name in todo:
            entry = manifest["libraries"][name]
            data = convert(download(source, entry["from"], work), entry["symbols"])
            if record:
                entry["sha256"] = sha256(data)
            elif sha256(data) != entry["sha256"]:
                raise SystemExit(f"{name}: the converted library does not match its recorded sha256; nothing written")
            (LIB / f"{name}.kicad_sym").write_bytes(data)
            print(f"  wrote lib/{name}.kicad_sym ({len(entry['symbols'])} symbols)")
    if record:
        MANIFEST.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
        print("  recorded the libraries' sha256 in lib/symbols.json")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
