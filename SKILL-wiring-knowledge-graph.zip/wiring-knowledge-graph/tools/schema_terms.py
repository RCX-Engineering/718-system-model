"""Embed a LinkML vocabulary in a graph as openCypher.

Reads the schema (for example schema/wiring_kg.yaml) and writes one ConceptScheme node and one
Term node per node label, relationship type, property and value set, each joined to the scheme
by IN_SCHEME. A graph that carries this block describes itself: the viewer shows the definitions,
the checks confirm every name the graph uses is defined and used as defined, and
tools/cypher2rdf.js converts the graph to RDF from the embedded IRIs.

Usage: python3 tools/schema_terms.py SCHEMA.yaml --write GRAPH.cypher
       writes (or rewrites) GRAPH's vocabulary block in place, with the names GRAPH uses.
       Without --write, prints the whole vocabulary. Generators import vocabulary_section.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

import yaml

# Cypher value-type names for LinkML ranges.
RANGE_NAMES = {"string": "text", "integer": "integer", "float": "number", "double": "number",
               "decimal": "number", "date": "date", "datetime": "date-time", "uri": "IRI",
               "uriorcurie": "IRI", "boolean": "boolean"}
# Reification slots: RDF-only, not openCypher property keys.
RDF_ONLY_SLOTS = {"subject", "object"}


def q(value) -> str:
    """openCypher literal for a string, number, boolean or list."""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return repr(value)
    if isinstance(value, (list, tuple)):
        return "[" + ", ".join(q(v) for v in value) + "]"
    return "'" + str(value).replace("\\", "\\\\").replace("'", "\\'") + "'"


def props(d: dict) -> str:
    return "{" + ", ".join(f"{k}: {q(v)}" for k, v in d.items() if v not in (None, [], "")) + "}"


def one_line(text) -> str:
    return " ".join(str(text or "").split())


class Schema:
    def __init__(self, path: Path):
        self.path = path
        self.s = yaml.safe_load(path.read_text())
        self.prefixes = self.s.get("prefixes", {})
        self.default = self.s.get("default_prefix")
        self.classes = self.s.get("classes", {})
        self.slots = self.s.get("slots", {})
        self.enums = self.s.get("enums", {})

    def expand(self, curie: str) -> str:
        if "://" in curie:
            return curie
        pfx, _, local = curie.partition(":")
        return self.prefixes[pfx] + local

    def iri(self, name: str, uri_key: str, element: dict) -> str:
        return self.expand(element.get(uri_key) or f"{self.default}:{name}")

    def ancestors(self, name: str) -> list[str]:
        out, c = [], self.classes.get(name, {})
        while c.get("is_a"):
            out.append(c["is_a"])
            c = self.classes.get(c["is_a"], {})
        return out

    def is_relationship(self, name: str) -> bool:
        return any(self.classes.get(a, {}).get("represents_relationship") for a in [name, *self.ancestors(name)])

    def concrete(self, name: str) -> bool:
        c = self.classes[name]
        return not c.get("abstract") and not c.get("mixin")

    def cypher_name(self, name: str) -> str:
        return (self.classes[name].get("annotations") or {}).get("cypher", name)

    def slots_of(self, name: str) -> list[str]:
        out = []
        for a in [*reversed(self.ancestors(name)), name]:
            for m in [a, *self.classes.get(a, {}).get("mixins", [])]:
                out += self.classes.get(m, {}).get("slots", [])
        return list(dict.fromkeys(out))

    def labels_for(self, rng: str) -> list[str]:
        """Concrete node labels a range admits (a class, its descendants, or classes using a mixin)."""
        out = []
        for n, c in self.classes.items():
            if not self.concrete(n) or self.is_relationship(n):
                continue
            if n == rng or rng in self.ancestors(n) or rng in c.get("mixins", []):
                out.append(n)
        return out

    def ends(self, name: str, which: str) -> list[str]:
        use = (self.classes[name].get("slot_usage") or {}).get(which, {})
        if use.get("any_of"):
            return [lab for alt in use["any_of"] for lab in self.labels_for(alt["range"])]
        return self.labels_for(use.get("range", "Entity"))

    def mappings(self, element: dict) -> dict:
        return {f"{k}_match": [self.expand(c) for c in element.get(f"{k}_mappings", [])]
                for k in ("exact", "close", "broad", "narrow", "related")}

    def status(self, element: dict):
        subs = element.get("in_subset") or []
        return subs[0] if subs else None

    def value_type(self, slot: dict) -> str:
        rng = slot.get("range", self.s.get("default_range", "string"))
        vt = f"value set {rng}" if rng in self.enums else RANGE_NAMES.get(rng, rng)
        return f"list of {vt}" if slot.get("multivalued") else vt


def names_used(cypher_text: str) -> dict[str, set[str]]:
    """The labels, relationship types and property keys an openCypher text uses."""
    # One left-to-right pass, so a // inside a string and a quote inside a comment are both safe.
    token = re.compile(r"'(?:\\.|[^'\\\n])*'|\"(?:\\.|[^\"\\\n])*\"|//[^\n]*")
    text = token.sub(lambda m: "" if m.group(0).startswith("//") else "''", cypher_text)
    labels = set(re.findall(r"\(\s*(?:[A-Za-z_]\w*)?\s*:\s*([A-Za-z_]\w*)", text))
    rels = set(re.findall(r"\[\s*(?:[A-Za-z_]\w*)?\s*:\s*([A-Za-z_]\w*)", text))
    props = set()
    for body in re.findall(r"\{([^{}]*)\}", text):
        props |= set(re.findall(r"(?:^|,)\s*([A-Za-z_]\w*)\s*:", body))
    props |= set(re.findall(r"\.\s*([A-Za-z_]\w*)\s*=", text))
    return {"labels": labels, "rels": rels, "props": props}


def cypher_block(schema_path: str | Path, scheme_id: str = "vocabulary", used: dict | None = None) -> list[str]:
    """ConceptScheme and Term nodes for the vocabulary. With used (from names_used), only the
    names the graph uses are embedded, with the value sets they draw on; the block's own names
    are always included."""
    S = Schema(Path(schema_path))
    ann = S.s.get("annotations") or {}
    scheme = dict(id=scheme_id, name=S.s.get("title", S.s["name"]), description=one_line(S.s.get("description")),
                  reading_guide=one_line(ann.get("reading_guide")), naming_rule=one_line(ann.get("naming_rule")),
                  status_meanings=[f"{k}: {one_line(v.get('description'))}" for k, v in (S.s.get("subsets") or {}).items()],
                  namespace=S.prefixes[S.default], schema_file=f"schema/{Path(schema_path).name}")
    terms = []

    # Node labels and relationship types.
    for name, c in S.classes.items():
        if not S.concrete(name):
            continue
        rel = S.is_relationship(name)
        cy = S.cypher_name(name)
        t = dict(id=f"term_{'rel' if rel else 'label'}_{cy}", name=cy,
                 kind="relationship_type" if rel else "node_label", iri=S.iri(name, "class_uri", c),
                 definition=one_line(c.get("description")), usage=" ".join(one_line(x) for x in c.get("comments", [])),
                 status=S.status(c), **S.mappings(c))
        if rel:
            t["from_labels"] = S.ends(name, "subject")
            t["to_labels"] = S.ends(name, "object")
        terms.append(t)

    # Properties: every slot a concrete class carries, with the labels and types that carry it.
    carriers: dict[str, list[str]] = {}
    required: dict[str, bool] = {}
    for name in S.classes:
        if not S.concrete(name):
            continue
        for sl in S.slots_of(name):
            carriers.setdefault(sl, []).append(S.cypher_name(name))
            use = (S.classes[name].get("slot_usage") or {}).get(sl, {})
            if use.get("required") or S.slots.get(sl, {}).get("required"):
                required.setdefault(sl, set()).add(S.cypher_name(name))
    for name, sl in S.slots.items():
        if name in RDF_ONLY_SLOTS or name not in carriers:
            continue
        codes = (sl.get("annotations") or {}).get("codes")
        terms.append(dict(id=f"term_prop_{name}", name=name, kind="property", iri=S.iri(name, "slot_uri", sl),
                          definition=one_line(sl.get("description")), usage=" ".join(one_line(x) for x in sl.get("comments", [])),
                          status=S.status(sl), applies_to=carriers[name], value_type=S.value_type(sl),
                          required=sorted(required.get(name, [])) or None,
                          value_pattern=sl.get("pattern"), value_minimum=sl.get("minimum_value"),
                          value_maximum=sl.get("maximum_value"), value_codes=codes, **S.mappings(sl)))

    # Value sets.
    for name, e in S.enums.items():
        values = [f"{v}: {one_line((d or {}).get('description', ''))}" for v, d in (e.get("permissible_values") or {}).items()]
        terms.append(dict(id=f"term_values_{name}", name=name, kind="value_set", iri=S.iri(name, "enum_uri", e),
                          definition=one_line(e.get("description")), status=S.status(e), values=values, **S.mappings(e)))

    if used is not None:
        # The block's own names are always used.
        labels = set(used["labels"]) | {"ConceptScheme", "Term"}
        rels = set(used["rels"]) | {"IN_SCHEME"}
        keys = set(used["props"]) | set(S.slots_of("ConceptScheme")) | set(S.slots_of("Term"))
        carriers_used = labels | rels
        kept = []
        for t in terms:
            if t["kind"] == "node_label" and t["name"] in labels:
                kept.append(t)
            elif t["kind"] == "relationship_type" and t["name"] in rels:
                kept.append(t)
            elif t["kind"] == "property" and t["name"] in keys:
                t["applies_to"] = [c for c in t["applies_to"] if c in carriers_used] or t["applies_to"]
                if t.get("required"):
                    t["required"] = [c for c in t["required"] if c in carriers_used] or None
                kept.append(t)
        sets = set()
        for t in kept:
            m = re.search(r"value set (\S+)", t.get("value_type") or "")
            if m:
                sets.add(m.group(1))
            if t.get("value_codes"):
                sets.add(t["value_codes"])
        kept += [t for t in terms if t["kind"] == "value_set" and t["name"] in sets]
        terms = kept

    out = [f"CREATE (:ConceptScheme {props(scheme)})"]
    for t in terms:
        out.append(f"CREATE (:Term {props(t)})")
    for t in terms:
        out.append(f"MATCH (a {{id: {q(t['id'])}}}), (b {{id: {q(scheme_id)}}}) CREATE (a)-[:IN_SCHEME {{}}]->(b)")
    return out


BEGIN = "// ---------------------------------------------------------------- vocabulary"
END = "// ---------------------------------------------------------------- end of vocabulary"


def vocabulary_section(schema_path: str | Path, graph_text: str, scheme_id: str = "vocabulary") -> str:
    """The graph's vocabulary block, between marker comments: the ConceptScheme, a Term for each
    name the rest of the graph uses, and CONFORMS_TO from the Dataset when there is one."""
    rest = strip_section(graph_text)
    note = (f"// Generated by tools/schema_terms.py from schema/{Path(schema_path).name}: one Term per name this graph uses.\n"
            "// Regenerate after changing the graph; do not edit by hand.")
    used = names_used(rest)
    has_dataset = "Dataset" in used["labels"]
    if has_dataset:
        used["rels"].add("CONFORMS_TO")
    lines = [BEGIN, note, *cypher_block(schema_path, scheme_id, used)]
    if has_dataset:
        lines.append(f"MATCH (d:Dataset), (s {{id: {q(scheme_id)}}}) CREATE (d)-[:CONFORMS_TO {{}}]->(s)")
    lines.append(END)
    return "\n".join(lines)


def strip_section(graph_text: str) -> str:
    """The graph without its vocabulary block."""
    return re.sub(re.escape(BEGIN) + r".*?" + re.escape(END) + r"\n?", "", graph_text, flags=re.S)


def write_section(schema_path: str | Path, graph_path: str | Path, scheme_id: str = "vocabulary") -> None:
    """Replace the graph file's vocabulary block, or append one."""
    p = Path(graph_path)
    text = p.read_text()
    section = vocabulary_section(schema_path, text, scheme_id)
    if BEGIN in text:
        text = re.sub(re.escape(BEGIN) + r".*?" + re.escape(END), lambda _: section, text, flags=re.S)
    else:
        text = text.rstrip("\n") + "\n\n" + section + "\n"
    p.write_text(text)


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="Embed a LinkML vocabulary in a graph as openCypher.")
    ap.add_argument("schema")
    ap.add_argument("--write", dest="graph", help="write (or rewrite) the vocabulary block of this graph file in place")
    ap.add_argument("--scheme-id", default="vocabulary")
    a = ap.parse_args()
    if a.graph:
        write_section(a.schema, a.graph, a.scheme_id)
    else:
        print("\n".join(cypher_block(a.schema, a.scheme_id)))
