"""Convert selected symbols from KiCad legacy .lib files to the KiCad 6+ .kicad_sym format.

The official KiCad symbol library is only reachable here through its archived
GitHub mirror, which holds the legacy (KiCad 5) .lib files. The conversion
follows the same rules KiCad applies when it migrates a legacy library:

  * coordinates and sizes go from mils to millimetres
  * S / P / C / A draw records become rectangle / polyline / circle / arc
  * legacy arcs are given a mid point on the shorter sweep between the
    recorded start and end points, which is how KiCad 5 drew them
  * X pin records become pin nodes with electrical type, graphic shape,
    orientation angle, length, name and number
  * unit 0 / convert 0 items are shared; DeMorgan (convert 2) items are dropped

Usage:
    python lib2kicadsym.py OUT.kicad_sym LIB.lib:Symbol[,Symbol...] [...]
Symbol names may use a trailing * to select every symbol with that prefix.
"""

from __future__ import annotations

import math
import re
import shlex
import sys
from pathlib import Path

MIL = 0.0254  # millimetres per mil

PIN_TYPES = {
    "I": "input", "O": "output", "B": "bidirectional", "T": "tri_state",
    "P": "passive", "U": "unspecified", "W": "power_in", "w": "power_out",
    "C": "open_collector", "E": "open_emitter", "N": "no_connect",
}
PIN_SHAPES = {
    "": "line", "I": "inverted", "C": "clock", "IC": "inverted_clock",
    "L": "input_low", "CL": "clock_low", "V": "output_low",
    "F": "edge_clock_high", "X": "non_logic",
}
PIN_ANGLES = {"R": 0, "U": 90, "L": 180, "D": 270}
FILLS = {"F": "outline", "f": "background", "N": "none"}


def mm(value: str | float) -> str:
    """Format a mil value as millimetres the way KiCad writes them."""
    text = f"{float(value) * MIL:.4f}".rstrip("0").rstrip(".")
    return "0" if text in ("-0", "") else text


def q(text: str) -> str:
    return '"' + text.replace("\\", "\\\\").replace('"', '\\"') + '"'


def parse_library(path: Path) -> dict[str, list[str]]:
    """Return symbol name -> raw record lines between DEF and ENDDEF."""
    symbols: dict[str, list[str]] = {}
    current: list[str] | None = None
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        if line.startswith("DEF "):
            current = [line]
        elif current is not None:
            current.append(line)
            if line.startswith("ENDDEF"):
                symbols[current[0].split()[1]] = current
                current = None
    return symbols


def aliases_of(records: list[str]) -> list[str]:
    for line in records:
        if line.startswith("ALIAS "):
            return line.split()[1:]
    return []


def arc_mid(cx: float, cy: float, r: float, sx: float, sy: float, ex: float, ey: float) -> tuple[float, float]:
    a0 = math.atan2(sy - cy, sx - cx)
    a1 = math.atan2(ey - cy, ex - cx)
    sweep = (a1 - a0) % (2 * math.pi)
    if sweep > math.pi:            # take the shorter sweep, as KiCad 5 does
        sweep -= 2 * math.pi
    mid = a0 + sweep / 2
    return cx + r * math.cos(mid), cy + r * math.sin(mid)


def stroke_fill(width: str, fill: str) -> str:
    w = mm(width) if float(width) > 0 else "0"
    return f"(stroke (width {w}) (type default)) (fill (type {FILLS.get(fill, 'none')}))"


def field(name: str, parts: list[str]) -> str:
    # F<n> "text" x y size orient visibility hjustify vjustify+style
    text, x, y, size, orient, vis = parts[0].strip('"'), parts[1], parts[2], parts[3], parts[4], parts[5]
    angle = 90 if orient == "V" else 0
    hide = " hide" if vis == "I" else ""
    return (f'    (property {q(name)} {q(text)} (at {mm(x)} {mm(y)} {angle})\n'
            f'      (effects (font (size {mm(size)} {mm(size)})){hide}))')


def convert_symbol(name: str, records: list[str]) -> str:
    head = records[0].split()
    # DEF name ref unused text_offset draw_nums draw_names unit_count locked flag
    ref, text_offset, draw_nums, draw_names, flag = head[2], head[4], head[5], head[6], head[9]
    out = [f"  (symbol {q(name)}"]
    if flag == "P":
        out.append("    (power)")
    if draw_nums == "N":
        out.append("    (pin_numbers hide)")
    names_hide = " hide" if draw_names == "N" else ""
    out.append(f"    (pin_names (offset {mm(text_offset)}){names_hide})")
    out.append("    (in_bom yes) (on_board yes)")

    field_names = {0: "Reference", 1: "Value", 2: "Footprint", 3: "Datasheet"}
    for line in records:
        match = re.match(r"^F(\d+)\s+(.*)$", line)
        if match and int(match.group(1)) in field_names:
            out.append(field(field_names[int(match.group(1))], shlex.split(match.group(2), posix=False)))

    graphics: list[str] = []
    pins: list[str] = []
    in_draw = False
    for line in records:
        if line.startswith("DRAW"):
            in_draw = True
            continue
        if line.startswith("ENDDRAW"):
            break
        if not in_draw or not line.strip():
            continue
        tok = line.split()
        kind = tok[0]
        if kind == "S":
            x1, y1, x2, y2, unit, conv, width, fill = tok[1:9]
            if conv == "2":
                continue
            graphics.append(f"      (rectangle (start {mm(x1)} {mm(y1)}) (end {mm(x2)} {mm(y2)}) {stroke_fill(width, fill)})")
        elif kind == "P":
            count, unit, conv, width = int(tok[1]), tok[2], tok[3], tok[4]
            if conv == "2":
                continue
            coords = tok[5:5 + 2 * count]
            fill = tok[5 + 2 * count] if len(tok) > 5 + 2 * count else "N"
            pts = " ".join(f"(xy {mm(coords[i])} {mm(coords[i + 1])})" for i in range(0, len(coords), 2))
            graphics.append(f"      (polyline (pts {pts}) {stroke_fill(width, fill)})")
        elif kind == "C":
            x, y, r, unit, conv, width = tok[1:7]
            fill = tok[7] if len(tok) > 7 else "N"
            if conv == "2":
                continue
            graphics.append(f"      (circle (center {mm(x)} {mm(y)}) (radius {mm(r)}) {stroke_fill(width, fill)})")
        elif kind == "A":
            x, y, r, _t1, _t2, unit, conv, width, fill, sx, sy, ex, ey = tok[1:14]
            if conv == "2":
                continue
            mx, my = arc_mid(*(float(v) for v in (x, y, r, sx, sy, ex, ey)))
            graphics.append(f"      (arc (start {mm(sx)} {mm(sy)}) (mid {mm(mx)} {mm(my)}) (end {mm(ex)} {mm(ey)}) {stroke_fill(width, fill)})")
        elif kind == "T":
            # T angle x y size hidden unit convert "text" italic bold hjust vjust
            angle, x, y, size, _hidden, unit, conv = tok[1:8]
            if conv == "2":
                continue
            text = tok[8].strip('"').replace("~", " ")
            graphics.append(f"      (text {q(text)} (at {mm(x)} {mm(y)} {int(angle) // 10}) (effects (font (size {mm(size)} {mm(size)}))))")
        elif kind == "X":
            pname, number, x, y, length, orient, nsize, psize, unit, conv, etype = tok[1:12]
            if conv == "2":
                continue
            shape_code = tok[12] if len(tok) > 12 else ""
            hidden = "N" in shape_code
            shape = PIN_SHAPES.get(shape_code.replace("N", ""), "line")
            hide = " hide" if hidden else ""
            pins.append(
                f"      (pin {PIN_TYPES.get(etype, 'unspecified')} {shape} (at {mm(x)} {mm(y)} {PIN_ANGLES[orient]}) (length {mm(length)}){hide}\n"
                f"        (name {q(pname)} (effects (font (size {mm(nsize)} {mm(nsize)}))))\n"
                f"        (number {q(number)} (effects (font (size {mm(psize)} {mm(psize)})))))"
            )

    out.append(f'    (symbol {q(name + "_0_1")}')
    out.extend(graphics)
    out.append("    )")
    out.append(f'    (symbol {q(name + "_1_1")}')
    out.extend(pins)
    out.append("    )")
    out.append("  )")
    return "\n".join(out)


def main(argv: list[str]) -> None:
    out_path = Path(argv[1])
    blocks = []
    for spec in argv[2:]:
        lib_path, names = spec.split(":", 1)
        library = parse_library(Path(lib_path))
        for pattern in names.split(","):
            if pattern.endswith("*"):
                chosen = sorted(n for n in library if n.startswith(pattern[:-1]))
            else:
                chosen = [pattern]
            for name in chosen:
                if name not in library:
                    raise SystemExit(f"{lib_path}: no symbol {name}")
                blocks.append(convert_symbol(name, library[name]))
    text = "(kicad_symbol_lib (version 20211014) (generator lib2kicadsym)\n" + "\n".join(blocks) + "\n)\n"
    out_path.write_text(text)
    print(f"wrote {out_path}: {len(blocks)} symbols, {len(text)} bytes")


if __name__ == "__main__":
    main(sys.argv)
