---
name: wiring-knowledge-graph
description: Model electronics wiring (boards, connectors, harnesses, pinouts) as an openCypher knowledge graph and render it as a verified KiCad-style interactive schematic viewer.
---

# Wiring knowledge graph → KiCad-style schematic viewer

Use this for any electronics wiring diagram, harness or pinout: model the system as an openCypher
property graph, then build a single-file HTML viewer that interprets that graph live. The viewer
draws with KiCad symbols, routes with ELK, and has a Tables view, an inspector, configuration
pickers and self-checks. The graph is the single source of truth. The viewer never holds
project knowledge.

## Non-negotiables

1. **The viewer is a pure interpreter.** Never add project-specific code, names or special cases
   to `src/`. Put every project fact in the graph. If the drawing needs a new kind of behaviour,
   add a *generic* rule to `src/profile.json` (keyed on labels, relationship types or property
   names), or a generic engine feature that any graph could use.
2. **Ground truth first.** Record only what the user stated, a datasheet or standard shows, or
   what you verified online. Where a value is unknown, write `'not recorded'` or leave the
   property out; never invent colours, pin numbers or positions. For researched values, record
   the source and a status, e.g. `color_source: '...'` and
   `color_status: 'confirmed by two sources' | 'unconfirmed: owner recollection'`. Say plainly in
   the reply what is unconfirmed.
3. **Every physical contact belongs to a connector**: a board header, a housing on a harness, or
   a port. The only exception is a pin marked `termination: 'flying lead'`.
   - Group physically adjacent positions into the housing they really share. Use 2- or 4-position
     housings where the pins are adjacent and one housing is used.
   - Give non-standard connector types (JST SH, JST PH, JST XH, Dupont, IDC, SAE J1962) their
     real series.
4. **Gender is stated, never implied.** Use `user_gender`:
   - `'male header'` for board pins;
   - `'female housing'` for crimp housings on wiring;
   - `'male plug'` for male cable ends;
   - `'female'` for receptacle ports.

   The viewer draws KiCad's male blade or female socket from this property.
5. **Verify before delivering.** `tools/check.js` must report 0 errors in every configuration,
   and `tools/visual_check.py` must report 0 findings. Then look at the screenshots yourself.
6. **Delivery conventions:**
   - Give the user the built page. Where the host can publish a page (an artifact or similar),
     publish `out/my.html` and, when iterating, republish it in place.
   - Send each modified file individually, not a zip.
   - Keep all iteration history out of files: no version, revision or "updated" notes in titles,
     comments or property values.
   - Make surgical edits to existing graphs; don't rewrite them wholesale.

## The toolkit

Everything the skill needs is in this folder: the viewer engine, the KiCad symbol libraries,
elkjs, the tools, the schema, examples and tests. Paths in this file are relative to the folder.
Run the tools from it, or copy it into the working directory first; builds write to `out/`.

`index.html` is the viewer ready to use, with no build: one self-contained file that opens on the
sensor-node example and loads any `.cypher` with "Open graph…" or by dropping the file on the
drawing. `tools/build.py` makes such a page with a given model embedded.

If the folder's files are not reachable (only this SKILL.md was installed), use a built viewer
`.html` instead. A built page carries the whole engine inline: its graph can be swapped in the
`<script type="text/x-cypher" id="graph-source">` block, or loaded with the page's
"Open graph…" button.

Requirements: Node 18+ and Python 3. The visual check needs the Python `playwright` package with
Chromium (`python3 -m playwright install chromium` if no Chromium is set up for it). The RDF tools
need `rdflib` and `pyshacl`; `tools/schema_terms.py` needs `PyYAML`. There are no npm
dependencies, because elkjs is vendored. Before the first build or check, run `python3 tools/fetch_symbols.py`
once to fetch the KiCad symbol libraries (it needs network access once; see "KiCad symbols").

Layout:
```
index.html  the viewer, prebuilt and self-contained
src/        cypher.js kicad.js scene.js layout.js render.js verify.js tables.js app.js page.html profile.json
lib/        symbols.json: which KiCad symbols, from which upstream commit; the .kicad_sym files
            (Connector, Connector_Generic, Device, Switch, power) are fetched by
            tools/fetch_symbols.py (CC-BY-SA 4.0 with the KiCad libraries exception; see lib/LICENSE.md)
vendor/     elkjs 0.12 (EPL-2.0 or GPL-3.0-or-later) and the IBM Plex fonts (SIL OFL 1.1, as inline
            WOFF2 in fonts/ibm-plex.css), each with its licence; licenses/ holds the Apache-2.0 text
            that built pages carry
tools/      build.py  check.js  visual_check.py  fetch_symbols.py  lib2kicadsym.py
            schema_terms.py (embed the vocabulary)  cypher2rdf.js (graph to RDF)  validate_rdf.py (SHACL)
schema/     wiring_kg.yaml (the vocabulary, LinkML) and the SHACL shapes and OWL generated from it
examples/   sensor_node.cypher (compact template)  RCX_RTK_Datalogger_wiring.cypher (large real model)
test/       engine regression tests: run after any change to src/
```

## Workflow

1. **Gather facts.** Collect board pinouts (header side and order), connector series and
   genders, wire colours and gauges, harness composition, what is inside the enclosure, and which
   parts are swapped between uses. Read datasheets and search standards (for example, OBD-II
   J1962 pins 6 and 14 carry CAN-H and CAN-L) instead of recalling them. Ask the user only for
   what can't be looked up. For drawings, photos, measurements and other source material,
   follow "From source material to a graph" below.
2. **Model** a `.cypher` file following the vocabulary below. Start from
   `examples/sensor_node.cypher`, which exercises every feature and shows the metadata a model
   carries. Fill in its Dataset, Source and Method nodes, then write the vocabulary block:
   `python3 tools/schema_terms.py schema/wiring_kg.yaml --write MY.cypher` (see "Model metadata").
3. **Check:** `node tools/check.js MY.cypher`. It lays out every combination of variants in both
   layouts, plus the default with unconnected pins shown, and runs the drawing checks. A graph
   with system views is checked whole in its default configuration, then system by system: each
   in the configuration it opens in and with each option of each choice it uses taken one at a
   time.
   - Fix all errors: first in the graph, then in the profile, and only as a last resort with a
     generic engine change.
   - Read the warnings; fix any that point at a real ambiguity.
4. **Build:** `python3 tools/build.py MY.cypher "MY.cypher" out/my.html`. This writes
   `out/my.html` (the page body, for hosts that wrap a page) and `out/my.standalone.html` (a full document that works
   offline and on tablets). The build embeds every library in `lib/`, elkjs and the fonts, so the
   page makes no network request; it verifies that the embedded graph is byte-identical to the
   source. Every page opens with a plain-text guide for people and AI agents (where the
   openCypher graph is, how to read it, its size, its description, every licence that applies and
   its notice), carries schema.org Dataset metadata, and ends with the full texts of the
   Apache-2.0, EPL-2.0 and SIL OFL 1.1 licences.
5. **Visual check:** `python3 tools/visual_check.py out/my.standalone.html --out out/visual`.
   This measures real text and wire boxes in Chromium, in every configuration. Open several of the
   PNGs and inspect them: plugs seated on their headers, genders, colours, labels,
   enclosure crossings.
6. **Deliver:**
   - Where the host can publish a page, publish `out/my.html`.
   - Give the user `MY.cypher` and `out/my.standalone.html` as files.
   - Give a short summary of what changed and what is still unconfirmed.
7. **Changing the engine?** Run `node test/t_verify_mutants.js`, which injects one fault per
   check and expects each to be caught, plus `node test/t_verify.js`, `node test/t_variants.js`,
   `node test/t_conductors.js` and `node test/t_vocabulary.js`.
   All of them must pass.

## From source material to a graph

A model is only as good as what it is read from. Work in passes, keep every intermediate result
(extracted text, traced conductors, joins) so a reading can be traced back, and record how each
fact was obtained. Use sources you are entitled to use. The model records facts (parts,
contacts, connections, colours, options) in its own structure and vocabulary; it never copies a
source's drawings, layout or text.

**1. Inventory the sources.** List each one and what it can establish:

- **Schematics and wiring drawings** (vector PDF, CAD export, or a scan or photo of a printed
  sheet): parts, connectors, pin numbers and names, conductors and their colours, splices,
  grounds and options.
- **Harness and connector drawings, pinout tables, datasheets and connector catalogues:** housing
  series, position counts, genders and pin functions.
- **Photographs:** connector faces and cavity numbers moulded on the housing, labels and part
  markings, wire colours and splice locations. Judge colours under neutral light, and record any
  colour read in poor light as unconfirmed.
- **Measurements:** continuity and resistance establish nets directly. Record what was measured,
  between which points and the reading.
- **Notes and existing data:** spreadsheets, netlists, earlier models, owner knowledge. Record
  owner knowledge as such (`twist_source: 'Stated by the vehicle owner: …'`).

Each source gets a `Source` node where the model cites its sources, and each procedure a
`Method` node that says what it can and cannot establish.

**2. Get text out of drawings.**

- **Vector drawings:** use the file's text objects when they exist, but verify them against the
  drawing first; a text layer added by an earlier OCR pass is often wrong. Where letters are
  drawn as outlines, group identical outlines, read each group once (OCR on a render, voting
  across upright and turned readings, and reading low-confidence groups by eye), then chain
  letters into words along a shared baseline.
- **Raster scans and photos:** run OCR at a resolution where the smallest text is at least 20 px
  high, and read pin numbers and designations by eye wherever OCR is unsure. Never guess a digit;
  leave it `'not recorded'` instead.
- Record the parameters (render resolution, grouping thresholds, word gap) in the Method.

**3. Trace the conductors.**

- **Paths:** follow each drawn conductor end to end through the drawing's paths, joining
  segments within a small tolerance. Record the tolerance, and use a larger one for dashed lines.
- **Colour:** a conductor's colour is the code printed beside it or, in a colour drawing, the
  stroke colours of the line (base colour, then a thinner stripe). Write it as a colour code
  (`BLK/VIO`).
- **Line styles:** dashed and solid lines usually mean different things (optional wiring, a
  shield, a part's internal connection). Read the drawing's legend and record what each style
  means.

**4. Classify every end.** Each end of a conductor is one of these:

- **A part's pin:** the number beside the end, the connector designation beside the group, and
  the pin name inside the part's outline in line with the conductor.
- **A cavity of an in-line connector:** two connector halves facing each other.
- **A splice:** a dot where three or more conductors meet.
- **A stud or ground point:** shown by its symbol and label.

A part is named by its label block, and keeps its location and fitment (`If equipped`, a model
or body variant) as properties. When two parts share a name but their contacts reach different
places, model two parts, each named with a bracketed note.

**5. Join across sheets and sources.**

- **Continuations:** a conductor that leaves one sheet at a continuation marker continues at the
  matching marker on the sheet it names. The two pieces are one conductor.
- **Parts, pins and in-line connectors** are one node across sheets when their names and numbers
  agree.
- **Splices:** a splice is one when two sheets join the same contacts there.
- **Conductors:** a conductor is one when its ends agree and its colour agrees, or matches an
  alternative colour the source states (note both colours on the conductor).
- **Disagreements:** where sources disagree, keep both readings, say so in `notes`, and set
  `interpretation_status`. Never silently pick one.
- **Configuration-specific sources:** a source that covers only one configuration (one engine,
  one body) governs the contacts it covers for that configuration.

**6. Configurations.** Options shown in the sources become a `VariationPoint` with its
`Variant`s. Examples are marked option branches ("W/ option", "W/O option", "If equipped"),
columns of pin numbers per option, and alternative parts. Each element records the variants it
belongs to in `variants`. Choose a `default_variant` for each point, and a `tier` (`primary` for
the choices that define the product, `secondary` for the rest).

**7. Nets and buses.** A net is a connected group of pins and splices, joined by conductors,
mated positions and the positions of one ground point. Name each net in this order of
preference:

1. the ground point it reaches;
2. a standard or gateway pin name;
3. the fuse or supply that feeds it;
4. a pin name on it.

Record which rule gave the name in `name_source`. A bus (CAN, LIN) is a `Bus` node with
`HAS_MEMBER` to its nets and their `role` (`CAN_H`, `CAN_L`).

**8. Verify.**

- **Checks:** run the checks in every configuration, and resolve all errors.
- **Counts and consistency:**
  - each connector's pin numbers fall within its position count;
  - every pin of a part appears once;
  - a conductor's colour agrees across sheets.
- **Spot-check against the sources:** compare a random sample of conductors end to end, and
  record the sample size and result in the checks Method.
- **Unconfirmed values:** mark everything not confirmed with its status property, and say what
  is unconfirmed when delivering.

**9. Record the method.** Write one `Method` per procedure, with its `parameters` (thresholds,
resolutions, tolerances), `limitations` (what it cannot establish) and `produces`, so another
person can judge the model and repeat the work.

## Model metadata: every graph describes itself

A model must be readable, checkable and convertible without the tools, files or conversation
that made it. Its metadata therefore lives **inside the graph**, never in a companion document
that can be separated from it. `schema/wiring_kg.yaml` is where the vocabulary is maintained and
what the in-graph definitions are generated from; a reader never needs it. Keep the metadata short:
enough to understand the model with confidence, not a manual. Each graph carries:

- **A `Dataset` node** (DCAT `dcat:Dataset`): `name`, `description`, `issued`, `scope` (what it
  covers and what it leaves out), `base_iri` (the IRI prefix its nodes take in RDF), `rights`
  (Dublin Core `dcterms:rights`: trademark notices and disclaimers of affiliation or warranty) and
  `license` (Dublin Core `dcterms:license`: the licence's URL, for example ODC-By 1.0 for a
  database). The viewer shows `rights` and the licence at the foot of every view, and the build
  writes both into the plain-text guide at the top of the page, so a model carries its own notice
  and licence wherever it is shared.
- **`Source` nodes** (PROV `prov:Entity`), where the model cites its sources: each document or
  record used, with `publisher`, `pages`, `format`. `Dataset -[:WAS_DERIVED_FROM]-> Source`.
- **`Method` nodes** (PROV `prov:Plan`): each procedure applied, with `description`,
  `parameters` (settings and thresholds, as `name = value`), `limitations` (what it cannot
  establish), and `produces` (the labels, relationship types and properties it made).
  `Dataset -[:WAS_GENERATED_BY]-> Method`, and `Method -[:USED]-> Source` where Sources are cited. Include the checks run.
- **The vocabulary**: a `ConceptScheme` node (SKOS) with a `reading_guide` (how to read the
  graph, in a few sentences), the `naming_rule` and `status_meanings`; and one `Term` node for
  each label, relationship type, property and value set **the graph uses**, each `IN_SCHEME`
  the scheme, with `Dataset -[:CONFORMS_TO]-> ConceptScheme`. Each Term has `definition`,
  `usage`, `status` (adopted / adapted / new), `iri`, SKOS mappings to standards
  (`exact_match`, `close_match`, `broad_match`, `narrow_match`, `related_match`); relationships
  add `from_labels`/`to_labels`; properties add `applies_to`, `value_type`, `required` (where),
  and `value_pattern`, `value_minimum`, `value_maximum`, `value_codes` where they apply; value
  sets add `values`, each with its meaning.
  Write it with the tool, never by hand, after any change to the graph:
  `python3 tools/schema_terms.py schema/wiring_kg.yaml --write MY.cypher`. It rewrites the block
  between its marker comments in place (or appends it), from the names the rest of the graph
  uses. A generator imports `vocabulary_section` instead.
- **Element-level evidence** stays on the element: `name_source` (as marked or documented,
  standard, or descriptive), `interpretation_status` (an unconfirmed reading and why), `twist_source`, and a
  cited `standard_function`.

Metadata nodes are never drawn (profile `metadata`). The viewer's Model tab shows the dataset,
sources, methods and a searchable glossary with links to each standard's term; the inspector shows
each label's definition, and properties and relationship types carry theirs as tooltips.

With a vocabulary embedded, the checks `term-defined` and `term-usage` require every label,
relationship type and property to be defined, and used as defined: relationship ends, which
labels carry a property, value types, value sets, required properties. They run over the whole
graph, metadata and every configuration included.

**Conversion.** `node tools/cypher2rdf.js MY.cypher > my.ttl` writes RDF using only the graph's
own Terms: nodes typed with their label IRIs, relationships as instances of their relationship
class with `rdf:subject`/`rdf:object`, IRI values as resources, and each name's IRI carrying its
label, definition and SKOS mappings, so the RDF explains itself too.
`python3 tools/validate_rdf.py my.ttl schema/wiring_kg.shacl.ttl schema/wiring_kg.owl.ttl`
validates it against the SHACL shapes LinkML generates from the schema (needs `pyshacl`). The same
schema generates OWL, JSON Schema and documentation (`gen-owl`, `gen-json-schema`, `gen-doc`).

## Making a new model or a new domain from this template

The wiring schema is the template for other domains (piping, networks, structures, software).

1. **Copy the schema** to `schema/<domain>.yaml`. Keep the metadata classes (Dataset, Source,
   Method, ConceptScheme, Term) and their relationships unchanged, so every model shares one
   self-description.
2. **Set the namespace** (`id`, the default prefix) to an IRI the owning organisation controls.
3. **Name each concept** by the rule in "Where the names come from": search the domain's
   standards first (exchange formats, industry ontologies, the dominant design tool's own
   terms) and adopt their names, converted to openCypher case. Define a name only where none
   exists, and mark it `in_subset: [new]`.
4. **Define every name**: a one-sentence `description` that says what it is, not how it is
   drawn; `comments` for how it differs from the same word elsewhere; SKOS mappings to each
   standard's term (exact only when interchangeable); relationship `subject`/`object` ranges;
   property ranges, value sets, `required`.
5. **Validate the schema**: `linkml-lint`, then `gen-shacl` and `gen-owl` into `schema/`.
6. **Build the graph** with its metadata (Dataset, Sources, Methods with parameters and
   limitations), then write its vocabulary block with `tools/schema_terms.py --write`.
7. **Map the profile** (`src/profile.json`) onto the new labels and relationship types so the
   viewer can draw them; the profile is a mapping, not a vocabulary.
8. **Check**: `node tools/check.js`, then convert to RDF and validate with SHACL. Both must pass.
9. **Review the `new` terms** with the people who will own the vocabulary before the model is
   shared: those are the names most likely to become someone's standard by accident.

## Graph vocabulary (what the default profile interprets)

The supported Cypher subset is CREATE, MATCH (single-hop, with WHERE), OPTIONAL MATCH,
MERGE … ON CREATE/ON MATCH SET, SET, REMOVE, DELETE and DETACH DELETE. RETURN and WITH are
accepted and ignored. Every node gets a unique `id` and a human `name`. Relationships are written
`MATCH (a {id:'x'}), (b {id:'y'}) CREATE (a)-[:TYPE {...}]->(b)`.

### Where the names come from

Names follow, in this order: KiCad (schematic, symbol and netlist vocabulary), then the harness
standards KBL (VDA 4964) and VEC (VDA 4968), then protocol standards for signal roles (ISO 11898
`CAN_H`/`CAN_L`), then the wording the parts and their documentation use for values (pin names, net
names, colour codes). A name is invented only where none of these has one, and is listed as such
below. Standard names are converted to Cypher case: labels in PascalCase (`Wiring_group` →
`WiringGroup`), relationship types in UPPER_SNAKE_CASE (role `Assigned_wire` → `ASSIGNED_WIRE`),
properties in snake_case (`Position_on_wire` → `position_on_wire`). The profile also accepts older
aliases (`pin_number`, `GROUPS`, `CARRIES`, `end`), so existing graphs keep working.

The tables below are a summary; `schema/wiring_kg.yaml` is the authoritative definition of
every name, with its mappings to standards. `Function`, `HAS_FUNCTION`, `ASSIGNED_FUNCTION`,
`TAPS_VEHICLE_CAN` and `HAS_CAN_BUS` are understood by the profile but not yet defined in the
schema: define them there before a graph that embeds its vocabulary uses them.

### Nodes

| Label | Role | Key properties |
|---|---|---|
| `Component` (any non-structural label works, e.g. `Device`, `Vehicle`, `Host`) | a part: board, module, sensor; KiCad netlist `comp` | `name`, `type`, `diagram_order` (left→right placement), `kicad_symbol: 'Lib:Symbol'` for a discrete part, `ref` (e.g. `R1`), `notes` |
| `Connector` | a header, housing, port or plug | `name`, `type`, `series`, `user_gender`, `positions`, `nominal_pitch_mm`, `board_side` (`left`/`right`/`top`/`bottom`), `populated_positions: ['6', '14']` (text, as pin numbers are; a sparse plug drawn with just those positions, keeping their numbers), `cover_label` (text at the enclosure boundary when exposed) |
| `Pin` | one contact (KiCad pin; KBL cavity / contact point) | `name` and `number` (KiCad pin name and number), `electrical_type` (KiCad: `passive` for a connector cavity; `input`, `output`, `bidirectional`, `tri_state`, `power_in`, `power_out`, … for a device pin, only when a source states it), `direction` (`IN`/`OUT`/`BIDIR`), `connector: '<connector id>'`, `header_side` + `header_order` (physical position on the board edge), `position_x_mm`/`position_y_mm` (with a coordinate frame, for parts drawn to scale), `functions: [...]` (capabilities), `assigned_function`, `termination: 'flying lead'`, `logical_signal: true` (an internal node that is not a physical contact) |
| `Wire` | one conductor (KBL `Wire_or_core_occurrence`; not KiCad's drawn wire segment) | `id` (a key; never shown as a wire number unless the source prints one), `color` (a name, or a code such as `ORG/BLK`), `gauge`, `line_style`, `notes`. Its two `TERMINATES_AT` relationships say where it ends. Preferred over the `WIRE` relationship: a conductor is a thing that other things refer to. |
| `Splice` | where conductors are joined in the harness (KBL: a `Connector_occurrence` with an installation instruction `splice_type`) | `name`, `type: 'harness splice'`, `splice_type` (`end_splice`, `inline_splice`) only when the source shows it. Conductors terminate on it directly; it has no pins. Drawn as a KiCad junction: a trunk, and a dot where each conductor tees in. One node per net. |
| `WiringGroup` | conductors handled together in one run, e.g. a twisted pair (KBL `Wiring_group`; VEC `WireGrouping`) | `name`, `type: 'twisted-pair'` (KBL's example value), twist data only when a source gives it (`lay_length_mm`, with its source). Members through `ASSIGNED_WIRE {role}`. A pair drawn twisted is one run between two terminations. |
| `Harness` | a jacketed cable or a named bundle of conductors | `name`, `wires`, `colors`, `jacketed: true` (drawn as one KiCad bus with 45° entries), `notes` |
| `Enclosure` | a box around parts | `name`, `type` |
| `VariationPoint` / `Variant` | alternative configurations | `default_variant` on the point; elements present only in some configurations carry `variants: ['var_a', ...]` (within one point any listed choice fits it; across points all must). A part left out takes its connectors and pins with it. A part each configuration wires its own way is one part per configuration, each with its `variants`; a net that exists per configuration may share a name, told apart by the configuration in brackets. |
| `Function` | a named pin function | reached by `HAS_FUNCTION` (capability) or `ASSIGNED_FUNCTION` |
| `FaultMode` | an annotation callout | `name`; points at things with `AFFECTS` / `SUSPECT_AT`. Remove it when the fault is resolved. |
| `Net` (optional) | one electrical node (KiCad netlist `net`; KBL `Connection.Signal_name`). A differential signal is two nets: a CAN bus has a CAN_H net and a CAN_L net, never one net for both | `name`, `name_source` (printed on the source, or descriptive), `signal_type` (KBL values `BUS`, `ENERGY`, `GROUND`). Declared by conductors joining it with `IN_NET`; the checks confirm each declared net is exactly one connected net. (Pins may instead join it with `ON_NET`, which draws the net as one trunk from a hub pin.) Nets are otherwise inferred from connectivity. |
| `Bus` (optional) | the nets that together carry one signal or protocol (KiCad bus alias): a CAN bus is its CAN_H and CAN_L nets, the two bus lines of one differential pair | `name`, `protocol` (`CAN`, `LIN`, …). Its nets are members through `HAS_MEMBER {role}`; the viewer can highlight a whole bus. |

### Relationships

| Type | From → to | Meaning / drawing |
|---|---|---|
| `HAS_CONNECTOR` | part → connector | The connector is a section of the part's box, titled on the part. |
| `HAS_PIN` | part → pin, and connector → pin | Ownership. A connector with no owning part is a free connector, drawn with a KiCad `Conn_01xNN_Male/Female` symbol. |
| `MATES_WITH` | connector → connector, **and** pin → pin for each position | The plug is drawn seated on its header, nose to nose. Give both levels. |
| `TERMINATES_AT` | `Wire` → pin, or `Wire` → `Splice` | Where a conductor ends: `position_on_wire: 0.0` or `1.0` (KBL `Extremity.Position_on_wire`, VEC `WireEnd.positionOnWire`), exactly two per wire. Two wires may end on one pin (a doubled crimp). |
| `ASSIGNED_WIRE` | `WiringGroup` → `Wire` | Membership (KBL role `Assigned_wire`), with the conductor's `role` in the group (`CAN_H`, `CAN_L`). |
| `IN_NET` | `Wire` → `Net` | The net a conductor belongs to. |
| `HAS_MEMBER` | `Bus` → `Net` | The bus's member nets (KiCad bus alias `members`), with the `role` each plays (`CAN_H`, `CAN_L`, `LIN`). |
| `WIRE` | pin → pin | Compact form of one conductor, for graphs where nothing refers to individual conductors: `id`, `color`, `gauge`, `signal`, `harness`, `conductor`, `notes`. Conductors meet only at pins. |
| `USB_CABLE`, `RF_CABLE` | pin → pin | Cable conductors; RF is drawn as coax. |
| `TAPS_VEHICLE_CAN` | tap connector → bus | A tap. Vehicle-side colours (`vehicle_wire_color`, `vehicle_wire_color_full`) go on this relationship. |
| `ELECTRICALLY_COMMON`, `PARALLEL_CONTACT` | pin → pin | Merge nets without drawing a wire (for example, a screw terminal paralleled by header pads). |
| `CONTAINS` | enclosure → part or free connector | Membership, drawn as a dash-dot frame. |
| `EXPOSES_INTERFACE` | enclosure → connector | Wires leaving the frame through this connector get a boundary label (`cover_label` on the connector); an exposed connector with nothing outside gets a port label. |
| `HAS_VARIANT` | variation point → variant | The options offered in the picker, in relationship order. |
| `HAS_SUBCONNECTOR`, `HAS_CAN_BUS` | parent → child | Grouping. |

### Modelling patterns

- **Board headers:** a part `HAS_CONNECTOR` a `Connector {user_gender: 'male header', positions: N}`.
  - Pins carry `connector`, `header_side` and `header_order`.
  - Model the positions that are used. Unconnected pins stay hidden until the "Unconnected pins"
    option is turned on.
  - Skipped positions keep their pitch, so a mating housing still lines up.
- **Harness ends:** a free `Connector {user_gender: 'female housing'}` with its own pins, plus
  `MATES_WITH` at connector and pin level onto the header positions it covers. Record which
  header positions a housing sits on (`header_positions: '5-7'`).
- **Pigtails** (male pins on a cable end, as with Dupont pigtails):
  `user_gender: 'male plug'` at the free end. The next lead's `female housing` mates with it.
- **Discrete parts** (a resistor, LED or switch in a lead): a `Component` with
  `kicad_symbol: 'Device:LED'` and `ref`. Its pins use the symbol's numbers (LED: 1 = K,
  2 = A; battery: 1 = +, 2 = −) and `termination: 'flying lead'`.
- **Configurations:** one `VariationPoint` per independent choice, such as the USB host (PC or
  power source), the attached vehicle or bus, or "no vehicle attached". Tag every element that
  exists only in some choices. The toolbar shows one picker per point that changes something in
  the current drawing, and every combination is checked (per sheet, one option at a time).
- **Standards-based ports** such as OBD-II: model only the pins in use. Put their standard numbers
  on the pins and `populated_positions` on the plug. Cite the standard in a property.
- **Conductors, splices, pairs and buses** keep three layers apart, following the VEC harness
  model (VDA 4968), where a twisted pair is a grouping of independent wires in their usage:
  - *physical*: each conductor is a `Wire` node, `TERMINATES_AT` a pin or a `Splice` at each end;
    a twisted pair is a `WiringGroup {type: 'twisted-pair'}` with its two wires `ASSIGNED_WIRE`, each with
    its `role`. Twisting stops at every splice or connector, so each run is its own group. A cable
    bought as one part (jacket, cores) is a `Harness {jacketed: true}`.
  - *electrical*: each conductor is `IN_NET` a named `Net`; nets otherwise follow connectivity.
  - *logical*: a `Bus {protocol}` `HAS_MEMBER` its nets, each with its role.
  - A CAN-H splice and its CAN-L twin stay two `Splice` nodes. The viewer draws them as one
    junction with two joints when their conductors pair off through twisted-pair groups.
- **Colours:** use names from the profile (`red`, `black`, `orange`, `yellow`, `green`, `blue`,
  `white`, `brown`, `gray`, `violet`/`purple`, `pink`, `tan`, `clear`) or codes (`RED`, `BLK`,
  `ORG`, `YEL`, `GRN`, `BLU`, `WHT`, `BRN`, `GRY`, `VIO`, `PNK`, `TAN`). Two-colour wires are
  written `ORG/BLK` (base/stripe).
- **Physical layout:** the "Physical pin locations" option places header pins by
  `header_side`/`header_order`, or by millimetre coordinates when every pin of the part has them;
  otherwise each connector's pins run in strict number order. Mark partial knowledge with
  `physical_position_status`.
- **Logical layout** (option off): each connector's pins stay together on one edge, but their
  order is chosen for the drawing. Pins whose nets are members of one `Bus`, or whose wires share
  a `WiringGroup`, sit side by side in the bus's member order (`CAN_H` before `CAN_L`), each
  cluster where its wires lead. A connector mated to a library connector symbol keeps number
  order so each position faces its mate.

## KiCad symbols

The symbols come from one source of truth: the KiCad symbol library
(github.com/KiCad/kicad-symbols, by the KiCad Library Team and contributors, CC-BY-SA 4.0 with the
KiCad libraries exception), at the pinned commit `4e17d7595f9691d45d97aea8ad64572652fb5bed`.
`lib/symbols.json` lists, for each library, the upstream file, the symbols used and the sha256 of
the converted result. The toolkit does not store the converted files:
`python3 tools/fetch_symbols.py` downloads the upstream files at that commit (by raw URL, or with
git where that is not reachable), converts the listed symbols with `tools/lib2kicadsym.py`, checks
each result against its sha256 and writes `lib/<name>.kicad_sym`. `build.py` and `check.js` stop
with that instruction when a library is missing or differs. Built pages embed the libraries, so
viewing a page never needs this step. The libraries used are:

- **Connector:**
  - `Conn_01x01..20_Male`
  - `Conn_01x01..20_Female`
  - `Screw_Terminal_01x02..12`
  - `Conn_Coaxial`, `Barrel_Jack`, `USB_B_Micro`, `USB_C_Receptacle_USB2.0`, `AudioJack3`
- **Connector_Generic:**
  - `Conn_01x01..40`
  - `Conn_02x02..25_Odd_Even`
- **Device:**
  - Resistors: `R`, `R_US`, `R_Potentiometer`, `Thermistor_NTC`
  - Capacitors and inductors: `C`, `C_Polarized`, `L`, `FerriteBead`
  - Diodes: `D`, `D_Schottky`, `D_Zener`, `LED`
  - Protection and power: `Fuse`, `Polyfuse`, `Battery`, `Battery_Cell`
  - `Crystal`, `Buzzer`, `Speaker`, `Antenna`
  - Transistors: `Q_NPN_BEC`, `Q_PNP_BEC`, `Q_NMOS_GSD`, `Q_PMOS_GSD`
  - `Opamp_Dual`
- **Switch:** `SW_Push`, `SW_SPST`, `SW_SPDT`, `SW_DIP_x04`
- **power:** `+3V3`, `+5V`, `+12V`, `+24V`, `+BATT`, `GND`, `GNDA`, `VCC`, `PWR_FLAG`

To add symbols, add their names to the library's `symbols` list in `lib/symbols.json`, in the
order the file should hold them (or add a library entry, with its upstream `from` file), then run
`python3 tools/fetch_symbols.py --record`, which converts every library and records the new
sha256 values. `build.py` embeds every `lib/*.kicad_sym` automatically. Users can also load a
`.kicad_sym` file into the page at runtime with "Add KiCad library…".

Symbol choice comes from `profile.json` → `symbols`, first match wins:
1. `{kicad_symbol}` or `{symbol}` given on the node.
2. `Antenna` label.
3. Screw terminal types.
4. Coax types.
5. Female, then male, connectors (`Conn_01x{n}_Female` / `_Male`).
6. Generic `Conn_01x{n}`.
7. Otherwise a generated box: a part with its connectors as titled sections.

## profile.json (rules, not code)

- `structure`: pin, connector and group labels and relationships. It also names:
  - `logicalPins`;
  - `sectionKeys` (`connector`);
  - `positionKeys`;
  - `populatedPositionKeys`;
  - `genders` (which keys state gender, and the male/female patterns);
  - `leadPins`.
- `variants`: the variation-point label, option relationship, default key and member key.
- `connections`: relationship type → style (`wire`, `coax`, `mate`, `tap`) and attach point.
- `conductors`: the conductor-node label, its end relationships and the key that orders the ends.
- `junctions`: which parts are drawn as KiCad junctions (by default, any node whose `type` says splice).
- `declaredNets` and `buses`: net and bus labels, membership relationships and the role key.
- `netMerges`, `joins`, `interfaces`, `annotations`, and `wireGroups` (harness key, membership
  relationships and role key, bundle keys, and `pairIf`, the rule for a twisted-pair group).
- `text`: name, id, ref, signal, pin number, function, capability, direction and type keys.
- `placement`: order keys, side keys (`header_side`, `board_side`, `side`), pin order keys,
  millimetre position keys and size keys.
- `wireColors`: colour names → hex, and codes → names.

To handle a new vocabulary (for example, a graph that uses `Component`, `Net` and `ON_NET`), add
keys to these lists rather than changing code.

## What the checks enforce

`tools/check.js` runs `src/verify.js`. Errors must be zero; warnings are reviewed. The checks
fall into two groups.

**The graph's own vocabulary** (when it embeds one):
- `term-defined`: every label, relationship type and property is defined.
- `term-usage`: each is used as defined (ends, carriers, value types, value sets, required).

**Fidelity to the graph:**
- `pin-once`: every contact is drawn once.
- `pin-number`: the numbers shown are the graph's.
- `connector-order`: a connector's positions sit contiguous, on one edge; in number order in the
  physical layout, and wherever the connector mates with a library connector symbol.
- `pair-adjacent`: in the logical layout, a connector's pins of one bus or one twisted pair stand
  side by side (warning).
- `mate-order` and `mate-direct`: seated plugs line up and touch.
- `connector-symbol`: the symbol matches the connector's gender and position count.
- `connector-shown`: a part with several connectors names each one.
- `pin-in-connector`: every physical pin belongs to a connector.
- `connector-whole`: an unnumbered connector's pins still share one unbroken edge.
- `location-claim`: in the physical layout, a pin the graph doesn't locate is marked so.
- `physical-order`: pins recorded higher on the part are drawn higher.
- `no-splice`: conductors meet only at pins or at a junction the graph states. The separator
  moves a run laid on another conductor's run of its own net, as it moves one too near another net.
- `shared-terminal` (warning): conductors on one terminal (ring terminals on a ground stud) leave it
  along its one lead and part within 100 mil of it.
- `net-declared`: a declared net is one connected net, and no two declared nets are connected.

**KiCad conventions:**
- `pin-grid`: connection points sit on the 100 mil grid.
- `wire-endpoint`: every wire ends exactly on its connection point.
- `false-connection`: no wire passes over another net's connection point.
- `net-overlap`: no two nets share a stretch of line.
- `wire-orthogonal`: wires run horizontally and vertically.
- `junction-net`: a junction dot joins one net only.
- `wire-through-body`: no wire crosses a symbol body.
- `text-clear`: names, references and captions stay off wires, parts and each other.
- `part-overlap`: no two symbols overlap.
- `pin-number-unique` (warning): no number appears twice on one symbol. It is expected on boards
  whose connectors each number from 1.
- `collinear-gap` and `side-by-side`: two nets never read as one wire; a cable's or twisted
  pair's route never lies on or crowds another wire or cable.

`tools/check.js` also renders every layout: `pair-drawn` fails when a twisted pair cannot be
drawn twisted and would show as a plain bus line. A pair whose route turns close to an end is
drawn narrower so its conductors still reach their strands before the turn. Several conductors
on one pin fan out within 80 mil of it, inside the pin pitch, so neighbouring pins' fans never meet.

`tools/visual_check.py` adds rendered checks: `text-on-part`, `text-on-text`, `text-on-wire`,
`label-on-part`, `label-on-wire`, `label-ambiguous`, `label-cuts-wire`, `leader-on-pin` and
`part-geometry`. A graph with twisted pairs is checked in both views, pairs routed together and
apart.

## Viewer features (for the user)

- **Display options:** Drawing and Tables views, "Physical pin locations", "Wire colours",
  "Unconnected pins", "Net labels", "Wire tags", "Twisted pairs" (when the graph has any), and
  search.
- **Highlighting:** hovering marks only the conductor under the pointer. Clicking a wire (a
  strand of a twisted pair included) lights that conductor and its two contacts; clicking it again
  lights its net, then the cable or pair it runs in, then the bus its net belongs to, skipping any
  step that lights nothing more; one more click clears. Clicking a pin or splice joint lights its
  whole net; a bus (from the inspector or the overview) lights every net it carries.
- **One net or bus alone:** double-click a wire, pin, splice joint or twisted pair to redraw only
  what it carries, laid out afresh and compact, with every check still run. A line of a bus (a
  CAN_H or CAN_L conductor, or their twisted pair) shows the whole bus, both nets together; any
  other conductor shows its net. A single click opens a small card at the pointer with the same
  choice, "Highlight" (the bus lit in place, the rest of the drawing kept) and "Show this line
  only"; the inspector has the same links. A bar at the top names what is shown;
  "Back to …" (the chosen view) or Esc returns. Parts keep only the pins on the shown nets; a free connector
  keeps all its positions, and pins of other nets are named by their net and marked "not shown".
- **Configuration:** a variation point whose `tier` (the profile's `variants.tierKeys`) is
  `primary` (body, engine, transmission) sits in the toolbar; the rest are in the Options dialog,
  filtered by name, marked when changed or when they change nothing in the view, and applied
  together so a large view is drawn once. A graph without tiers shows, in the toolbar, the
  choices that change the view.
- **Views:** the View chooser draws one class of connection across the whole graph (Power,
  Ground, Comms, Signals, from `units.classes`), one or more systems ticked together, or the
  whole graph, each listed with its wire count and an estimated drawing time. The profile's
  `views.open` names the first view (`{"class": "Comms"}`): a large graph never opens whole.
- **Systems:** one model, never divided by how its sources are organised. Conductors record the
  systems they serve in a list property (`systems`; a paginated source's page can be kept in
  `source_page`), and the
  profile's `sheets` entry names it, with its `label`. Each system is a view, as KiCad offers
  hierarchical sheets of one design, and several can be drawn together. A system view keeps its
  conductors and what they end on; a connector that records `populated_positions` keeps all of
  them. Nets continue into other systems, so the check that a declared net is one connected
  piece is relaxed there. A system that exists only in another configuration (one engine's system
  while another engine is chosen) opens in that configuration.
- **Drawing a view:** a loading card names the view and its size, marks each stage (reading,
  choosing, placing parts, routing, separating side-by-side runs, drawing), and counts the time
  against an estimate from this browser's own pace; Stop keeps the view that was showing. ELK
  runs in a worker made from the page's own copy of elkjs where the page allows workers, so the
  page stays live and Stop takes effect at once; elsewhere it runs in the page. The drawing is
  shown first and its checks follow. Layout separation and the checks index runs by area, so
  their cost grows with the drawing, not with its square.
- **Units:** the Unit picker (and "All its connections" on any part in the inspector) draws every
  net that reaches one part, whole across all systems, optionally one class of them. The
  profile's `units.classes` test each net's declared properties (`signal_type` `ENERGY`,
  `GROUND`, `BUS`) in order: Power, Ground, Comms (also any net of a Bus), and Signals for the
  rest; `units.exclude` keeps diagram boundaries out of the list.
- **Combining sources:** gather everything first, then join what the sources share before
  modelling: the same splice reached by different branches in two sources (two shared contacts,
  or one contact that holds a single conductor in the same colour), a stud in one source that is
  a numbered contact in another, a conductor one system hands to another that is that system's
  conductor from the same contact. Where two sources still disagree on a contact's routing, keep
  both and say so in each conductor's `notes`. A source specific to one configuration governs the
  contacts it covers for that configuration.
- **Tables:** pins and IO, functions, connections, nets and connectors. Each table can be sorted
  and filtered, and copied as CSV.
- **Side panel:**
  - Inspect, for any part, pin or wire, with its source lines and the definition of its label.
  - Model: the dataset, its sources and methods, and a searchable glossary of the vocabulary.
  - Source: the graph can be edited live; "Apply revision…" appends a MATCH/SET revision script;
    "Copy page with this graph"; "Copy SVG".
  - Rules: edit the profile live.
  - Symbols: what is drawn with which KiCad symbol.
  - Issues: the checks, live.
- **Offline use:** the standalone HTML carries elkjs inline, so it works offline and on tablets.

## Known limits

- Two-row connectors (IDC, 2x5 SWD) are drawn as one run in position order. Model them with
  `positions` and real `number` values; skipped positions keep their pitch.
- In the logical layout, a box's pin sides and pin order come from connectivity. Use the physical
  layout to see board sides and numbered order.
- Gender glyphs are drawn on box (board) pins and by the gendered library symbols. The generic
  `Conn_01xNN` symbols carry no gender, so state `user_gender` so the gendered symbol is chosen.
