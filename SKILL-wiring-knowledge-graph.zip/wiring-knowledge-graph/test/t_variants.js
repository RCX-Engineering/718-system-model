// Configurations: defaults come from the graph, a selection swaps what is drawn, and a
// variant nobody offers is reported.
const C = require('../src/cypher.js'), K = require('../src/kicad.js'), S = require('../src/scene.js');
const fs = require('fs');
const lib = new K.Library();
for (const f of ['Connector_Generic', 'Connector', 'Device', 'power']) lib.addText(f, fs.readFileSync('lib/' + f + '.kicad_sym', 'utf8'));
const profile = JSON.parse(fs.readFileSync('src/profile.json', 'utf8'));
const src = fs.readFileSync('test/rcx.cypher', 'utf8');
let bad = 0;
const expect = (cond, msg) => { console.log(`${cond ? 'ok  ' : 'FAIL'} ${msg}`); if (!cond) bad++; };
const names = (sc) => [...sc.symbols.values()].map((s) => s.name);

const { graph } = C.load(src);
const def = S.buildScene(graph, profile, lib, {});
const pts = Object.fromEntries(def.variationPoints.map((p) => [p.id, p]));
expect(pts.vp_vehicle_bus?.selected === 'var_718_chassis', `default vehicle bus is the 718 chassis bus (${pts.vp_vehicle_bus?.selected})`);
expect(pts.vp_usb_c?.selected === 'var_usb_power', `default USB-C connection is the USB power source (${pts.vp_usb_c?.selected})`);
expect(names(def).includes('Chassis CAN') && !names(def).includes('Drive CAN') && !names(def).includes('CAN Drive'), 'only the chassis bus is drawn by default');
expect(names(def).includes('USB power source') && !names(def).some((n) => /Development PC/.test(n)), 'the USB power source replaces the PC by default');

const frs = S.buildScene(graph, profile, lib, { variants: { vp_vehicle_bus: 'var_frs_obd', vp_usb_c: 'var_usb_pc' } });
expect(names(frs).includes('CAN at OBD-II port') && !names(frs).some((n) => /PosiTap/.test(n)), 'FR-S drops the PosiTaps and draws the OBD-II bus');
expect(names(frs).some((n) => /Development PC/.test(n)), 'programming configuration draws the PC');
const taps = frs.connections.filter((c) => c.type === 'TAPS_VEHICLE_CAN').length;
expect(taps === 0, `no vehicle taps in the FR-S configuration (${taps})`);

const d987 = S.buildScene(graph, profile, lib, { variants: { vp_vehicle_bus: 'var_987_2_drive' } });
const t987 = d987.connections.filter((c) => c.type === 'TAPS_VEHICLE_CAN');
expect(t987.length === 2 && t987.every((c) => /YEL|BLK/.test(c.props.vehicle_wire_color)), '987.2 drive taps carry their recorded colours');
const chassis = def.connections.filter((c) => c.type === 'TAPS_VEHICLE_CAN');
const col = (sig) => chassis.find((c) => c.props.signal === sig)?.props.vehicle_wire_color;
expect(col('CAN-H') === 'ORG/VIO' && col('CAN-L') === 'ORG/BRN', `default 718 chassis taps: CAN-H ${col('CAN-H')}, CAN-L ${col('CAN-L')}`);
const plug = [...frs.symbols.values()].find((s) => /OBD-II lead plug/.test(s.name));
const nums = plug ? [...plug.contacts.values()].filter((c) => c.libPin).map((c) => `${c.name}=${c.libPin.number}`).sort().join(', ') : '';
expect(plug && plug.kind === 'lib' && nums === 'CAN-H=6, CAN-L=14', `OBD-II plug drawn with two pins numbered from the graph (${nums})`);

const none = S.buildScene(graph, profile, lib, { variants: { vp_vehicle_bus: 'var_no_vehicle' } });
expect(names(none).includes('CAN pigtail Dupont male plug') && !names(none).some((n) => /PosiTap|OBD|Porsche|Scion|CAN at|Chassis CAN|Drive CAN/.test(n)), 'no vehicle: the pigtail ends free and no vehicle is drawn');
const libOf = (sc, re) => [...sc.symbols.values()].find((s) => re.test(s.name))?.libId;
expect(/_Male$/.test(libOf(def, /CAN pigtail Dupont male plug/) || '') && /_Female$/.test(libOf(def, /CAN pigtail Dupont female/) || '') && /_Female$/.test(libOf(def, /PosiTap lead Dupont female/) || ''),
  `CAN pigtail male at the vehicle end, female on the transceiver; vehicle lead female (${libOf(def, /pigtail Dupont male/)}, ${libOf(def, /pigtail Dupont female/)}, ${libOf(def, /PosiTap lead/)})`);
const genderOn = (sc, part, pin) => [...[...sc.symbols.values()].find((s) => s.name === part).contacts.values()].find((c) => c.name === pin)?.section?.gender;
expect(['ESP32-S3-LCD-1.47B|GP4', 'LG290P RTK GNSS module|TX', 'SN65HVD230 CAN transceiver module|VCC', 'SN65HVD230 CAN transceiver module|CANL parallel header pin'].every((k) => genderOn(def, ...k.split('|')) === 'male'), 'ESP32, LG290P and SN65 header pins are male');
const pinsShown = (opts) => [...S.buildScene(graph, profile, lib, opts).symbols.values()].reduce((n, s) => n + [...s.contacts.values()].filter((c) => c.visible).length, 0);
expect(pinsShown({ physical: true }) < pinsShown({ physical: true, showUnconnected: true }), 'the unconnected-pins option hides and shows pins in the physical layout too');

// a part fitted only in another configuration takes its connector and pins with it
const fitted = C.load(src + `
CREATE (:Device {id: 'xpart', name: 'Option module', variants: ['var_frs_obd']})
CREATE (:Connector {id: 'xpart_conn', name: 'Option module connector'})
CREATE (:Pin {id: 'xpart_1', name: 'SIG', number: '1'})
MATCH (a {id: 'xpart'}), (b {id: 'xpart_conn'}) CREATE (a)-[:HAS_CONNECTOR]->(b)
MATCH (a {id: 'xpart_conn'}), (b {id: 'xpart_1'}) CREATE (a)-[:HAS_PIN]->(b)
`).graph;
const offCfg = S.configure(fitted, profile, {}).graph;
const onCfg = S.configure(fitted, profile, { vp_vehicle_bus: 'var_frs_obd' }).graph;
const ids = (g) => new Set([...g.nodes.values()].map((n) => n.props.id));
expect(!ids(offCfg).has('xpart_conn') && !ids(offCfg).has('xpart_1') && ids(onCfg).has('xpart_conn') && ids(onCfg).has('xpart_1'),
  'a part left out of the configuration takes its connector and pins with it');

const bogus = C.load(src + "\nCREATE (x:Device {id: 'x', name: 'Orphan', variants: ['var_nowhere']})\n").graph;
const bs = S.buildScene(bogus, profile, lib, {});
expect(bs.notes.some((n) => /var_nowhere/.test(n.message)), 'an unknown variant is reported');
process.exit(bad ? 1 : 0);
