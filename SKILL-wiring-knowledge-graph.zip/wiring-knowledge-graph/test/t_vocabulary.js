// A graph that embeds its vocabulary: metadata nodes stay off the drawing, the model is read back,
// names used as defined pass the checks, and each kind of misuse is reported. The same graph
// converts to RDF with its own IRIs.
const path = require('path');
const fs = require('fs');
const { execFileSync } = require('child_process');
const ROOT = path.resolve(__dirname, '..');
const C = require(path.join(ROOT, 'src/cypher.js'));
const K = require(path.join(ROOT, 'src/kicad.js'));
const S = require(path.join(ROOT, 'src/scene.js'));
const L = require(path.join(ROOT, 'src/layout.js'));
const V = require(path.join(ROOT, 'src/verify.js'));
const R = require(path.join(ROOT, 'tools/cypher2rdf.js'));
const ELK = require(path.join(ROOT, 'vendor/package/lib/elk.bundled.js'));

const profile = JSON.parse(fs.readFileSync(path.join(ROOT, 'src/profile.json'), 'utf8'));
const lib = new K.Library();
for (const f of fs.readdirSync(path.join(ROOT, 'lib')).filter((f) => f.endsWith('.kicad_sym')).sort()) lib.addText(path.basename(f, '.kicad_sym'), fs.readFileSync(path.join(ROOT, 'lib', f), 'utf8'));
const measure = (t, size) => String(t).length * size * 0.6;
const vocabulary = execFileSync('python3', [path.join(ROOT, 'tools/schema_terms.py'), path.join(ROOT, 'schema/wiring_kg.yaml')], { encoding: 'utf8' });

// Two modules joined by one CAN pair, described by a Dataset that conforms to the vocabulary.
const part = (id, name) => `
CREATE (:Component {id: '${id}', name: '${name}'})
CREATE (:Connector {id: '${id}_c', name: '${name} connector'})
CREATE (:Pin {id: '${id}_h', connector: '${id}_c', name: 'CAN HIGH', number: '1', electrical_type: 'passive'})
CREATE (:Pin {id: '${id}_l', connector: '${id}_c', name: 'CAN LOW', number: '2', electrical_type: 'passive'})
MATCH (a {id: '${id}'}), (b {id: '${id}_c'}) CREATE (a)-[:HAS_CONNECTOR {}]->(b)
MATCH (a {id: '${id}_c'}), (b {id: '${id}_h'}) CREATE (a)-[:HAS_PIN {}]->(b)
MATCH (a {id: '${id}_c'}), (b {id: '${id}_l'}) CREATE (a)-[:HAS_PIN {}]->(b)`;
const wire = (id, from, to, net, color) => `
CREATE (:Wire {id: '${id}', color: '${color}'})
MATCH (w {id: '${id}'}), (p {id: '${from}'}) CREATE (w)-[:TERMINATES_AT {position_on_wire: 0.0}]->(p)
MATCH (w {id: '${id}'}), (p {id: '${to}'}) CREATE (w)-[:TERMINATES_AT {position_on_wire: 1.0}]->(p)
MATCH (w {id: '${id}'}), (n {id: '${net}'}) CREATE (w)-[:IN_NET {}]->(n)`;
const base = [
  "CREATE (:Dataset {id: 'dataset', name: 'Vocabulary test', base_iri: 'https://example.org/wiring-kg/data/test/'})",
  "CREATE (:Method {id: 'method_hand', name: 'Written by hand', description: 'Typed from a sketch.'})",
  "MATCH (a {id: 'dataset'}), (b {id: 'method_hand'}) CREATE (a)-[:WAS_GENERATED_BY {}]->(b)",
  part('ma', 'Module A'), part('mb', 'Module B'),
  "CREATE (:Net {id: 'n_h', name: 'CAN TEST HIGH', signal_type: 'BUS'})",
  "CREATE (:Net {id: 'n_l', name: 'CAN TEST LOW', signal_type: 'BUS'})",
  "CREATE (:Bus {id: 'bus_t', name: 'CAN TEST', protocol: 'CAN'})",
  "MATCH (a {id: 'bus_t'}), (b {id: 'n_h'}) CREATE (a)-[:HAS_MEMBER {role: 'CAN_H'}]->(b)",
  "MATCH (a {id: 'bus_t'}), (b {id: 'n_l'}) CREATE (a)-[:HAS_MEMBER {role: 'CAN_L'}]->(b)",
  wire('w1', 'ma_h', 'mb_h', 'n_h', 'ORG/GRN'), wire('w2', 'ma_l', 'mb_l', 'n_l', 'ORG/BRN'),
  "CREATE (:WiringGroup {id: 'tp1', name: 'CAN TEST', type: 'twisted-pair'})",
  "MATCH (g {id: 'tp1'}), (w {id: 'w1'}) CREATE (g)-[:ASSIGNED_WIRE {role: 'CAN_H'}]->(w)",
  "MATCH (g {id: 'tp1'}), (w {id: 'w2'}) CREATE (g)-[:ASSIGNED_WIRE {role: 'CAN_L'}]->(w)",
  vocabulary,
  "MATCH (a {id: 'dataset'}), (b {id: 'vocabulary'}) CREATE (a)-[:CONFORMS_TO {}]->(b)",
].join('\n');

let failed = 0;
const ok = (cond, what) => { console.log(`${cond ? 'ok  ' : 'FAIL'} ${what}`); if (!cond) failed++; };
const checksOf = async (text) => {
  const { graph } = C.load(text);
  const sc = S.buildScene(graph, profile, lib, {});
  const out = await L.layoutScene(sc, new ELK(), { measure, physical: false });
  return { sc, findings: V.run(sc, out).findings };
};

(async () => {
  const { sc, findings } = await checksOf(base);
  ok(sc.model && sc.model.dataset && sc.model.scheme, 'the model is read: dataset and vocabulary');
  ok(sc.model.terms.labels.has('Wire') && sc.model.terms.rels.has('TERMINATES_AT') && sc.model.terms.props.has('position_on_wire'), 'labels, relationship types and properties are defined');
  ok(![...sc.symbols.values()].some((s) => ['Dataset', 'Method', 'Term', 'ConceptScheme'].some((l) => s.node.labels.includes(l))), 'metadata nodes are not drawn');
  ok(sc.connections.filter((c) => c.node).length === 2, 'the wiring is drawn as before');
  const vocab = findings.filter((f) => f.check.startsWith('term-'));
  ok(vocab.length === 0, `names used as defined pass (${vocab.map((f) => f.message).join('; ') || 'no findings'})`);

  const cases = [
    ['an undefined label', base + "\nCREATE (:Gizmo {id: 'g1', name: 'Gizmo'})", 'term-defined', /Label Gizmo/],
    ['an undefined property', base.replace("{id: 'w1', color: 'ORG/GRN'}", "{id: 'w1', color: 'ORG/GRN', length_m: 2}"), 'term-defined', /Property length_m/],
    ['a relationship between the wrong labels', base + "\nMATCH (w {id: 'w1'}), (n {id: 'n_l'}) CREATE (w)-[:TERMINATES_AT {position_on_wire: 0.5}]->(n)", 'term-usage', /may point to Pin or Splice/],
    ['a value outside its value set', base.replace("{role: 'CAN_L'}]->(b)", "{role: 'CAN_X'}]->(b)"), 'term-usage', /CAN_X is not in the value set SignalRole/],
    ['a missing required property', base.replace("[:TERMINATES_AT {position_on_wire: 1.0}]", "[:TERMINATES_AT {}]"), 'term-usage', /missing required property position_on_wire/],
    ['a value outside its range', base.replace('position_on_wire: 1.0', 'position_on_wire: 1.5'), 'term-usage', /position_on_wire value 1.5 is outside 0 to 1/],
    ['a value not matching its pattern', base.replace("color: 'ORG/GRN'", "color: 'ORG-GRN'"), 'term-usage', /color value ORG-GRN does not match/],
    ['a value of the wrong type', base.replace("number: '1'", 'number: 1'), 'term-usage', /number on Pin should be text/],
    ['a property on a label that does not carry it', base.replace("{id: 'n_h', name: 'CAN TEST HIGH', signal_type: 'BUS'}", "{id: 'n_h', name: 'CAN TEST HIGH', signal_type: 'BUS', color: 'RED'}"), 'term-usage', /color is not defined for Net/],
  ];
  for (const [what, text, check, re] of cases) {
    const { findings: fs2 } = await checksOf(text);
    ok(fs2.some((f) => f.check === check && re.test(f.message)), `${what} is reported`);
  }

  // Written in place, the block holds only the names the graph uses, and rewriting it is stable.
  const os = require('os');
  const tmp = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'vocab-')), 'g.cypher');
  fs.writeFileSync(tmp, base.replace(vocabulary, '').replace("\nMATCH (a {id: 'dataset'}), (b {id: 'vocabulary'}) CREATE (a)-[:CONFORMS_TO {}]->(b)", ''));
  const write = () => execFileSync('python3', [path.join(ROOT, 'tools/schema_terms.py'), path.join(ROOT, 'schema/wiring_kg.yaml'), '--write', tmp]);
  write();
  const once = fs.readFileSync(tmp, 'utf8');
  write();
  ok(fs.readFileSync(tmp, 'utf8') === once, 'rewriting the vocabulary block in place is stable');
  const w = await checksOf(once);
  ok(w.sc.model.terms.labels.has('Wire') && !w.sc.model.terms.labels.has('Enclosure') && !w.sc.model.terms.props.has('gauge'), 'only the names the graph uses are embedded');
  ok(!w.findings.some((f) => f.check.startsWith('term-')), 'the written block defines everything the graph uses, CONFORMS_TO included');
  ok(w.sc.model.scheme.props.reading_guide && (w.sc.model.scheme.props.status_meanings || []).length === 3, 'the scheme carries its reading guide and status meanings');

  const ttl = R.convert(base);
  ok(/<https:\/\/example\.org\/wiring-kg\/data\/test\/w1>\s+a <https:\/\/example\.org\/wiring-kg\/Wire>/.test(ttl), 'converts to RDF under the dataset base IRI, typed with the vocabulary IRIs');
  ok(/<http:\/\/www\.w3\.org\/2004\/02\/skos\/core#closeMatch> <https:\/\/ecad-wiki\.prostep\.org/.test(ttl), 'mappings to standards become IRIs in RDF');
  let threw = false;
  try { R.convert(base + "\nCREATE (:Gizmo {id: 'g1'})"); } catch (e) { threw = /label Gizmo/.test(e.message); }
  ok(threw, 'conversion refuses a name the vocabulary does not define');
  console.log(failed ? `${failed} failed` : 'all passed');
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(2); });
