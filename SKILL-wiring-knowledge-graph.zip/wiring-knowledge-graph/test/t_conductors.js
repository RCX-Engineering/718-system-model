// Conductors as nodes: Wire nodes terminating on pins and splices, twisted-pair wiring groups,
// declared nets and buses. Builds a three-module CAN bus with one splice pair and checks the scene,
// the drawing checks, pin order in both layouts, and that a mis-declared net is reported.
const path = require('path');
const fs = require('fs');
const ROOT = path.resolve(__dirname, '..');
const C = require(path.join(ROOT, 'src/cypher.js'));
const K = require(path.join(ROOT, 'src/kicad.js'));
const S = require(path.join(ROOT, 'src/scene.js'));
const L = require(path.join(ROOT, 'src/layout.js'));
const V = require(path.join(ROOT, 'src/verify.js'));
const ELK = require(path.join(ROOT, 'vendor/package/lib/elk.bundled.js'));

const profile = JSON.parse(fs.readFileSync(path.join(ROOT, 'src/profile.json'), 'utf8'));
const lib = new K.Library();
for (const f of fs.readdirSync(path.join(ROOT, 'lib')).filter((f) => f.endsWith('.kicad_sym')).sort()) lib.addText(path.basename(f, '.kicad_sym'), fs.readFileSync(path.join(ROOT, 'lib', f), 'utf8'));
const measure = (t, size) => String(t).length * size * 0.6;

// Three modules on one CAN bus: A reaches a splice pair, which feeds B and C.
// Module A numbers its pins CAN HIGH 1, TERM 30 2, CAN LOW 3: the physical layout keeps 1, 2, 3;
// the logical layout draws CAN HIGH and CAN LOW side by side.
const nodePins = (id, name, [h, l, p]) => `
CREATE (:Component {id: '${id}', name: '${name}'})
CREATE (:Connector {id: '${id}_c', name: '${name} connector', type: 'vehicle harness connector'})
CREATE (:Pin {id: '${id}_h', connector: '${id}_c', name: 'CAN HIGH', number: ${h}, electrical_type: 'passive'})
CREATE (:Pin {id: '${id}_l', connector: '${id}_c', name: 'CAN LOW', number: ${l}, electrical_type: 'passive'})
CREATE (:Pin {id: '${id}_p', connector: '${id}_c', name: 'TERM 30', number: ${p}, electrical_type: 'passive'})
MATCH (a {id: '${id}'}), (b {id: '${id}_c'}) CREATE (a)-[:HAS_CONNECTOR {}]->(b)`;
const wire = (id, color, from, to, net) => `
CREATE (:Wire {id: '${id}', color: '${color}'})
MATCH (w {id: '${id}'}), (p {id: '${from}'}) CREATE (w)-[:TERMINATES_AT {position_on_wire: 0.0}]->(p)
MATCH (w {id: '${id}'}), (p {id: '${to}'}) CREATE (w)-[:TERMINATES_AT {position_on_wire: 1.0}]->(p)
MATCH (w {id: '${id}'}), (n {id: '${net}'}) CREATE (w)-[:IN_NET {}]->(n)`;
const pair = (id, h, l) => `
CREATE (:WiringGroup {id: '${id}', name: 'CAN test', type: 'twisted-pair'})
MATCH (g {id: '${id}'}), (w {id: '${h}'}) CREATE (g)-[:ASSIGNED_WIRE {role: 'CAN_H'}]->(w)
MATCH (g {id: '${id}'}), (w {id: '${l}'}) CREATE (g)-[:ASSIGNED_WIRE {role: 'CAN_L'}]->(w)`;

const graphText = (lowNetOfW4) => [
  nodePins('ma', 'Module A', [1, 3, 2]), nodePins('mb', 'Module B', [1, 2, 3]), nodePins('mc', 'Module C', [1, 2, 3]),
  "CREATE (:Splice {id: 'sh', name: 'Splice on CAN test high', type: 'harness splice'})",
  "CREATE (:Splice {id: 'sl', name: 'Splice on CAN test low', type: 'harness splice'})",
  "CREATE (:Net {id: 'n_h', name: 'CAN test high'})",
  "CREATE (:Net {id: 'n_l', name: 'CAN test low'})",
  "CREATE (:Net {id: 'n_p', name: 'TERM 30'})",
  "CREATE (:Bus {id: 'bus_t', name: 'CAN test', protocol: 'CAN'})",
  "MATCH (a {id: 'bus_t'}), (b {id: 'n_h'}) CREATE (a)-[:HAS_MEMBER {role: 'CAN_H'}]->(b)",
  "MATCH (a {id: 'bus_t'}), (b {id: 'n_l'}) CREATE (a)-[:HAS_MEMBER {role: 'CAN_L'}]->(b)",
  wire('w1', 'ORG/GRN', 'ma_h', 'sh', 'n_h'), wire('w2', 'ORG/BRN', 'ma_l', 'sl', 'n_l'),
  wire('w3', 'ORG/GRN', 'sh', 'mb_h', 'n_h'), wire('w4', 'ORG/BRN', 'sl', 'mb_l', lowNetOfW4),
  wire('w5', 'ORG/GRN', 'sh', 'mc_h', 'n_h'), wire('w6', 'ORG/BRN', 'sl', 'mc_l', 'n_l'),
  wire('w7', 'RED', 'ma_p', 'mb_p', 'n_p'),
  pair('tp1', 'w1', 'w2'), pair('tp2', 'w3', 'w4'), pair('tp3', 'w5', 'w6'),
  'MATCH (c:Connector), (p:Pin) WHERE p.connector = c.id CREATE (c)-[:HAS_PIN {}]->(p)',
].join('\n');

let failed = 0;
const ok = (cond, what) => { console.log(`${cond ? 'ok  ' : 'FAIL'} ${what}`); if (!cond) failed++; };

(async () => {
  const { graph, diagnostics } = C.load(graphText('n_l'));
  ok(!(diagnostics || []).some((d) => d.level === 'error'), 'the graph parses');
  const sc = S.buildScene(graph, profile, lib, {});
  const conductors = sc.connections.filter((c) => c.node);
  ok(conductors.length === 7, 'each Wire node is one conductor');
  ok(conductors.every((c) => c.color), 'conductors take their colour from the Wire node');
  const junctions = [...sc.symbols.values()].filter((s) => s.junction);
  ok(junctions.length === 1 && (junctions[0].alsoNodes || []).length === 1, 'the CAN-H and CAN-L splices are drawn as one junction, and stay two nodes');
  const joints = new Set([...junctions[0].contacts.values()].map((c) => c.joint));
  ok(joints.has('CAN_H') && joints.has('CAN_L') && joints.size === 2, 'the junction has a CAN_H joint and a CAN_L joint');
  const high = [...sc.nets.values()].find((n) => n.name === 'CAN test high');
  ok(high && high.connections.length === 3, 'the declared net names the net its conductors form');
  ok(sc.buses.length === 1 && sc.buses[0].members.map((m) => m.role).sort().join() === 'CAN_H,CAN_L', 'the bus carries a CAN_H and a CAN_L net');
  ok(sc.bundles.filter((b) => b.style === 'pair').length === 3, 'each twisted-pair group is routed as one pair');
  const out = await L.layoutScene(sc, new ELK(), { measure, physical: false });
  const { findings } = V.run(sc, out);
  ok(!findings.some((f) => f.level === 'error'), `the drawing checks pass (${findings.filter((f) => f.level === 'error').map((f) => f.message).join('; ') || 'no errors'})`);
  ok(!findings.some((f) => f.check === 'pair-adjacent'), 'no pair is drawn apart in the logical layout');

  // Pin order along Module A's edge, as drawn.
  const orderOf = (layout) => {
    const s = layout.symbols.get([...sc.symbols.values()].find((x) => x.name === 'Module A').id);
    const pins = s.geo.pins.filter((p) => p.contact);
    const along = (p) => (p.side === 'WEST' || p.side === 'EAST' ? p.tip[1] : p.tip[0]);
    return pins.sort((a, b) => along(a) - along(b)).map((p) => +p.contact.number);
  };
  const logical = orderOf(out);
  ok(Math.abs(logical.indexOf(1) - logical.indexOf(3)) === 1, `logical layout: CAN HIGH (1) and CAN LOW (3) side by side (${logical.join(', ')})`);
  ok(logical.indexOf(1) < logical.indexOf(3), 'logical layout: CAN_H before CAN_L, in the bus member order');
  const phys = S.buildScene(graph, profile, lib, { physical: true });
  const physOut = await L.layoutScene(phys, new ELK(), { measure, physical: true });
  const physFindings = V.run(phys, physOut).findings;
  ok(!physFindings.some((f) => f.level === 'error'), 'the drawing checks pass in the physical layout');
  const physOrder = (() => {
    const s = physOut.symbols.get([...phys.symbols.values()].find((x) => x.name === 'Module A').id);
    const along = (p) => (p.side === 'WEST' || p.side === 'EAST' ? p.tip[1] : p.tip[0]);
    return s.geo.pins.filter((p) => p.contact).sort((a, b) => along(a) - along(b)).map((p) => +p.contact.number);
  })();
  ok(physOrder.join() === '1,2,3', `physical layout: pins in number order (${physOrder.join(', ')})`);

  const bad = S.buildScene(C.load(graphText('n_h')).graph, profile, lib, {});
  const badOut = await L.layoutScene(bad, new ELK(), { measure, physical: false });
  const badFindings = V.run(bad, badOut).findings.filter((f) => f.check === 'net-declared');
  ok(badFindings.length >= 1, 'a conductor declared on the wrong net is reported');
  console.log(failed ? `${failed} failed` : 'all passed');
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(2); });
