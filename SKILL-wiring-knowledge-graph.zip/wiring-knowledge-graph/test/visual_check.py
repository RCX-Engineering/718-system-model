"""Rendered-drawing checks: measure what the browser actually drew.

The layout checks (t_verify.js) work from estimated text widths. This pass loads the
built page, reads real bounding boxes from the SVG, and reports:
  text-on-part   text belonging to one part lying over another part's body or pins
  text-on-text   text of two different parts overlapping
  text-on-wire   part text crossed by a wire
  label-on-part  a net label, bus label or wire tag lying over a part
  label-on-wire  a label covering a wire of a different net
  label-ambiguous a label nearer another net's wire than its own
  label-cuts-wire a net label drawn over another run of its own net
  leader-on-pin  an annotation leader passing through a pin end
Each layout (logical, physical) is checked, and an annotated screenshot marks every hit.

Usage: python3 test/visual_check.py              (exit status 1 when anything is reported)
       python3 test/visual_check.py --selftest   (moves one part's name onto another and expects a report)
"""
import asyncio, json, sys
sys.path.insert(0, "test")
from shot import route, PAGE
from playwright.async_api import async_playwright

PROBE = r"""
() => {
  const svg = document.querySelector('#sheet svg');
  const boxOf = (el) => { const b = el.getBBox(); const m = el.getCTM(), r = svg.getCTM().inverse().multiply(m);
    const pts = [[b.x, b.y], [b.x + b.width, b.y], [b.x, b.y + b.height], [b.x + b.width, b.y + b.height]].map(([x, y]) => [r.a * x + r.c * y + r.e, r.b * x + r.d * y + r.f]);
    const xs = pts.map(p => p[0]), ys = pts.map(p => p[1]);
    return { x: Math.min(...xs), y: Math.min(...ys), w: Math.max(...xs) - Math.min(...xs), h: Math.max(...ys) - Math.min(...ys) }; };
  const shrink = (r, d) => ({ x: r.x + d, y: r.y + d, w: Math.max(0, r.w - 2 * d), h: Math.max(0, r.h - 2 * d) });
  const hit = (a, b) => a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;
  const texts = [], parts = [];
  for (const sym of svg.querySelectorAll('.symbol')) {
    const id = sym.dataset.sym;
    const name = sym.querySelector('.val')?.textContent || id;
    for (const t of sym.querySelectorAll('.val, .ref, .pin-cap, .sec-cap, .pin-name, .pin-num')) if (t.textContent.trim()) texts.push({ id, name, cls: t.getAttribute('class'), text: t.textContent, r: shrink(boxOf(t), 4) });
    const shapes = [...sym.querySelectorAll('.body, .lib-shape, .pin-line')];
    if (shapes.length) {
      const bs = shapes.map(boxOf);
      const x1 = Math.min(...bs.map(b => b.x)), y1 = Math.min(...bs.map(b => b.y)), x2 = Math.max(...bs.map(b => b.x + b.w)), y2 = Math.max(...bs.map(b => b.y + b.h));
      parts.push({ id, name, r: { x: x1, y: y1, w: x2 - x1, h: y2 - y1 } });
    }
  }
  // Wires: the visible strokes of every connection and bus, as straight segments.
  const segs = [];
  for (const p of svg.querySelectorAll('.conn path:not(.hit):not(.trace), .bus .bus-line')) {
    const d = p.getAttribute('d') || '';
    const nums = [...d.matchAll(/[ML]\s*(-?[\d.]+)[ ,](-?[\d.]+)/g)].map(m => [+m[1], +m[2]]);
    for (let i = 1; i < nums.length; i++) segs.push({ a: nums[i - 1], b: nums[i], net: p.closest('[data-net]')?.dataset.net || p.closest('[data-bundle]')?.dataset.bundle || '' });
  }
  const crosses = (s, r) => { // Liang-Barsky
    let t0 = 0, t1 = 1; const dx = s.b[0] - s.a[0], dy = s.b[1] - s.a[1];
    for (const [p, q] of [[-dx, s.a[0] - r.x], [dx, r.x + r.w - s.a[0]], [-dy, s.a[1] - r.y], [dy, r.y + r.h - s.a[1]]]) {
      if (p === 0) { if (q < 0) return false; continue; }
      const t = q / p; if (p < 0) { if (t > t1) return false; if (t > t0) t0 = t; } else { if (t < t0) return false; if (t < t1) t1 = t; }
    }
    return t1 - t0 > 1e-6; };
  const out = [];
  // Net labels, bus labels and wire tags belong to a net: they may sit on their own wire only.
  for (const g of svg.querySelectorAll('.net-label, .wire-tag, .bus')) {
    const t = g.classList.contains('bus') ? g.querySelector('.bus-label') : g.querySelector('text');
    if (!t) continue;
    const r = shrink(boxOf(g.classList.contains('bus') ? t : g), 4);
    const net = g.dataset.net || g.dataset.bundle || '';
    const label = `${g.classList.contains('bus') ? 'bus label' : g.classList.contains('net-label') ? 'net label' : 'wire tag'} "${t.textContent}"`;
    for (const p of parts) if (hit(r, p.r)) out.push({ kind: 'label-on-part', msg: `${label} lies over ${p.name}`, r });
    const s = segs.find(s => s.net !== net && crosses(s, r));
    if (s) out.push({ kind: 'label-on-wire', msg: `${label} covers a wire of another net`, r });
    for (const u of texts) if (hit(r, u.r)) out.push({ kind: 'text-on-text', msg: `${label} overlaps ${u.name} "${u.text}"`, r });
    // The wire nearest a label must be the one it names.
    if (!g.classList.contains('bus')) {
      const cx = r.x + r.w / 2, cy = r.y + r.h / 2;
      const dist = (s) => { const dx = s.b[0] - s.a[0], dy = s.b[1] - s.a[1], L = dx * dx + dy * dy || 1; const t = Math.max(0, Math.min(1, ((cx - s.a[0]) * dx + (cy - s.a[1]) * dy) / L)); return Math.hypot(cx - s.a[0] - t * dx, cy - s.a[1] - t * dy); };
      const nearest = segs.slice().sort((p, q) => dist(p) - dist(q))[0];
      if (nearest && nearest.net !== net) out.push({ kind: 'label-ambiguous', msg: `${label} sits nearer a wire of another net than its own`, r });
    }
  }
  for (const t of texts) {
    // Pin names and numbers sit on their own part; only another part's footprint is a collision.
    for (const p of parts) if (p.id !== t.id && hit(t.r, p.r)) out.push({ kind: 'text-on-part', msg: `${t.name}: "${t.text}" lies over ${p.name}`, r: t.r });
    if (/val|ref|pin-cap|sec-cap/.test(t.cls)) {
      const own = svg.querySelector(`.symbol[data-sym="${CSS.escape(t.id)}"]`);
      const ownNets = new Set([...own.querySelectorAll('[data-net]')].map(e => e.dataset.net));
      const s = segs.find(s => !(t.cls.includes('pin-cap') && ownNets.has(s.net)) && crosses(s, t.r));
      if (s) out.push({ kind: 'text-on-wire', msg: `${t.name}: "${t.text}" is crossed by a wire`, r: t.r });
    }
  }
  // A net label must not cut its own net's other runs either.
  for (const g of svg.querySelectorAll('.net-label')) {
    const r = shrink(boxOf(g), 4), net = g.dataset.net;
    const own = segs.filter(s => s.net === net && crosses(s, r) && !(Math.abs(s.a[1] - s.b[1]) < 0.5 && (s.a[1] < r.y || s.a[1] > r.y + r.h)));
    if (own.length) out.push({ kind: 'label-cuts-wire', msg: `net label "${g.textContent}" is drawn over its own wire`, r });
  }
  // Annotation leaders must not pass through a pin end, where they would read as a wire.
  const tips = [...svg.querySelectorAll('.pin .pin-line')].map(l => { const x1 = +l.getAttribute('x1'), y1 = +l.getAttribute('y1'); return [x1, y1]; });
  for (const p of svg.querySelectorAll('.callout .leader')) {
    const d = p.getAttribute('d') || '';
    const pts = [...d.matchAll(/[ML]\s*(-?[\d.]+)[ ,](-?[\d.]+)/g)].map(m => [+m[1], +m[2]]);
    for (let i = 1; i < pts.length; i++) {
      const s = { a: pts[i - 1], b: pts[i] };
      const hitTip = tips.find(t => crosses(s, { x: t[0] - 12, y: t[1] - 12, w: 24, h: 24 }));
      if (hitTip) { out.push({ kind: 'leader-on-pin', msg: `an annotation leader passes through a pin end`, r: { x: hitTip[0] - 20, y: hitTip[1] - 20, w: 40, h: 40 } }); break; }
    }
  }
  for (let i = 0; i < texts.length; i++) for (let j = i + 1; j < texts.length; j++) {
    const A = texts[i], B = texts[j];
    if (A.id !== B.id && hit(A.r, B.r)) out.push({ kind: 'text-on-text', msg: `${A.name} "${A.text}" overlaps ${B.name} "${B.text}"`, r: A.r });
  }
  // Mark each finding on the drawing.
  const ns = 'http://www.w3.org/2000/svg';
  for (const f of out) { const e = document.createElementNS(ns, 'rect'); for (const [k, v] of Object.entries({ x: f.r.x - 10, y: f.r.y - 10, width: f.r.w + 20, height: f.r.h + 20, fill: 'none', stroke: '#e0006a', 'stroke-width': 12 })) e.setAttribute(k, v); svg.appendChild(e); }
  return out.map(({ kind, msg }) => ({ kind, msg }));
}
"""


SELFTEST = r"""
() => { const svg = document.querySelector('#sheet svg');
  const val = [...svg.querySelectorAll('.symbol .val')].find(t => /cooling fan/.test(t.textContent));
  const body = [...svg.querySelectorAll('.symbol')].find(s => /LG290P/.test(s.textContent)).querySelector('.body').getBBox();
  val.setAttribute('x', body.x + 60); val.setAttribute('y', body.y + 200); val.querySelectorAll('tspan').forEach(t => t.setAttribute('x', body.x + 60)); }
"""


async def check(physical, selftest=False, extra=""):
    async with async_playwright() as p:
        b = await p.chromium.launch()
        page = await b.new_page(viewport={"width": 1800, "height": 1000})
        await page.route("**/*", route)
        await page.goto(PAGE)
        await page.wait_for_function("document.getElementById('status').hidden", timeout=20000)
        await page.add_style_tag(content=".bar,.toolbar,.panel,.zoom,.draft{display:none!important}.work{grid-template-columns:1fr!important}.app{padding:0!important;gap:0!important;grid-template-rows:1fr!important}")
        await page.evaluate(f"async () => {{ KGViewer.state.options.physical = {str(physical).lower()}; {extra} await KGViewer.run(); KGViewer.fit(); }}")
        if selftest:
            await page.evaluate(SELFTEST)
        found = await page.evaluate(PROBE)
        tag = ("physical" if physical else "logical") + ("-all" if "wireTags" in extra else "") + (("-" + extra.split("vp_vehicle_bus: '")[1].split("'")[0]) if "vp_vehicle_bus" in extra else "")
        labels = await page.evaluate("document.querySelectorAll('#sheet .net-label').length")
        print(f"   ({tag}: {labels} net labels drawn)")
        await page.screenshot(path=f"out/visual-{tag}.png")
        await b.close()
        return tag, found


async def main():
    if "--selftest" in sys.argv:
        _, found = await check(False, selftest=True)
        ok = any(f["kind"] == "text-on-part" and "cooling fan" in f["msg"] for f in found)
        print("selftest:", "caught" if ok else "MISSED", *(f["msg"] for f in found[:3]))
        sys.exit(0 if ok else 1)
    total = 0
    everything = "KGViewer.state.options.wireTags = true; KGViewer.state.options.showUnconnected = true;"
    configs = [(False, ""), (True, ""), (False, everything), (True, everything)]
    # Each other configuration the sample graph offers, in both layouts.
    for bus in ("var_718_drive", "var_987_2_drive", "var_frs_obd", "var_no_vehicle"):
        pick = f"KGViewer.state.options.variants = {{vp_vehicle_bus: '{bus}', vp_usb_c: 'var_usb_pc'}};"
        configs += [(False, pick), (True, pick)]
    for physical, extra in configs:
        tag, found = await check(physical, extra=extra)
        total += len(found)
        print(f"== {tag}: {len(found)} findings (marked in out/visual-{tag}.png)")
        for f in found:
            print(f"   {f['kind']}: {f['msg']}")
    sys.exit(1 if total else 0)

asyncio.run(main())
