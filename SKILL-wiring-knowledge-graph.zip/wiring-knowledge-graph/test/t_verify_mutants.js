// Proves each drawing check can fail: inject one known fault into a clean layout and
// confirm that check, and only a plausible set of checks, reports it.
const C = require('../src/cypher.js'), K = require('../src/kicad.js'), S = require('../src/scene.js'), L = require('../src/layout.js'), V = require('../src/verify.js');
const ELK = require('../vendor/package/lib/elk.bundled.js');
const fs = require('fs');
const lib = new K.Library();
for (const f of ['Connector_Generic', 'Connector', 'Device', 'power']) lib.addText(f, fs.readFileSync('lib/' + f + '.kicad_sym', 'utf8'));
const profile = JSON.parse(fs.readFileSync('src/profile.json', 'utf8'));
const measure = (t, size) => String(t).length * size * 0.6;
const clone = (o) => JSON.parse(JSON.stringify(o));

async function fresh(physical) {
  const { graph } = C.load(fs.readFileSync('test/rcx.cypher', 'utf8'));
  const sc = S.buildScene(graph, profile, lib, { physical });
  const out = await L.layoutScene(sc, new ELK(), { measure, physical });
  return { sc, out };
}
const symByName = (out, re) => [...out.symbols.values()].find((s) => re.test(s.sym.name));
const pinsNamed = (s, re) => s.geo.pins.filter((p) => p.contact && re.test(p.contact.name));

const MUTANTS = [
  ['pin-once', 'draw the SN65 VCC pin twice', ({ out }) => { const s = symByName(out, /SN65HVD230 CAN/); s.geo.pins.push({ ...pinsNamed(s, /^VCC$/)[0] }); }],
  ['pin-number', 'put plug position 1 on library pin 2', ({ out }) => { const s = symByName(out, /3-pin power plug/); const [a, b] = s.geo.pins; const ca = a.contact; a.contact = b.contact; b.contact = ca; }],
  ['connector-order', 'swap RXD and TXD rows on the SN65 header', ({ out }) => { const s = symByName(out, /SN65HVD230 CAN/); const [r, t] = [pinsNamed(s, /^RXD$/)[0], pinsNamed(s, /^TXD$/)[0]]; for (const k of ['tip', 'base']) { const y = r[k][1]; r[k] = [r[k][0], t[k][1]]; t[k] = [t[k][0], y]; } }],
  ['mate-order', 'swap two plug positions against the header', ({ out }) => { const s = symByName(out, /SN65 4-pin logic\/power plug/); const [a, b] = s.geo.pins; for (const k of ['tip', 'base', 'face']) { const t = a[k]; a[k] = b[k]; b[k] = t; } }],
  ['connector-symbol', 'draw a female housing with a male symbol', ({ sc }) => { const s = [...sc.symbols.values()].find((x) => /CAN pigtail Dupont female/.test(x.name)); s.libId = s.libId.replace('Female', 'Male'); }],
  ['pin-grid', 'nudge a pin 30 mil off the grid', ({ out }) => { const s = symByName(out, /LG290P/); const p = s.geo.pins[1]; p.tip = [p.tip[0], p.tip[1] + 30]; p.base = [p.base[0], p.base[1] + 30]; }],
  ['wire-endpoint', 'stop a wire 50 mil short', ({ out }) => { const c = out.connections.find((x) => x.type === 'WIRE'); const e = out.edges.get(c.id); e.sections[0][0] = [e.sections[0][0][0] + 50, e.sections[0][0][1]]; }],
  ['false-connection', 'run a wire across another net\'s pin', ({ out }) => { const s = symByName(out, /LG290P/); const p = s.geo.pins.find((x) => x.contact.net); const tip = [s.x + p.tip[0], s.y + p.tip[1]]; const c = out.connections.find((x) => x.type === 'WIRE' && x.net !== p.contact.net); out.edges.get(c.id).sections.push([[tip[0] - 200, tip[1]], [tip[0] + 200, tip[1]]]); }],
  ['net-overlap', 'lay one net over another', ({ out }) => { const ws = out.connections.filter((x) => x.type === 'WIRE'); const a = ws[0], b = ws.find((x) => x.net !== a.net); out.edges.get(b.id).sections.push(clone(out.edges.get(a.id).sections[0])); }],
  ['junction-net', 'put a dot where another net passes', ({ out }) => { const ws = out.connections.filter((x) => x.type === 'WIRE'); const a = ws[0], b = ws.find((x) => x.net !== a.net); const sec = out.edges.get(a.id).sections[0]; out.edges.get(b.id).junctions.push(sec[1]); }],
  ['wire-through-body', 'route a wire through the LG290P body', ({ out }) => { const s = symByName(out, /LG290P/); const b = s.geo.body; const c = out.connections.find((x) => x.type === 'WIRE'); out.edges.get(c.id).sections.push([[s.x + b.x - 100, s.y + b.y + b.h / 2], [s.x + b.x + b.w + 100, s.y + b.y + b.h / 2]]); }],
  ['text-clear', 'drop the fan name onto the LG290P', ({ out }) => { const f = symByName(out, /cooling fan/), g = symByName(out, /LG290P/); f.geo.value.x = g.x - f.x + g.geo.body.x + 50; f.geo.value.y = g.y - f.y + g.geo.body.y + 200; }],
  ['mate-direct', 'pull a plug away from its header', ({ out }) => { const m = out.connections.find((x) => x.style === 'mate'); const e = out.edges.get(m.id); const [a, b] = e.sections[0]; e.sections = [[a, [a[0] - 600, a[1]], [a[0] - 600, a[1] + 400], b]]; }],
  ['connector-shown', 'drop the section titles from the SN65', ({ out }) => { const s = symByName(out, /SN65HVD230 CAN/); s.geo.captions = []; for (const p of s.geo.pins) p.contact = { ...p.contact, name: p.contact.name.split(' ')[0] }; }],
  ['connector-whole', 'split the LG290P connector across two edges', ({ out }) => { const s = symByName(out, /LG290P/); const p = s.geo.pins.find((x) => /UART/.test(x.contact.section?.name || '')); p.side = p.side === 'WEST' ? 'EAST' : 'WEST'; }],
  ['location-claim', 'draw an unlocated pin as if placed', ({ out }) => { if (!out.physical) throw new Error('physical layout only'); const s = symByName(out, /LG290P/); for (const p of s.geo.pins) p.unplaced = false; }],
  ['pin-number-unique', 'give two plug positions the same number', ({ out }) => { const s = symByName(out, /3-pin power plug/); s.geo.pins[1].contact = { ...s.geo.pins[1].contact, number: s.geo.pins[0].contact.number }; }],
  ['no-splice', 'splice one conductor into another', ({ out }) => { const ws = out.connections.filter((x) => x.type === 'WIRE' && x.net); const a = ws[0], b = ws.find((x) => x !== a && x.net === a.net) || ws[0]; const sec = out.edges.get(a.id).sections[0]; out.edges.get(b.id).junctions.push([(sec[0][0] + sec[1][0]) / 2 + 1, (sec[0][1] + sec[1][1]) / 2 + 1]); out.edges.get(b.id).sections.push([sec[0], sec[1]]); }],
  ['collinear-gap', 'end one net 100 mil before another on the same line', ({ out }) => { const ws = out.connections.filter((x) => x.type === 'WIRE'); const a = ws[0], b = ws.find((x) => x.net !== a.net); const p = [9000, 9000]; out.edges.get(a.id).sections.push([[p[0], p[1]], [p[0] + 500, p[1]]]); out.edges.get(b.id).sections.push([[p[0] + 600, p[1]], [p[0] + 1100, p[1]]]); }],
  ['side-by-side', 'run two nets 10 mil apart', ({ out }) => { const ws = out.connections.filter((x) => x.type === 'WIRE'); const a = ws[0], b = ws.find((x) => x.net !== a.net); out.edges.get(a.id).sections.push([[9000, 9000], [9000, 9600]]); out.edges.get(b.id).sections.push([[9010, 9100], [9010, 9500]]); }],
  ['physical-order', 'draw the SN65 CANL header pin below TXD', ({ out }) => { if (!out.physical) throw new Error('physical layout only'); const s = symByName(out, /SN65HVD230 CAN/); const p = s.geo.pins.find((x) => /CANL parallel header/.test(x.contact.name)); p.tip = [p.tip[0], p.tip[1] + 600]; p.base = [p.base[0], p.base[1] + 600]; }],
  ['pin-in-connector', 'take a header pin out of its connector', ({ sc }) => { for (const s of sc.symbols.values()) for (const c of s.contacts.values()) if (c.name === 'GP4' && c.pin) { c.section = null; return; } }],
  ['part-overlap', 'push the antenna plug onto the UART plug', ({ out }) => { const a = symByName(out, /antenna cable plug/), u = symByName(out, /UART cable plug/); a.y = u.y + 20; a.x = u.x; }],
  ['wire-orthogonal', 'slant one wire run', ({ out }) => { const c = out.connections.find((x) => x.type === 'WIRE'); out.edges.get(c.id).sections.push([[9000, 9000], [9300, 9120]]); }],
];

(async () => {
  let failed = 0;
  for (const physical of [false, true]) {
    const base = await fresh(physical);
    const clean = V.run(base.sc, base.out).findings;
    console.log(`== ${physical ? 'physical' : 'logical'}: clean layout has ${clean.length} findings`);
    for (const [check, what, mutate] of MUTANTS) {
      const run = await fresh(physical);
      try { mutate(run); } catch (e) { console.log(`   SKIP ${check.padEnd(18)} ${what}: ${e.message}`); continue; }
      const got = V.run(run.sc, run.out).findings.filter((f) => f.check === check);
      const ok = got.length > 0;
      if (!ok) failed++;
      console.log(`   ${ok ? 'caught' : 'MISSED'} ${check.padEnd(18)} ${what}${ok ? `  → ${got[0].message}` : ''}`);
    }
  }
  console.log(failed ? `${failed} injected faults went unreported` : 'every injected fault was reported');
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.error('ERR', e); process.exit(2); });
