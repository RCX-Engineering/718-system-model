import asyncio, sys, json
from pathlib import Path
from playwright.async_api import async_playwright
sys.path.insert(0, 'test')
from shot import route
PAGE = "http://localhost:8765/kg-schematic-viewer.standalone.html"

REV = """
// Revision: move the GPS UART to a new colour pair and drop the parallel pads
MATCH ()-[w:WIRE {id: 'w_gps_tx_to_esp_gp4'}]->() SET w.color = 'violet'
MATCH (c:Connector {id: 'sn65_can_parallel_pads'}) DETACH DELETE c
"""

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch()
        ctx = await b.new_context(viewport={"width": 1600, "height": 1000})
        await ctx.grant_permissions(["clipboard-read", "clipboard-write"], origin="http://localhost:8765")
        page = await ctx.new_page()
        errors = []
        page.on("pageerror", lambda e: errors.append(str(e)))
        page.on("console", lambda m: errors.append(m.text) if m.type == "error" and "ERR_FAILED" not in m.text else None)
        await page.route("**/*", route)
        await page.goto(PAGE)
        await page.wait_for_function("document.getElementById('status').hidden", timeout=20000)
        ready = "document.getElementById('status').hidden"

        # 1. hover a UART wire highlights the whole net
        box = await page.evaluate("""() => { const s = KGViewer.state; const c = s.scene.connections.find(c => c.props && c.props.id === 'w_esp_gp5_to_gps_rx');
          const el = document.querySelector(`[data-conn="${c.id}"] path.hit`); const r = el.getBoundingClientRect(); return {x: r.x + r.width/2, y: r.y + r.height/2, id: c.id}; }""")
        # hover exactly on the path: use the path's point at half length
        pt = await page.evaluate("""(id) => { const el = document.querySelector(`[data-conn="${id}"] path.hit`); const svg = el.ownerSVGElement;
           const p = el.getPointAtLength(el.getTotalLength()/2); const m = el.getScreenCTM(); return {x: p.x*m.a + m.e, y: p.y*m.d + m.f}; }""", box["id"])
        await page.mouse.move(pt["x"], pt["y"])
        hl = await page.evaluate("document.querySelectorAll('.schematic .hl').length")
        dimmed = await page.evaluate("document.querySelector('.schematic').classList.contains('dimmed')")
        print("hover net: highlighted elements", hl, "dimmed", dimmed)

        # 2. click the wire -> inspector
        await page.mouse.click(pt["x"], pt["y"])
        head = await page.inner_text("#pane-inspect .insp-head")
        print("click wire ->", head.replace("\n", " | ")[:160])

        # 3. select a pin via search
        await page.fill("#search", "GP4")
        await page.press("#search", "Enter")
        await page.wait_for_timeout(200)
        print("search GP4 ->", (await page.inner_text("#pane-inspect h2")))
        await page.screenshot(path="out/shot-pin.png")

        # 4. callout -> annotation inspector (only when the graph carries annotations)
        await page.evaluate("KGViewer.fit()")
        co = await page.evaluate("() => { const e = document.querySelector('.callout-box'); if (!e) return null; const r = e.getBoundingClientRect(); return {x: r.x + r.width/2, y: r.y + r.height/2}; }")
        if co:
            await page.mouse.click(co["x"], co["y"])
            print("callout ->", (await page.inner_text("#pane-inspect .insp-head")).replace("\n", " | ")[:140])
        else:
            print("callout -> none in this graph")

        # 5. apply a revision through the file input
        Path("out/rev.cypher").write_text(REV)
        await page.click(".tab[data-tab=source]")
        await page.set_input_files("#revision-file", "out/rev.cypher")
        await page.wait_for_timeout(300)
        await page.wait_for_function(ready, timeout=20000)
        col = await page.evaluate("() => KGViewer.state.scene.connections.find(c => c.props && c.props.id === 'w_gps_tx_to_esp_gp4').color.label")
        banner = await page.evaluate("!document.getElementById('draft-banner').hidden")
        nodes = await page.evaluate("KGViewer.state.result.graph.nodes.size")
        print("revision applied: colour", col, "nodes", nodes, "banner shown", banner, "|", await page.inner_text("#source-state"))

        # 6. copy the page with the revised graph and check the embedded block round-trips
        await page.click("#page-copy")
        await page.wait_for_timeout(200)
        html = await page.evaluate("navigator.clipboard.readText()")
        start = html.index('id="graph-source"'); body = html[html.index('>', start)+1: html.index('</script>', start)]
        cur = await page.evaluate("KGViewer.state.source")
        print("copied page:", len(html), "chars; embedded graph equals edited source:", body == cur, "; contains revision:", "violet" in body)
        Path("out/copied.html").write_text(html)

        # 7. revert
        await page.click("#source-revert")
        await page.wait_for_timeout(300)
        await page.wait_for_function(ready, timeout=20000)
        print("reverted: nodes", await page.evaluate("KGViewer.state.result.graph.nodes.size"), "banner hidden", await page.evaluate("document.getElementById('draft-banner').hidden"))

        # 8. toggles
        for tid in ["#opt-colours", "#opt-unconnected", "#opt-physical", "#opt-wiretags"]:
            await page.click(f"label:has({tid})")
            await page.wait_for_timeout(200)
            await page.wait_for_function(ready, timeout=20000)
        pins = await page.evaluate("document.querySelectorAll('.schematic .pin').length")
        kicad = await page.evaluate("document.querySelector('.schematic').classList.contains('kicad-wires')")
        tags = await page.evaluate("document.querySelectorAll('.schematic .wire-tag').length")
        print("toggles: pins drawn", pins, "kicad wires", kicad, "wire tags", tags)
        await page.evaluate("KGViewer.fit()")
        await page.screenshot(path="out/shot-toggles.png")

        # 9. invalid rules JSON keeps the drawing and reports it
        await page.click(".tab[data-tab=rules]")
        await page.fill("#rules-text", "{ broken")
        await page.wait_for_timeout(900)
        print("bad rules ->", await page.inner_text("#rules-state"))
        await page.click("#rules-reset")
        await page.wait_for_timeout(300)

        # 10. open a different graph (the ESP32 + UART example)
        await page.click(".tab[data-tab=source]")
        # Tables view: filtering narrows the rows, and the drawing's viewport survives the switch.
        await page.fill("#search", "")
        await page.click("[data-view=tables]")
        await page.wait_for_timeout(200)
        all_rows = await page.evaluate("document.querySelectorAll('#tables tbody tr[data-row]').length")
        await page.fill("#search", "UART1")
        await page.wait_for_timeout(200)
        some_rows = await page.evaluate("document.querySelectorAll('#tables tbody tr[data-row]').length")
        await page.fill("#search", "")
        await page.click("[data-view=drawing]")
        await page.wait_for_timeout(200)
        vb = await page.evaluate("document.querySelector('#sheet svg').getAttribute('viewBox')")
        print("tables:", all_rows, "rows,", some_rows, "after filter; viewBox numeric:", all(p.replace('.', '', 1).replace('-', '', 1).isdigit() for p in vb.split()))

        # Configuration picker: choosing another vehicle bus redraws that configuration.
        if await page.evaluate("!!document.querySelector('select[data-point]')"):
            point = await page.evaluate("document.querySelector('select[data-point]').dataset.point")
            last = await page.evaluate("[...document.querySelector('select[data-point]').options].pop().value")
            await page.select_option(f"select[data-point='{point}']", last)
            await page.wait_for_function(ready, timeout=20000)
            await page.wait_for_timeout(300)
            print("picked", last, "->", await page.evaluate(f"KGViewer.state.scene.variationPoints.find(p => p.id === '{point}').selected"))

        await page.set_input_files("#import-file", "test/design.cypher")
        await page.wait_for_timeout(300)
        await page.wait_for_function(ready, timeout=20000)
        print("design.cypher: parts", await page.evaluate("KGViewer.state.layout.symbols.size"), "title", await page.inner_text("#doc-title"))
        await page.screenshot(path="out/shot-design.png")
        print("errors:", errors[:5])
        await b.close()

asyncio.run(main())
