// Drawing checks over every sample graph in both layouts. Exits non-zero on any error.
const C = require('../src/cypher.js'), K = require('../src/kicad.js'), S = require('../src/scene.js'), L = require('../src/layout.js'), V = require('../src/verify.js');
const ELK = require('../vendor/package/lib/elk.bundled.js');
const fs = require('fs');
const lib = new K.Library();
for (const f of ['Connector_Generic', 'Connector', 'Device', 'power']) lib.addText(f, fs.readFileSync('lib/' + f + '.kicad_sym', 'utf8'));
const profile = JSON.parse(fs.readFileSync('src/profile.json', 'utf8'));
const measure = (t, size) => String(t).length * size * 0.6;
const files = process.argv.slice(2).length ? process.argv.slice(2) : ['test/rcx.cypher', 'test/design.cypher'];
(async () => {
  let errors = 0;
  // Every configuration the graph offers (the product of its variation points), each laid out
  // both ways; the default configuration is also checked with unconnected pins shown.
  const combos = (points) => points.reduce((acc, pt) => acc.flatMap((sel) => pt.options.map((o) => ({ ...sel, [pt.id]: o.id }))), [{}]);
  const runs = [];
  for (const f of files) {
    const { graph } = C.load(fs.readFileSync(f, 'utf8'));
    const points = S.configure(graph, profile, {}).points;
    for (const variants of combos(points)) for (const physical of [false, true]) runs.push({ f, graph, variants, physical, showUnconnected: false, points });
    for (const physical of [false, true]) runs.push({ f, graph, variants: {}, physical, showUnconnected: true, points });
  }
  for (const { f, graph, variants, physical, showUnconnected, points } of runs) {
    const sc = S.buildScene(graph, profile, lib, { physical, showUnconnected, variants });
    const out = await L.layoutScene(sc, new ELK(), { measure, physical });
    const { findings, summary } = V.run(sc, out);
    const e = findings.filter((x) => x.level === 'error').length, w = findings.length - e;
    errors += e;
    const config = points.map((pt) => pt.options.find((o) => o.id === (variants[pt.id] || pt.default)).name).join(' · ');
    console.log(`== ${f} ${physical ? 'physical' : 'logical'}${showUnconnected ? ' +unconnected' : ''}${config ? ` [${config}]` : ''}: ${e} errors, ${w} warnings`);
    for (const s of summary) if (s.errors || s.warnings) console.log(`   ${s.id.padEnd(18)} ${s.errors} err ${s.warnings} warn`);
    for (const x of findings) console.log(`   [${x.level[0]}] ${x.check}: ${x.message}${x.at ? ` @(${Math.round(x.at[0])},${Math.round(x.at[1])})` : ''}`);
  }
  process.exit(errors ? 1 : 0);
})().catch((e) => { console.error('ERR', e); process.exit(2); });
