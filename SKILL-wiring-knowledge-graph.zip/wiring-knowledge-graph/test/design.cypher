// Authoritative design graph: ESP32-S3 host talking to a GNSS sensor board over UART.
// Shape is the standard netlist triple -- Component -[:HAS_PIN]-> Pin -[:ON_NET]-> Net --
// so the same graph feeds a renderer, a netlist export, or a connectivity query.
//
// Presentation hints (column, row, side, order, symbol) live as node properties.
// They steer the drawing without leaking into the electrical model.

// ---------------------------------------------------------------- components

CREATE (u1:Component {ref: 'U1', value: 'ESP32-S3-WROOM-1', symbol: 'RF_Module:ESP32-S3-WROOM-1', footprint: 'RF_Module:ESP32-S3-WROOM-1', column: 0, row: 0});
CREATE (u2:Component {ref: 'U2', value: 'LG290P GNSS breakout', symbol: 'Connector:Conn_01x06_Pin', footprint: 'Connector_PinHeader_2.54mm:PinHeader_1x06_P2.54mm_Vertical', column: 2, row: 0});
CREATE (r1:Component {ref: 'R1', value: '33R', symbol: 'Device:R_US', footprint: 'Resistor_SMD:R_0603_1608Metric', column: 1, row: 0});
CREATE (r2:Component {ref: 'R2', value: '33R', symbol: 'Device:R_US', footprint: 'Resistor_SMD:R_0603_1608Metric', column: 1, row: 1});
CREATE (c1:Component {ref: 'C1', value: '100nF', symbol: 'Device:C', footprint: 'Capacitor_SMD:C_0603_1608Metric', column: 2, row: 2});

// ---------------------------------------------------------------- nets

CREATE (n_3v3:Net   {name: '+3V3',    class: 'power'});
CREATE (n_gnd:Net   {name: 'GND',     class: 'power'});
CREATE (n_txa:Net   {name: 'ESP_TX',  class: 'signal'});
CREATE (n_txb:Net   {name: 'GNSS_RX', class: 'signal'});
CREATE (n_rxa:Net   {name: 'GNSS_TX', class: 'signal'});
CREATE (n_rxb:Net   {name: 'ESP_RX',  class: 'signal'});

// ---------------------------------------------------------------- U1 pins

CREATE (u1_p2:Pin  {uid: 'U1.2',  number: '2',  name: '3V3',  dir: 'power_in',  side: 'top',    order: 1});
CREATE (u1_p1:Pin  {uid: 'U1.1',  number: '1',  name: 'GND',  dir: 'power_in',  side: 'bottom', order: 1});
CREATE (u1_p10:Pin {uid: 'U1.10', number: '10', name: 'IO17', dir: 'output',    side: 'right',  order: 1});
CREATE (u1_p11:Pin {uid: 'U1.11', number: '11', name: 'IO18', dir: 'input',     side: 'right',  order: 2});

// ---------------------------------------------------------------- U2 pins

CREATE (u2_p1:Pin  {uid: 'U2.1',  number: '1',  name: 'VCC',  dir: 'power_in',  side: 'top',    order: 1});
CREATE (u2_p2:Pin  {uid: 'U2.2',  number: '2',  name: 'GND',  dir: 'power_in',  side: 'bottom', order: 1});
CREATE (u2_p3:Pin  {uid: 'U2.3',  number: '3',  name: 'RX',   dir: 'input',     side: 'left',   order: 1});
CREATE (u2_p4:Pin  {uid: 'U2.4',  number: '4',  name: 'TX',   dir: 'output',    side: 'left',   order: 2});

// ---------------------------------------------------------------- passive pins

CREATE (r1_p1:Pin {uid: 'R1.1', number: '1', name: '1', dir: 'passive', side: 'left',   order: 1});
CREATE (r1_p2:Pin {uid: 'R1.2', number: '2', name: '2', dir: 'passive', side: 'right',  order: 1});
CREATE (r2_p1:Pin {uid: 'R2.1', number: '1', name: '1', dir: 'passive', side: 'left',   order: 1});
CREATE (r2_p2:Pin {uid: 'R2.2', number: '2', name: '2', dir: 'passive', side: 'right',  order: 1});
CREATE (c1_p1:Pin {uid: 'C1.1', number: '1', name: '1', dir: 'passive', side: 'top',    order: 1});
CREATE (c1_p2:Pin {uid: 'C1.2', number: '2', name: '2', dir: 'passive', side: 'bottom', order: 1});

// ---------------------------------------------------------------- ownership

CREATE (u1)-[:HAS_PIN]->(u1_p1);
CREATE (u1)-[:HAS_PIN]->(u1_p2);
CREATE (u1)-[:HAS_PIN]->(u1_p10);
CREATE (u1)-[:HAS_PIN]->(u1_p11);
CREATE (u2)-[:HAS_PIN]->(u2_p1);
CREATE (u2)-[:HAS_PIN]->(u2_p2);
CREATE (u2)-[:HAS_PIN]->(u2_p3);
CREATE (u2)-[:HAS_PIN]->(u2_p4);
CREATE (r1)-[:HAS_PIN]->(r1_p1);
CREATE (r1)-[:HAS_PIN]->(r1_p2);
CREATE (r2)-[:HAS_PIN]->(r2_p1);
CREATE (r2)-[:HAS_PIN]->(r2_p2);
CREATE (c1)-[:HAS_PIN]->(c1_p1);
CREATE (c1)-[:HAS_PIN]->(c1_p2);

// ---------------------------------------------------------------- connectivity

CREATE (u1_p2)-[:ON_NET]->(n_3v3);
CREATE (u2_p1)-[:ON_NET]->(n_3v3);
CREATE (c1_p1)-[:ON_NET]->(n_3v3);

CREATE (u1_p1)-[:ON_NET]->(n_gnd);
CREATE (u2_p2)-[:ON_NET]->(n_gnd);
CREATE (c1_p2)-[:ON_NET]->(n_gnd);

CREATE (u1_p10)-[:ON_NET]->(n_txa);
CREATE (r1_p1)-[:ON_NET]->(n_txa);
CREATE (r1_p2)-[:ON_NET]->(n_txb);
CREATE (u2_p3)-[:ON_NET]->(n_txb);

CREATE (u2_p4)-[:ON_NET]->(n_rxa);
CREATE (r2_p2)-[:ON_NET]->(n_rxa);
CREATE (r2_p1)-[:ON_NET]->(n_rxb);
CREATE (u1_p11)-[:ON_NET]->(n_rxb);

// ---------------------------------------------------------------- interface

CREATE (uart:Interface {name: 'UART1', protocol: 'NMEA-0183', baud: 460800, framing: '8N1', logic: '3V3'});
CREATE (uart)-[:CARRIED_BY]->(n_txa);
CREATE (uart)-[:CARRIED_BY]->(n_rxa);
CREATE (u1)-[:HOST_OF]->(uart);
CREATE (u2)-[:PERIPHERAL_OF]->(uart);
