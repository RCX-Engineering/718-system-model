import asyncio, sys, json
from pathlib import Path
from playwright.async_api import async_playwright

import os
PAGE = Path(os.environ.get("KG_PAGE", "out/kg-schematic-viewer.standalone.html")).resolve().as_uri()
ELK = Path("vendor/package/lib/elk.bundled.js").read_text()

async def route(r):
    url = r.request.url
    if "elk.bundled.js" in url:
        await r.fulfill(status=200, content_type="application/javascript", body=ELK)
    elif url.startswith("file://") or url.startswith("http://localhost"):
        await r.continue_()
    else:
        await r.abort()

async def main(tag="a", width=1600, height=1000, scheme="light", extra=None):
    async with async_playwright() as p:
        b = await p.chromium.launch()
        ctx = await b.new_context(viewport={"width": width, "height": height}, color_scheme=scheme, device_scale_factor=1)
        page = await ctx.new_page()
        logs = []
        page.on("console", lambda m: logs.append(f"{m.type}: {m.text}") if m.type in ("error", "warning") else None)
        page.on("pageerror", lambda e: logs.append(f"pageerror: {e}"))
        await page.route("**/*", route)
        await page.goto(PAGE)
        await page.wait_for_function("document.getElementById('status').hidden || document.getElementById('status').classList.contains('error')", timeout=20000)
        status = await page.eval_on_selector("#status", "e => e.hidden ? 'ok' : e.textContent")
        if extra:
            await extra(page)
        await page.screenshot(path=f"out/shot-{tag}.png")
        print(tag, "status:", status)
        for l in logs[:20]: print("  ", l)
        await b.close()

if __name__ == "__main__":
    asyncio.run(main(*sys.argv[1:2]))
