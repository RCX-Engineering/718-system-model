const C = require('../src/cypher.js');
const fs = require('fs');
for (const f of ['test/rcx.cypher', 'test/design.cypher']) {
  const t0 = Date.now();
  const { graph, diagnostics, statementCount } = C.load(fs.readFileSync(f, 'utf8'));
  const labels = {}; for (const n of graph.nodes.values()) for (const l of n.labels) labels[l] = (labels[l]||0)+1;
  const types = {}; for (const r of graph.rels.values()) types[r.type] = (types[r.type]||0)+1;
  console.log(`${f}: ${statementCount} statements, ${graph.nodes.size} nodes, ${graph.rels.size} rels in ${Date.now()-t0} ms`);
  console.log('  labels', JSON.stringify(labels));
  console.log('  types ', JSON.stringify(types));
  diagnostics.forEach(d => console.log(`  [${d.level}] line ${d.line}: ${d.message}`));
}
// revision script exercising MERGE / SET / DELETE / WHERE
const base = fs.readFileSync('test/rcx.cypher', 'utf8');
const rev = `
// revision: rename GPS harness colour, add a ferrite, delete the parallel pads
MATCH ()-[w:WIRE {id: 'w_gps_tx_to_esp_gp4'}]->() SET w.color = 'white', w.revised = true;
MERGE (f:Component {id: 'fb1'}) ON CREATE SET f.name = 'Ferrite bead', f.diagram_order = 25
MATCH (c:Connector) WHERE c.id STARTS WITH 'sn65_can_parallel' DETACH DELETE c
MATCH (p:Pin) WHERE p.id IN ['can_l_pad', 'can_h_pad'] DETACH DELETE p
MATCH (n {id: 'does_not_exist'}) SET n.x = 1
`;
const r2 = C.load(base + rev);
const w = [...r2.graph.rels.values()].find(r => r.props.id === 'w_gps_tx_to_esp_gp4');
console.log('revision:', r2.graph.nodes.size, 'nodes', r2.graph.rels.size, 'rels; wire colour now', w.props.color, w.lines);
console.log('  fb1:', JSON.stringify([...r2.graph.nodes.values()].find(n => n.props.id === 'fb1')?.props));
r2.diagnostics.filter(d => d.line > 396).forEach(d => console.log(`  [${d.level}] line ${d.line}: ${d.message}`));
// syntax error recovery
const bad = base.replace("CREATE (lg290p:Device {id: 'lg290p'", "CREATE (lg290p:Device {id 'lg290p'");
const r3 = C.load(bad);
console.log('with a syntax error:', r3.graph.nodes.size, 'nodes', r3.graph.rels.size, 'rels');
r3.diagnostics.filter(d => d.level === 'error').slice(0, 3).forEach(d => console.log(`  [${d.level}] line ${d.line}: ${d.message}`));
