# KiCad symbol libraries

The `.kicad_sym` files in this folder contain symbols from the KiCad symbol library
(github.com/KiCad/kicad-symbols, commit 4e17d7595f9691d45d97aea8ad64572652fb5bed), by the KiCad
Library Team and contributors. They are not stored in the repository: `tools/fetch_symbols.py`
makes them from that upstream commit, as `symbols.json` in this folder lists, and checks each
against its recorded sha256. Every page built with them embeds them, with this attribution.

**Change made:** the selected symbols were converted from the legacy KiCad 5 `.lib` format to the
KiCad 6+ `.kicad_sym` format by `tools/lib2kicadsym.py`. The conversion follows the rules KiCad
applies when it migrates a legacy library: units go from mils to millimetres and drawing records
take the new syntax. DeMorgan alternates are dropped.

**Licence:** Creative Commons Attribution-ShareAlike 4.0 International (CC-BY-SA 4.0), with the
KiCad libraries exception (SPDX: `CC-BY-SA-4.0 WITH KiCad-libraries-exception`).

- Full licence text: https://creativecommons.org/licenses/by-sa/4.0/legalcode
- Exception: https://spdx.org/licenses/KiCad-libraries-exception.html

The exception reads:

> To the extent that the creation of electronic designs that use 'Licensed Material' can be
> considered to be 'Adapted Material', then the copyright holder waives article 3 of the license
> with respect to these designs and any generated files which use data provided as part of the
> 'Licensed Material'.

In practice:

- These library files, and any changed copy of them, stay under CC-BY-SA 4.0 with this
  attribution.
- Schematics and viewer pages drawn with the symbols are designs, and are not bound by the
  share-alike terms.
