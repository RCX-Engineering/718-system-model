/* ============================================================================
 * Reference tables
 *
 * The same scene the drawing comes from, as tables an engineer can scan, sort
 * and copy: every pin and internal IO with its function and what it connects
 * to, the functions and where they are assigned, every connection, every net,
 * and every connector. Nothing here is specific to one graph; columns come
 * from the scene and the rules profile.
 *
 * buildTables(scene, graph) returns [{ id, title, note, columns, rows }], where
 * each column is { key, label } and each row is { cells: { key: text }, ref }.
 * `ref` says what a row stands for, so the page can open it in the inspector.
 * ========================================================================== */

(function (root, factory) {
  const api = factory(root.KGScene || (typeof require === "function" ? require("./scene.js") : null));
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.KGTables = api;
})(typeof self !== "undefined" ? self : this, function (Scene) {
  "use strict";

  const SIDE_WORD = { WEST: "left", EAST: "right", NORTH: "top", SOUTH: "bottom" };
  const SIDE_RANK = { WEST: 0, NORTH: 1, EAST: 2, SOUTH: 3 };
  const list = (v) => (Array.isArray(v) ? v : v === undefined || v === null || v === "" ? [] : [v]).map(String);
  const uniq = (xs) => [...new Set(xs.filter(Boolean))];
  const first = (props, keys) => { for (const k of keys || []) if (props && props[k] !== undefined && props[k] !== null && props[k] !== "") return props[k]; return undefined; };

  function buildTables(scene, graph) {
    const P = scene.profile || {};
    const T = P.text || {};
    const nameOf = (n) => String(first(n.props, T.nameKeys || ["name", "id"]) ?? n.id);
    const capRels = new Set(T.pinCapabilityRelationships || []);
    const assignRels = new Set(T.pinFunctionRelationships || []);
    const capKeys = T.pinCapabilityKeys || [];

    // Functions each pin can take, and the one it is assigned.
    const capsOf = new Map(), assignedOf = new Map();
    for (const r of graph.rels.values()) {
      const target = graph.nodes.get(r.end);
      if (!target) continue;
      if (capRels.has(r.type)) { if (!capsOf.has(r.start)) capsOf.set(r.start, []); capsOf.get(r.start).push(nameOf(target)); }
      if (assignRels.has(r.type)) { if (!assignedOf.has(r.start)) assignedOf.set(r.start, []); assignedOf.get(r.start).push(nameOf(target)); }
    }

    const partName = (c) => scene.symbols.get(c.symbolId)?.name || "";
    const where = (c) => `${partName(c)} · ${c.name}`;
    const connsOf = new Map();
    for (const cn of scene.connections) for (const end of [cn.a, cn.b]) if (end) { if (!connsOf.has(end)) connsOf.set(end, []); connsOf.get(end).push(cn); }
    const colourOf = (cn) => cn.color?.label || "";
    const location = (c) => {
      if (c.pos) return `${c.pos.x} × ${c.pos.y} mm`;
      const side = SIDE_WORD[c.sideHint];
      if (side && c.order !== undefined && c.order !== null) return `${side}, position ${c.order}`;
      return side || "";
    };
    const symbolsInOrder = [...scene.symbols.values()].sort((a, b) => (a.rank ?? 1e9) - (b.rank ?? 1e9) || Scene.compareNatural(a.name, b.name));

    // ---- pins and IO ----------------------------------------------------------------------------------
    const pinRows = [];
    for (const s of symbolsInOrder) {
      const contacts = [...s.contacts.values()].filter((c) => c.pin);
      // Physical contacts first, connector by connector in position order; internal IO after.
      const rowKey = (c) => [c.logical ? 1 : 0, c.section ? 0 : 1];
      contacts.sort((a, b) => rowKey(a)[0] - rowKey(b)[0] || rowKey(a)[1] - rowKey(b)[1] || Scene.compareNatural(a.section?.name || "", b.section?.name || "") || (SIDE_RANK[a.sideHint] ?? 9) - (SIDE_RANK[b.sideHint] ?? 9) || Scene.contactOrder(a, b));
      for (const c of contacts) {
        const caps = uniq([...(capsOf.get(c.pin.id) || []), ...capKeys.flatMap((k) => list(c.pin.props[k]))]);
        const assigned = uniq([...(assignedOf.get(c.pin.id) || []), c.func]);
        const others = (connsOf.get(c) || []).filter((cn) => !cn.inferred).map((cn) => {
          const other = cn.a === c ? cn.b : cn.a;
          const to = other ? where(other) : cn.port ? `${cn.port.label} (enclosure)` : "";
          return `${to}${colourOf(cn) ? ` [${colourOf(cn)}]` : ""}`;
        });
        pinRows.push({
          ref: { type: c.visible ? "contact" : "node", sym: s.id, key: c.key, id: c.pin.id },
          cells: {
            part: s.name, connector: c.section?.name || "", pin: c.name, number: c.number || "",
            kind: c.logical ? "internal" : "physical", type: c.ptype, dir: c.dir,
            assigned: assigned.join(", "), capabilities: caps.join(", "),
            net: c.net?.name || "", to: uniq(others).join("; "), location: location(c),
          },
        });
      }
    }

    // ---- functions ------------------------------------------------------------------------------------
    const fn = new Map();
    const fnEntry = (name) => { if (!fn.has(name)) fn.set(name, { assigned: [], available: [], parts: new Set() }); return fn.get(name); };
    for (const s of symbolsInOrder) for (const c of s.contacts.values()) {
      if (!c.pin) continue;
      const caps = uniq([...(capsOf.get(c.pin.id) || []), ...capKeys.flatMap((k) => list(c.pin.props[k]))]);
      const assigned = uniq([...(assignedOf.get(c.pin.id) || []), c.func]);
      for (const a of assigned) { const e = fnEntry(a); e.assigned.push(c.name); e.parts.add(s.name); }
      for (const k of caps) { const e = fnEntry(k); e.available.push(c.name); e.parts.add(s.name); }
    }
    const fnRows = [...fn.entries()]
      .sort((a, b) => (b[1].assigned.length ? 1 : 0) - (a[1].assigned.length ? 1 : 0) || Scene.compareNatural(a[0], b[0]))
      .map(([name, e]) => ({
        ref: null,
        cells: { function: name, assigned: uniq(e.assigned).join(", "), available: uniq(e.available).join(", "), count: String(uniq(e.available).length), parts: [...e.parts].join(", ") },
      }));

    // ---- connections ----------------------------------------------------------------------------------
    const connRows = scene.connections.filter((cn) => cn.rel || cn.node).map((cn) => ({
      ref: { type: "connection", id: cn.id },
      cells: {
        id: String(cn.props?.id ?? ""), type: cn.type, style: cn.inferred ? `${cn.style} (inferred)` : cn.style,
        from: cn.a ? where(cn.a) : "", to: cn.b ? where(cn.b) : cn.port ? cn.port.label : "",
        net: cn.net?.name || "", colour: colourOf(cn),
        harness: cn.bundle ? `${cn.bundle.name} (${cn.bundle.style === "pair" ? `twisted pair${cn.groupRole ? `, ${cn.groupRole}` : ""}` : "one jacket"})`
          : cn.group ? `${scene.wireGroups.get(String(cn.group))?.name || String(cn.group)}${cn.groupRole ? ` (${cn.groupRole})` : ""}` : "",
        detail: Object.entries(cn.props || {}).filter(([k]) => !["id", "color", "harness", "signal"].includes(k)).map(([k, v]) => `${k}: ${Array.isArray(v) ? v.join(", ") : v}`).join("; "),
      },
    }));

    // ---- nets -----------------------------------------------------------------------------------------
    const netRows = [...scene.nets.values()]
      .filter((n) => n.connections.length || n.contacts.filter((c) => c.pin).length > 1)
      .sort((a, b) => Scene.compareNatural(a.name, b.name))
      .map((n) => {
        const members = n.contacts.filter((c) => c.pin).map((c) => `${where(c)}${c.logical ? " (internal)" : ""}`);
        return { ref: null, cells: { net: n.name, members: members.join("; "), count: String(members.length), connections: String((n.connections || []).length) } };
      });

    // ---- connectors -----------------------------------------------------------------------------------
    const connectorLabels = new Set((P.structure || {}).connectorLabels || []);
    const conRows = [];
    for (const node of graph.nodes.values()) {
      if (!node.labels.some((l) => connectorLabels.has(l))) continue;
      const contacts = [];
      for (const s of scene.symbols.values()) for (const c of s.contacts.values()) if (c.section?.node === node || (s.node === node && c.pin)) contacts.push(c);
      const owner = contacts[0] ? scene.symbols.get(contacts[0].symbolId) : null;
      const mates = uniq(contacts.flatMap((c) => (connsOf.get(c) || []).filter((cn) => cn.style === "mate").map((cn) => {
        const other = cn.a === c ? cn.b : cn.a;
        return other ? (other.section?.name || partName(other)) : "";
      })));
      conRows.push({
        ref: { type: "node", id: node.id },
        cells: {
          connector: nameOf(node), part: owner && owner.node !== node ? owner.name : "free-standing",
          type: String(node.props.type ?? ""), gender: String(node.props.user_gender ?? node.props.gender ?? ""),
          positions: String(node.props.positions ?? (contacts.length || "")),
          pins: contacts.map((c) => `${c.number ? c.number + " " : ""}${c.name}`).join(", "),
          mates: mates.join(", "),
        },
      });
    }

    const col = (key, label) => ({ key, label });
    return [
      { id: "pins", title: "Pins and IO", note: "Every pin in the graph, physical and internal, with its function and what it connects to.", rows: pinRows,
        columns: [col("part", "Part"), col("connector", "Connector"), col("pin", "Pin"), col("number", "No."), col("net", "Net"), col("to", "Connects to"), col("assigned", "Assigned function"), col("capabilities", "Can also be"), col("type", "Type"), col("dir", "Dir"), col("kind", "Kind"), col("location", "Physical location")] },
      { id: "functions", title: "Functions", note: "Each function, the pins it is assigned to, and every pin able to take it.", rows: fnRows,
        columns: [col("function", "Function"), col("assigned", "Assigned to"), col("available", "Available on"), col("count", "Pins"), col("parts", "Parts")] },
      { id: "connections", title: "Connections", note: "Every stated connection: wires, cables, mates and taps.", rows: connRows,
        columns: [col("id", "ID"), col("type", "Type"), col("from", "From"), col("to", "To"), col("net", "Net"), col("colour", "Colour"), col("harness", "Harness"), col("detail", "Other properties")] },
      { id: "nets", title: "Nets", note: "Electrical nets and every contact on each.", rows: netRows,
        columns: [col("net", "Net"), col("count", "Contacts"), col("connections", "Connections"), col("members", "Members")] },
      { id: "connectors", title: "Connectors", note: "Every connector, its positions and what it mates with.", rows: conRows,
        columns: [col("connector", "Connector"), col("part", "On part"), col("type", "Type"), col("gender", "Gender"), col("positions", "Positions"), col("pins", "Pins"), col("mates", "Mates with")] },
    ];
  }

  /** RFC 4180 CSV of one table. */
  function toCsv(table) {
    const q = (v) => (/[",\n]/.test(v) ? `"${String(v).replace(/"/g, '""')}"` : String(v));
    return [table.columns.map((c) => q(c.label)).join(","), ...table.rows.map((r) => table.columns.map((c) => q(r.cells[c.key] ?? "")).join(","))].join("\r\n");
  }

  return { buildTables, toCsv };
});
