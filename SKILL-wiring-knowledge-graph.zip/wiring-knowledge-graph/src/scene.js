/* ============================================================================
 * Scene builder
 *
 * Turns a property graph into schematic objects using the rules profile:
 * which nodes are drawn as symbols, which of their contacts show, how they
 * connect, which electrical nets result, what encloses what, which contacts
 * are exposed interfaces and which annotations point at which parts.
 *
 * Nothing here knows about a particular project. Every decision reads a
 * label, relationship type or property named in the profile, or follows from
 * the shape of the graph itself.
 * ========================================================================== */

(function (root, factory) {
  const api = factory(root.KGKicad || (typeof require === "function" ? require("./kicad.js") : null));
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.KGScene = api;
})(typeof self !== "undefined" ? self : this, function (Kicad) {
  "use strict";

  // ------------------------------------------------------------------ helpers

  const first = (obj, keys) => {
    for (const k of keys || []) if (obj && obj[k] !== undefined && obj[k] !== null && obj[k] !== "") return obj[k];
    return undefined;
  };

  /** Fill "{key}" and "{key:N}" (first N characters) from the given property bags; null if any is missing. */
  function template(pattern, ...bags) {
    let missing = false;
    const out = String(pattern).replace(/\{([A-Za-z0-9_]+)(?::(\d+))?\}/g, (_, key, len) => {
      const bag = bags.find((b) => b && b[key] !== undefined && b[key] !== null && b[key] !== "");
      if (!bag) { missing = true; return ""; }
      const v = String(bag[key]);
      return len ? v.slice(0, +len).toUpperCase() : v;
    });
    return missing ? null : out;
  }

  function regexFrom(spec) {
    const m = /^\/(.*)\/([a-z]*)$/.exec(spec);
    return m ? new RegExp(m[1], m[2]) : new RegExp(`^${spec.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}$`, "i");
  }

  const norm = (s) => String(s ?? "").trim().toLowerCase().replace(/\s+/g, " ");

  function prettyKey(s) {
    return String(s).replace(/[_]+/g, " ").replace(/\s+/g, " ").trim();
  }

  /** Remove words the owner's name already says, e.g. "LG290P antenna connector" inside "LG290P ..." */
  function shortenAgainst(name, ownerName) {
    if (!name || !ownerName) return name;
    const words = String(name).split(/\s+/);
    const ownerFirst = String(ownerName).split(/\s+/)[0].toLowerCase();
    let k = 0;
    while (k < words.length - 1 && ownerFirst.startsWith(words[k].toLowerCase())) k++;
    return k ? words.slice(k).join(" ") : name;
  }

  function compareNatural(a, b) {
    return String(a).localeCompare(String(b), undefined, { numeric: true, sensitivity: "base" });
  }

  class UnionFind {
    constructor() { this.p = new Map(); }
    find(x) {
      if (!this.p.has(x)) this.p.set(x, x);
      let r = x;
      while (this.p.get(r) !== r) r = this.p.get(r);
      let c = x;
      while (this.p.get(c) !== r) { const n = this.p.get(c); this.p.set(c, r); c = n; }
      return r;
    }
    union(a, b) { const ra = this.find(a), rb = this.find(b); if (ra !== rb) this.p.set(ra, rb); }
  }

  // ------------------------------------------------------------------ colours

  function wireColor(props, profile) {
    const spec = profile.wireColors || {};
    const raw = first(props, spec.keys || []);
    if (!raw) return null;
    const names = spec.names || {};
    const codes = spec.codes || {};
    const parts = String(raw).split(/[\/\-+ ]+/).filter(Boolean);
    const stripes = [];
    for (const part of parts) {
      const code = codes[part.toUpperCase()];
      const name = (code || part).toLowerCase();
      if (names[name]) stripes.push({ name, hex: names[name] });
      else if (/^#[0-9a-f]{3,8}$/i.test(part)) stripes.push({ name: part, hex: part });
    }
    if (!stripes.length) return null;
    return { label: String(raw), stripes };
  }

  // ------------------------------------------------------------------ builder

  /**
   * Configurations: the graph names variation points, each with alternative variants, and an
   * element that exists only in some configurations lists them in a membership property. The
   * selection (point id -> variant id, falling back to each point's default) picks one variant
   * per point; an element survives when, for every point its list mentions, the selected
   * variant is on the list. Elements that list nothing are in every configuration. Removing a
   * node removes its relationships, and a part removed takes its connectors and their pins.
   */
  function configure(graph, profile, selection = {}) {
    const V = profile.variants;
    const notes = [];
    if (!V) return { graph, points: [], notes };
    const T = profile.text || {};
    const idOf = (n) => String(first(n.props, T.idKeys || ["id"]) ?? `#${n.id}`);
    const nameOf = (n) => String(first(n.props, T.nameKeys || ["name", "id"]) ?? `#${n.id}`);
    const byId = new Map([...graph.nodes.values()].map((n) => [idOf(n), n]));
    const optionRels = new Set(V.optionRelationships || []);
    const points = [];
    const pointOf = new Map(); // variant id -> point
    for (const n of graph.nodes.values()) {
      if (!(V.pointLabels || []).some((l) => n.labels.includes(l))) continue;
      const options = [...graph.rels.values()].filter((r) => r.start === n.id && optionRels.has(r.type)).map((r) => graph.nodes.get(r.end)).filter(Boolean)
        .map((o) => ({ id: idOf(o), name: nameOf(o), node: o }));
      if (!options.length) continue;
      const point = { id: idOf(n), name: nameOf(n), node: n, options, default: String(first(n.props, V.defaultKeys || []) ?? options[0].id) };
      if (!options.some((o) => o.id === point.default)) {
        notes.push({ level: "warning", line: n.lines[0], message: `${point.name}: default ${point.default} is not one of its variants; using ${options[0].name}.` });
        point.default = options[0].id;
      }
      const chosen = selection[point.id];
      point.selected = options.some((o) => o.id === chosen) ? chosen : point.default;
      for (const o of options) pointOf.set(o.id, point);
      points.push(point);
    }
    const listOf = (props) => {
      for (const k of V.memberKeys || []) if (props[k] !== undefined) return (Array.isArray(props[k]) ? props[k] : [props[k]]).map(String);
      return null;
    };
    const keep = (el) => {
      const list = listOf(el.props);
      if (!list) return true;
      const unknown = list.filter((v) => !pointOf.has(v));
      if (unknown.length) notes.push({ level: "warning", line: el.lines?.[0], message: `${unknown.join(", ")} ${unknown.length > 1 ? "are" : "is"} listed as a variant but no variation point offers ${unknown.length > 1 ? "them" : "it"}.` });
      const mentioned = new Set(list.filter((v) => pointOf.has(v)).map((v) => pointOf.get(v)));
      return [...mentioned].every((pt) => list.includes(pt.selected));
    };
    const nodes = new Map([...graph.nodes].filter(([, n]) => keep(n)));
    // A part left out takes its connectors with it, and a connector left out its pins: they are
    // not drawn on their own as free connectors.
    const S = profile.structure || {};
    const owned = new Set([...(S.connectorRelationships || []), ...(S.pinRelationships || [])]);
    const owners = new Map();
    for (const r of graph.rels.values()) if (owned.has(r.type)) { if (!owners.has(r.end)) owners.set(r.end, []); owners.get(r.end).push(r.start); }
    for (let changed = true; changed;) {
      changed = false;
      for (const [id, os] of owners) if (nodes.has(id) && os.every((o) => !nodes.has(o))) { nodes.delete(id); changed = true; }
    }
    const rels = new Map([...graph.rels].filter(([, r]) => nodes.has(r.start) && nodes.has(r.end) && keep(r)));
    const dropped = graph.nodes.size - nodes.size;
    if (points.length && dropped) notes.push({ level: "info", message: `Showing ${points.map((pt) => pt.options.find((o) => o.id === pt.selected).name).join(" · ")}; ${dropped} elements of other configurations are hidden.` });
    const out = new Map(), inn = new Map();
    for (const r of rels.values()) {
      if (!out.has(r.start)) out.set(r.start, []); out.get(r.start).push(r);
      if (!inn.has(r.end)) inn.set(r.end, []); inn.get(r.end).push(r);
    }
    const view = {
      nodes, rels,
      relsOf(id, dir) { return dir === "out" ? out.get(id) || [] : dir === "in" ? inn.get(id) || [] : [...(out.get(id) || []), ...(inn.get(id) || [])]; },
    };
    return { graph: view, points, notes };
  }

  /**
   * The model's description of itself: the dataset, its sources and methods, and the vocabulary
   * (ConceptScheme and Term nodes) that defines every name the graph uses. Metadata nodes are
   * read here and never drawn.
   */
  function readModel(graph, profile) {
    const M = profile.metadata;
    if (!M) return null;
    const has = (n, key) => (M[key] || []).some((l) => n.labels.includes(l));
    const model = { dataset: null, sources: [], methods: [], scheme: null, metaIds: new Set(),
      terms: { labels: new Map(), rels: new Map(), props: new Map(), valueSets: new Map() } };
    const kinds = { node_label: "labels", relationship_type: "rels", property: "props", value_set: "valueSets" };
    for (const n of graph.nodes.values()) {
      if (!(M.labels || []).some((l) => n.labels.includes(l))) continue;
      model.metaIds.add(n.id);
      if (has(n, "datasetLabels") && !model.dataset) model.dataset = n;
      else if (has(n, "sourceLabels")) model.sources.push(n);
      else if (has(n, "methodLabels")) model.methods.push(n);
      else if (has(n, "schemeLabels") && !model.scheme) model.scheme = n;
      else if (has(n, "termLabels")) {
        const bucket = model.terms[kinds[n.props.kind]];
        if (bucket && n.props.name !== undefined) bucket.set(String(n.props.name), n.props);
      }
    }
    return model;
  }

  /** A graph view without some nodes (and every relationship that touches them). */
  function viewWithout(view, dropIds) {
    if (!dropIds.size) return view;
    const nodes = new Map([...view.nodes].filter(([id]) => !dropIds.has(id)));
    const rels = new Map([...view.rels].filter(([, r]) => nodes.has(r.start) && nodes.has(r.end)));
    const out = new Map(), inn = new Map();
    for (const r of rels.values()) {
      if (!out.has(r.start)) out.set(r.start, []); out.get(r.start).push(r);
      if (!inn.has(r.end)) inn.set(r.end, []); inn.get(r.end).push(r);
    }
    return {
      nodes, rels,
      relsOf(id, dir) { return dir === "out" ? out.get(id) || [] : dir === "in" ? inn.get(id) || [] : [...(out.get(id) || []), ...(inn.get(id) || [])]; },
    };
  }

  function buildScene(sourceGraph, profile, library, options = {}) {
    const P = profile;
    const S = P.structure || {};
    const T = P.text || {};
    const PL = P.placement || {};
    const model = readModel(sourceGraph, P);
    const configured = configure(sourceGraph, P, options.variants || {});
    // Metadata describes the model; it is not part of the wiring, so it is never drawn.
    const graph = viewWithout(configured.graph, model ? model.metaIds : new Set());
    const notes = [...configured.notes];
    const nodes = graph.nodes;
    const rels = [...graph.rels.values()];
    const relsByType = new Map();
    for (const r of rels) { if (!relsByType.has(r.type)) relsByType.set(r.type, []); relsByType.get(r.type).push(r); }
    const ofType = (types) => (types || []).flatMap((t) => relsByType.get(t) || []);
    const nameOf = (n) => (n ? String(first(n.props, T.nameKeys || ["name", "id"]) ?? `#${n.id}`) : "");
    const keyOf = (n) => (n ? String(first(n.props, T.idKeys || ["id"]) ?? `#${n.id}`) : "");

    const nodeById = new Map();
    for (const n of nodes.values()) { const k = first(n.props, T.idKeys || ["id"]); if (k !== undefined && !nodeById.has(String(k))) nodeById.set(String(k), n); }

    // ---- node roles ---------------------------------------------------------
    const pinRels = ofType(S.pinRelationships);
    const pinIds = new Set();
    for (const n of nodes.values()) if ((S.pinLabels || []).some((l) => n.labels.includes(l))) pinIds.add(n.id);
    for (const r of pinRels) pinIds.add(r.end);

    const connectorIds = new Set();
    for (const n of nodes.values()) if ((S.connectorLabels || []).some((l) => n.labels.includes(l))) connectorIds.add(n.id);
    const connectorOwner = new Map();
    for (const r of ofType(S.connectorRelationships)) {
      connectorIds.add(r.end);
      if (!connectorOwner.has(r.end)) connectorOwner.set(r.end, r.start);
    }

    const annotationLabels = new Set(P.annotations?.labels || []);
    const netNodeLabels = new Set(P.netNodes?.labels || []);
    const isAnnotation = (n) => n.labels.some((l) => annotationLabels.has(l));
    const isNetNode = (n) => n.labels.some((l) => netNodeLabels.has(l));

    // ---- ranks (left-to-right ordering hints) ----------------------------------
    const groupParentRaw = new Map();
    for (const r of ofType(S.groupRelationships)) if (!groupParentRaw.has(r.end)) groupParentRaw.set(r.end, r.start);
    const pinOwnerRels = new Map();
    for (const r of pinRels) { if (!pinOwnerRels.has(r.end)) pinOwnerRels.set(r.end, []); pinOwnerRels.get(r.end).push(r); }

    const rankCache = new Map();
    const rankOf = (id, depth = 0) => {
      if (rankCache.has(id)) return rankCache.get(id);
      const n = nodes.get(id);
      let v = n ? first(n.props, PL.orderKeys) : undefined;
      v = typeof v === "number" ? v : v !== undefined && !isNaN(+v) ? +v : undefined;
      if (v === undefined && depth < 8) {
        const up = connectorOwner.get(id) ?? groupParentRaw.get(id) ?? pinOwnerRels.get(id)?.[0]?.start;
        if (up !== undefined) v = rankOf(up, depth + 1);
      }
      rankCache.set(id, v);
      return v;
    };

    // ---- symbols and contacts ------------------------------------------------
    const symbols = new Map();
    const contactIndex = new Map();

    const ensureSymbol = (node) => {
      const id = `s${node.id}`;
      if (!symbols.has(id)) {
        symbols.set(id, {
          id, node, key: keyOf(node), name: nameOf(node),
          role: connectorIds.has(node.id) ? "connector" : "component",
          contacts: new Map(), rank: rankOf(node.id), parent: null, kind: "box",
        });
      }
      return symbols.get(id);
    };

    // The mating gender a connector states (male pins or female sockets); null when it states none.
    const genderOf = (node) => {
      const G = S.genders;
      const v = G && first(node?.props || {}, G.keys || []);
      if (v === undefined) return null;
      if (G.female && regexFrom(G.female).test(String(v))) return "female";
      if (G.male && regexFrom(G.male).test(String(v))) return "male";
      return null;
    };

    const sectionOfPin = (pin, owners) => {
      const conn = owners.find((o) => connectorIds.has(o) && connectorOwner.has(o));
      // A connector that lists the positions it uses is drawn with just those, packed together.
      const sparse = Array.isArray(first(nodes.get(conn)?.props || {}, S.populatedPositionKeys || []));
      if (conn !== undefined) return { key: keyOf(nodes.get(conn)), node: nodes.get(conn), name: nameOf(nodes.get(conn)), sparse, gender: genderOf(nodes.get(conn)) };
      const k = first(pin.props, S.sectionKeys);
      if (k === undefined) return null;
      const named = nodeById.get(String(k));
      return named ? { key: String(k), node: named, name: nameOf(named) } : { key: String(k), node: null, name: prettyKey(k) };
    };

    const functionOf = (pin) => {
      const viaRel = ofType(T.pinFunctionRelationships).find((r) => r.start === pin.id);
      if (viaRel) return nameOf(nodes.get(viaRel.end));
      const v = first(pin.props, T.pinFunctionKeys);
      return v !== undefined ? String(v) : null;
    };

    const addContact = (sym, contact) => {
      if (!sym.contacts.has(contact.key)) {
        contact.symbolId = sym.id;
        sym.contacts.set(contact.key, contact);
        contactIndex.set(`${sym.id}|${contact.key}`, contact);
      }
      return sym.contacts.get(contact.key);
    };

    // Logical pins name a signal (an internal GPIO assignment, a differential pair's logical
    // side) rather than a contact you can touch: they merge nets but are never drawn.
    const logicalRules = [
      ...(S.logicalPinKeys || []).map((key) => ({ key, equals: true })),
      ...(S.logicalPins || []),
    ];
    // Lead pins are wires leaving a part with no connector at that end (a fan's flying leads).
    // A lead rule may carry its own `caption` (a splice's joints are not flying leads); the
    // profile's leadCaption is the fallback.
    const leadRule = (pin) => (S.leadPins || []).find((r) => {
      const v = pin.props[r.key];
      if (v === undefined) return false;
      if ("equals" in r) return v === r.equals;
      return r.match ? regexFrom(r.match).test(String(v)) : false;
    }) || null;
    const leadPin = (pin) => leadRule(pin) !== null;
    const logicalPin = (pin) => logicalRules.some((r) => {
      const v = pin.props[r.key];
      if (v === undefined) return false;
      if ("equals" in r) return v === r.equals;
      return r.match ? regexFrom(r.match).test(String(v)) : false;
    });
    const sideWord = (v) => (v === undefined ? null : (PL.sides || {})[String(v).toLowerCase()] || null);
    const numberOf = (v) => (v === undefined || v === null || v === "" || isNaN(+v) ? undefined : +v);

    const pinContact = new Map();
    for (const pinId of pinIds) {
      const pin = nodes.get(pinId);
      if (!pin || isAnnotation(pin)) continue;
      const owners = (pinOwnerRels.get(pinId) || []).map((r) => r.start);
      let symbolNode = null;
      const candidates = [];
      for (const o of owners) {
        if (connectorIds.has(o) && connectorOwner.has(o)) candidates.push(connectorOwner.get(o));
        else candidates.push(o);
      }
      const devices = [...new Set(candidates)].filter((c) => !connectorIds.has(c));
      const pool = devices.length ? devices : [...new Set(candidates)];
      if (pool.length > 1) {
        pool.sort((a, b) => (rankOf(a) ?? 1e9) - (rankOf(b) ?? 1e9));
        notes.push({ level: "warning", line: pin.lines[0], message: `Pin ${keyOf(pin)} belongs to more than one part (${pool.map((x) => keyOf(nodes.get(x))).join(", ")}); drawn on ${keyOf(nodes.get(pool[0]))}.` });
      }
      symbolNode = pool.length ? nodes.get(pool[0]) : pin;
      const sym = ensureSymbol(symbolNode);
      const ownerRel = (pinOwnerRels.get(pinId) || []).find((r) => Object.keys(r.props).length) || (pinOwnerRels.get(pinId) || [])[0];
      const relProps = ownerRel ? ownerRel.props : {};
      let number = null;
      for (const pat of T.pinNumber || []) { number = template(pat, pin.props, relProps); if (number) break; }
      const rule = leadRule(pin);
      const lead = rule !== null;
      const caption = lead ? (rule.caption ?? S.leadCaption) : null;
      const section = sectionOfPin(pin, owners) || (caption ? { key: `__leads:${caption}`, node: null, name: caption, lead: true } : null);
      // A pin's physical side comes from the pin itself, else from the connector it sits in.
      const side = sideWord(first(pin.props, PL.pinSideKeys)) || sideWord(section?.node ? first(section.node.props, PL.pinSideKeys) : undefined);
      const px = numberOf(first(pin.props, PL.positionKeys?.x)), py = numberOf(first(pin.props, PL.positionKeys?.y));
      const c = addContact(sym, {
        key: `p${pin.id}`,
        pin,
        name: String(first(pin.props, T.pinNameKeys) ?? keyOf(pin)),
        number,
        func: functionOf(pin),
        dir: String(first(pin.props, T.pinDirectionKeys) ?? "").toUpperCase(),
        ptype: String(first(pin.props, T.pinTypeKeys) ?? ""),
        section,
        sideHint: side,
        pos: px !== undefined && py !== undefined ? { x: px, y: py } : null,
        order: first({ ...relProps, ...pin.props }, PL.pinOrderKeys),
        logical: logicalPin(pin),
        lead,
        synthetic: false,
      });
      pinContact.set(pinId, c);
    }

    // ---- physical outlines ---------------------------------------------------------
    // A part with a recorded size and pin coordinates is drawn to scale. Pins without a stated
    // side take the side of the outline their connector sits against.
    for (const sym of symbols.values()) {
      const w = numberOf(first(sym.node.props, PL.sizeKeys?.x)), h = numberOf(first(sym.node.props, PL.sizeKeys?.y));
      const located = [...sym.contacts.values()].filter((c) => c.pos && !c.logical);
      if (!w || !h || !located.length) continue;
      sym.outline = { w, h, yUp: PL.positionYUp !== false };
      const bySection = new Map();
      for (const c of located) {
        const k = c.section?.key || c.key;
        if (!bySection.has(k)) bySection.set(k, []);
        bySection.get(k).push(c);
      }
      for (const list of bySection.values()) {
        const cx = list.reduce((a, c) => a + c.pos.x, 0) / list.length / w - 0.5;
        let cy = list.reduce((a, c) => a + c.pos.y, 0) / list.length / h - 0.5;
        if (!sym.outline.yUp) cy = -cy;
        const side = Math.abs(cx) >= Math.abs(cy) ? (cx < 0 ? "WEST" : "EAST") : (cy > 0 ? "NORTH" : "SOUTH");
        for (const c of list) if (!c.sideHint) c.sideHint = side;
      }
    }

    // ---- connections ---------------------------------------------------------
    const connections = [];
    const signalOf = (props) => { const v = first(props, T.signalKeys); return v !== undefined ? String(v) : null; };

    const resolveEndpoint = (nodeId, rel) => {
      const node = nodes.get(nodeId);
      if (!node || isAnnotation(node) || isNetNode(node)) return null;
      if (pinContact.has(nodeId)) return pinContact.get(nodeId);
      const signal = signalOf(rel ? rel.props : {});
      if (connectorOwner.has(nodeId)) {
        const owner = nodes.get(connectorOwner.get(nodeId));
        const sym = ensureSymbol(owner);
        return addContact(sym, {
          key: `c${nodeId}:${norm(signal)}`, pin: null, connector: node,
          name: signal || shortenAgainst(nameOf(node), sym.name),
          number: null, func: null, dir: "", ptype: "",
          section: { key: keyOf(node), node, name: nameOf(node) },
          sideHint: null, pos: null, order: null, logical: false, synthetic: true,
        });
      }
      const sym = ensureSymbol(node);
      return addContact(sym, {
        key: `x:${norm(signal) || "_"}`, pin: null, connector: null,
        name: signal || "",
        number: null, func: null, dir: "", ptype: "",
        section: null, sideHint: null, pos: null, order: null, logical: false, synthetic: true,
      });
    };

    const connectionRules = P.connections || {};
    for (const [type, rule] of Object.entries(connectionRules)) {
      const list = relsByType.get(type) || [];
      for (const rel of list) {
        const startIsPin = pinIds.has(rel.start), endIsPin = pinIds.has(rel.end);
        if (rule.preferPinLevel && !startIsPin && !endIsPin) {
          // Skip a part-level relationship when the same parts are already related pin by pin.
          const pinsOf = (id) => new Set(pinRels.filter((r) => r.start === id).map((r) => r.end));
          const a = pinsOf(rel.start), b = pinsOf(rel.end);
          const covered = list.some((r) => r !== rel && ((a.has(r.start) && b.has(r.end)) || (b.has(r.start) && a.has(r.end))));
          if (covered) { rel.__summarised = true; continue; }
        }
        const a = resolveEndpoint(rel.start, rel), b = resolveEndpoint(rel.end, rel);
        if (!a || !b) {
          notes.push({ level: "warning", line: rel.lines[0], message: `${type} from ${keyOf(nodes.get(rel.start))} to ${keyOf(nodes.get(rel.end))} has an end that is not a drawable part; skipped.` });
          continue;
        }
        connections.push({
          id: `r${rel.id}`, rel, type, style: rule.style || "wire", attach: rule.attach || "tip",
          a, b, props: rel.props, color: wireColor(rel.props, P),
          group: P.wireGroups?.key ? rel.props[P.wireGroups.key] ?? null : null,
          inferred: false,
        });
      }
    }

    // ---- conductors modelled as nodes -------------------------------------------------------
    // A conductor is a thing in its own right: it has a colour and gauge, and it belongs to a
    // twisted pair or a jacket. So a graph gives it a node, and its relationships say only where
    // each end terminates: on a pin, or directly on a junction such as a splice.
    const CN = P.conductors;
    const GR = P.wireGroups || {};
    const conductorLabels = new Set(CN?.labels || []);
    const isConductor = (n) => !!n && n.labels.some((l) => conductorLabels.has(l));
    const isJunctionNode = (n) => !!n && !!P.junctions?.if && ruleMatches({ if: P.junctions.if }, { node: n, role: "component" });
    const memberOf = new Map(); // conductor node id -> { node: group node, role }
    for (const r of ofType(GR.relationships)) {
      const g = nodes.get(r.start);
      if (g && isConductor(nodes.get(r.end)) && !memberOf.has(r.end)) memberOf.set(r.end, { node: g, role: first(r.props, [GR.roleKey || "role"]) ?? null });
    }
    if (CN) {
      const endsOf = new Map();
      for (const r of ofType(CN.endRelationships)) {
        if (!isConductor(nodes.get(r.start))) continue;
        if (!endsOf.has(r.start)) endsOf.set(r.start, []);
        endsOf.get(r.start).push(r);
      }
      const endpoint = (r) => {
        const t = nodes.get(r.end);
        if (!isJunctionNode(t)) return resolveEndpoint(r.end, r);
        // Each conductor ending on a junction gets its own joint contact; all of them are one node.
        return addContact(ensureSymbol(t), {
          key: `j${r.id}`, pin: null, connector: null, name: "", number: null, func: null, dir: "", ptype: "",
          section: null, sideHint: null, pos: null, order: null, logical: false, lead: true, synthetic: true,
          joint: keyOf(t), junctionNode: t,
        });
      };
      for (const node of nodes.values()) {
        if (!isConductor(node)) continue;
        // Ends are ordered by their position along the conductor (KBL Extremity.Position_on_wire,
        // VEC WireEnd.positionOnWire: 0 at the start, 1 at the end), or by an end label.
        const endKeys = CN.endKeys || [CN.endKey || "end"];
        const ends = (endsOf.get(node.id) || []).slice().sort((x, y) => compareNatural(String(first(x.props, endKeys) ?? ""), String(first(y.props, endKeys) ?? "")));
        if (ends.length !== 2) {
          notes.push({ level: "warning", line: node.lines[0], message: `${keyOf(node)} terminates at ${ends.length} place${ends.length === 1 ? "" : "s"}; a conductor has two ends, so it is not drawn.` });
          continue;
        }
        const a = endpoint(ends[0]), b = endpoint(ends[1]);
        if (!a || !b) {
          notes.push({ level: "warning", line: node.lines[0], message: `${keyOf(node)} has an end that is not a drawable part; skipped.` });
          continue;
        }
        const m = memberOf.get(node.id);
        connections.push({
          id: `w${node.id}`, rel: null, node, type: node.labels[0], style: CN.style || "wire", attach: CN.attach || "tip",
          a, b, props: node.props, color: wireColor(node.props, P),
          group: m ? keyOf(m.node) : GR.key ? node.props[GR.key] ?? null : null, groupRole: m ? m.role : null,
          inferred: false,
        });
      }
    }

    // Nets modelled as nodes: every pin on the same net node is joined to the first driver.
    if (P.netNodes) {
      const onNet = ofType(P.netNodes.relationships);
      const byNet = new Map();
      for (const r of onNet) {
        const netNode = nodes.get(r.end);
        if (!netNode || !isNetNode(netNode) || !pinContact.has(r.start)) continue;
        if (!byNet.has(r.end)) byNet.set(r.end, []);
        byNet.get(r.end).push(pinContact.get(r.start));
      }
      for (const [netId, contacts] of byNet) {
        if (contacts.length < 2) continue;
        const score = (c) => (/OUT/.test(c.dir) ? 0 : /POWER_OUT/i.test(c.ptype) ? 0 : 1);
        const sorted = [...contacts].sort((x, y) => score(x) - score(y) || compareNatural(x.symbolId, y.symbolId));
        const hub = sorted[0];
        const netNode = nodes.get(netId);
        for (const c of sorted.slice(1)) {
          connections.push({
            id: `n${netId}:${c.symbolId}:${c.key}`, rel: null, netNode, type: (P.netNodes.relationships || [])[0] || "NET",
            style: "wire", attach: "tip", a: hub, b: c, props: { net: first(netNode.props, P.netNodes.nameKeys) },
            color: null, group: null, inferred: false,
          });
        }
      }
    }

    // ---- symbol kind: KiCad library symbol or generated box ---------------------
    const connectedContacts = new Set();
    for (const c of connections) { connectedContacts.add(c.a); connectedContacts.add(c.b); }

    // ---- joins inside sub-assemblies (e.g. a Y splitter) -------------------------
    if (P.joins?.relationship) {
      const byParent = new Map();
      for (const r of ofType([P.joins.relationship])) {
        if (!byParent.has(r.start)) byParent.set(r.start, []);
        byParent.get(r.start).push(r.end);
      }
      for (const [parentId, childIds] of byParent) {
        const bySignal = new Map();
        for (const childId of childIds) {
          const sym = symbols.get(`s${childId}`);
          if (!sym) continue;
          for (const c of sym.contacts.values()) {
            const k = norm(c.name);
            if (!k) continue;
            if (!bySignal.has(k)) bySignal.set(k, []);
            bySignal.get(k).push(c);
          }
        }
        for (const [signal, contacts] of bySignal) {
          const distinct = [...new Map(contacts.map((c) => [c.symbolId, c])).values()];
          if (distinct.length < 2) continue;
          // The hub is the contact whose outside connection reaches the lowest-ranked part.
          const outsideRank = (c) => {
            let best = Infinity;
            for (const conn of connections) {
              const other = conn.a === c ? conn.b : conn.b === c ? conn.a : null;
              if (!other) continue;
              const r = symbols.get(other.symbolId)?.rank;
              if (r !== undefined && r < best) best = r;
            }
            return best;
          };
          distinct.sort((x, y) => outsideRank(x) - outsideRank(y) || compareNatural(x.symbolId, y.symbolId));
          const hub = distinct[0];
          for (const c of distinct.slice(1)) {
            connections.push({
              id: `j${parentId}:${signal}:${c.symbolId}:${c.key}`, rel: null, type: "inferred join", style: P.joins.style || "join",
              attach: P.joins.attach || "tip", a: hub, b: c, props: { signal: hub.name }, color: null, group: null, inferred: true,
            });
            connectedContacts.add(hub); connectedContacts.add(c);
          }
          notes.push({ level: "info", line: nodes.get(parentId).lines[0], code: "inferred-join", message: `${nameOf(nodes.get(parentId))}: ${hub.name} is shown joined across ${distinct.length} sub-connectors. The graph implies this through ${P.joins.relationship} but does not state it; drawn dashed.` });
        }
      }
    }

    // ---- junction pairs -----------------------------------------------------------------
    // Two junctions whose conductors pair off one for one through twisted-pair groups (a CAN-H
    // splice and its CAN-L twin) are drawn as one junction with a joint each, the way wiring
    // diagrams draw them side by side. They stay two nodes in the graph.
    const pairKeys = GR.pairKeys || [];
    const isPairGroupNode = (g) => !!g && (pairKeys.some((k) => g.props[k] === true) || (!!GR.pairIf && ruleMatches({ if: GR.pairIf }, { node: g, role: "component" })));
    {
      const atJunction = new Map(); // junction symbol id -> [{ conn, end }]
      for (const q of connections) for (const e of [q.a, q.b]) {
        if (!e?.junctionNode) continue;
        if (!atJunction.has(e.symbolId)) atJunction.set(e.symbolId, []);
        atJunction.get(e.symbolId).push({ conn: q, end: e });
      }
      const byGroup = new Map();
      for (const q of connections) if (q.group !== null && q.group !== undefined) { if (!byGroup.has(q.group)) byGroup.set(q.group, []); byGroup.get(q.group).push(q); }
      const twinOf = (sid) => {
        const list = atJunction.get(sid) || [];
        const votes = new Map();
        for (const { conn } of list) {
          const g = nodeById.get(String(conn.group));
          if (!isPairGroupNode(g)) return null;
          const partner = (byGroup.get(conn.group) || []).find((q) => q !== conn);
          if (!partner) return null;
          for (const e of new Set([partner.a.symbolId, partner.b.symbolId])) if (e !== sid && atJunction.has(e)) votes.set(e, (votes.get(e) || 0) + 1);
        }
        const full = [...votes].filter(([, n]) => n === list.length).map(([k]) => k);
        return full.length === 1 && (atJunction.get(full[0]) || []).length === list.length ? full[0] : null;
      };
      for (const sid of [...atJunction.keys()]) {
        const other = twinOf(sid);
        if (!other || !symbols.has(sid) || !symbols.has(other) || twinOf(other) !== sid) continue;
        const [keepId, dropId] = compareNatural(sid, other) <= 0 ? [sid, other] : [other, sid];
        const keep = symbols.get(keepId), drop = symbols.get(dropId);
        for (const [k, c] of drop.contacts) {
          contactIndex.delete(`${dropId}|${k}`);
          c.symbolId = keepId;
          keep.contacts.set(k, c);
          contactIndex.set(`${keepId}|${k}`, c);
        }
        keep.alsoNodes = [...(keep.alsoNodes || []), drop.node];
        symbols.delete(dropId);
        // Each joint takes its conductors' role in their pair (CAN_H, CAN_L) where the graph gives one.
        for (const { conn, end } of [...(atJunction.get(keepId) || []), ...(atJunction.get(dropId) || [])]) if (conn.groupRole) end.joint = String(conn.groupRole);
        atJunction.delete(dropId);
      }
    }

    // ---- nets ------------------------------------------------------------------------
    const uf = new UnionFind();
    const cid = (c) => `${c.symbolId}|${c.key}`;
    for (const c of contactIndex.values()) uf.find(cid(c));
    for (const conn of connections) uf.union(cid(conn.a), cid(conn.b));
    // Every conductor ending on one junction node is on one net.
    const firstAtJunction = new Map();
    for (const c of contactIndex.values()) {
      if (!c.junctionNode) continue;
      if (firstAtJunction.has(c.junctionNode.id)) uf.union(cid(c), firstAtJunction.get(c.junctionNode.id));
      else firstAtJunction.set(c.junctionNode.id, cid(c));
    }
    for (const r of ofType(P.netMerges)) {
      const a = pinContact.get(r.start), b = pinContact.get(r.end);
      if (a && b) uf.union(cid(a), cid(b));
    }
    const nets = new Map();
    for (const c of contactIndex.values()) {
      const root = uf.find(cid(c));
      if (!nets.has(root)) nets.set(root, { id: root, contacts: [], connections: [], names: new Map() });
      nets.get(root).contacts.push(c);
      c.netRoot = root;
    }
    for (const conn of connections) {
      const net = nets.get(uf.find(cid(conn.a)));
      net.connections.push(conn);
      conn.net = net;
      const s = first(conn.props, T.signalKeys);
      if (s !== undefined) net.names.set(String(s), (net.names.get(String(s)) || 0) + 1);
    }
    let netSeq = 0;
    for (const net of nets.values()) {
      const names = [...net.names.entries()].sort((a, b) => b[1] - a[1] || a[0].length - b[0].length);
      net.name = names.length ? names[0][0] : null;
      if (!net.name) {
        const powerPin = net.contacts.find((c) => /power|ground/i.test(c.ptype));
        net.name = powerPin ? powerPin.name : null;
      }
      net.key = `net${++netSeq}`;
      // A view of part of the graph can name a net it leaves out by the name it has in the whole.
      if (!net.name && options.outsideNetNames && !net.connections.some((c) => c.style !== "mate" && c.style !== "join")) {
        const named = net.contacts.map((c) => c.pin && options.outsideNetNames.get(c.pin.id)).find(Boolean);
        if (named) { net.name = named; net.outside = true; }
      }
      if (!net.name) net.name = `N$${netSeq}`;
      net.power = /^(GND|0V|VSS|AGND|DGND|PGND)$|^\+?\d+(\.\d+)?V\d*$|^\+?\d+V\d+$|VCC|VDD|VBUS|VBAT/i.test(net.name)
        || net.contacts.some((c) => /power|ground/i.test(c.ptype));
      for (const c of net.contacts) c.net = net;
    }

    // ---- declared nets and buses --------------------------------------------------------------
    // A graph may name its nets as nodes that conductors belong to, and group nets into buses
    // (a CAN bus carries a CAN_H and a CAN_L net). A declared name wins over one inferred from
    // wire properties; the checks confirm the declarations agree with the connectivity.
    const DN = P.declaredNets;
    const declaredNets = [];
    const derivedOf = new Map(); // declared net node id -> Set of derived nets
    if (DN) {
      const dnLabels = new Set(DN.labels || []);
      const connByNode = new Map(connections.filter((q) => q.node).map((q) => [q.node.id, q]));
      for (const r of ofType(DN.memberRelationships)) {
        const nn = nodes.get(r.end);
        if (!nn || !nn.labels.some((l) => dnLabels.has(l))) continue;
        const net = connByNode.get(r.start)?.net || (pinContact.get(r.start)?.net) || null;
        if (!net) continue;
        if (!derivedOf.has(nn.id)) derivedOf.set(nn.id, new Set());
        derivedOf.get(nn.id).add(net);
      }
      for (const [nid, set] of derivedOf) {
        const nn = nodes.get(nid);
        const name = String(first(nn.props, DN.nameKeys || ["name"]) ?? keyOf(nn));
        // Members the chosen configuration leaves out: without them the net may fall into pieces.
        const all = [...sourceGraph.rels.values()].filter((r) => (DN.memberRelationships || []).includes(r.type) && r.end === nid).length;
        const kept = ofType(DN.memberRelationships).filter((r) => r.end === nid).length;
        declaredNets.push({ node: nn, name, nets: [...set], reduced: kept < all });
        for (const net of set) {
          (net.declared || (net.declared = [])).push(nn);
          if (net.declared.length === 1) net.name = name;
        }
      }
    }
    const BU = P.buses;
    const buses = [];
    if (BU) {
      const buLabels = new Set(BU.labels || []);
      const carries = ofType(BU.relationships);
      for (const n of nodes.values()) {
        if (!n.labels.some((l) => buLabels.has(l))) continue;
        const members = carries.filter((r) => r.start === n.id).map((r) => ({
          role: String(first(r.props, [BU.roleKey || "role"]) ?? ""),
          netNode: nodes.get(r.end),
          nets: [...(derivedOf.get(r.end) || [])],
        }));
        const bus = { id: `bus${n.id}`, key: keyOf(n), name: nameOf(n), node: n, members };
        buses.push(bus);
        for (const m of members) for (const net of m.nets) (net.buses || (net.buses = [])).push({ bus, role: m.role });
      }
    }

    // ---- interfaces ------------------------------------------------------------------
    const interfaceRels = ofType(P.interfaces?.relationships);
    const exposedConnectors = new Map();
    for (const r of interfaceRels) {
      const target = nodes.get(r.end);
      if (!target) continue;
      const label = String(first(target.props, P.interfaces.labelKeys) ?? first(r.props, P.interfaces.labelKeys) ?? nameOf(target));
      exposedConnectors.set(r.end, { rel: r, groupNodeId: r.start, target, label });
    }

    // ---- visibility -------------------------------------------------------------------
    for (const sym of symbols.values()) {
      for (const c of sym.contacts.values()) {
        const exposed = c.section?.node && exposedConnectors.has(c.section.node.id) || exposedConnectors.has(sym.node.id);
        c.exposed = !!exposed;
        c.located = !!(c.pos || (c.sideHint && numberOf(c.order) !== undefined) || (c.sideHint && c.section?.node));
        c.connected = connectedContacts.has(c);
        // Unwired contacts are drawn only on request, in either layout; the physical layout keeps
        // the hidden ones' places, so the drawn pins stay where the graph locates them.
        c.visible = !c.logical && (c.synthetic || c.connected || c.exposed || !!options.showUnconnected);
      }
    }

    // ---- which symbols are drawn --------------------------------------------------------
    for (const [id, sym] of [...symbols]) {
      if (isAnnotation(sym.node) || isNetNode(sym.node)) symbols.delete(id);
    }

    // ---- choose KiCad library symbols -------------------------------------------------------
    for (const sym of symbols.values()) chooseSymbol(sym, P, library, notes);

    // ---- junctions: parts drawn as KiCad junctions, not boxes -----------------------------------
    // A splice is where conductors meet. It is drawn the way KiCad draws a net junction: a short
    // trunk per joint with a dot where each wire tees in, and no body or pin names.
    const J = P.junctions;
    if (J && J.if) {
      for (const sym of symbols.values()) {
        if (sym.kind !== "box" || !ruleMatches({ if: J.if }, sym)) continue;
        sym.junction = true;
        for (const c of sym.contacts.values()) {
          const v = c.pin ? first(c.pin.props, J.jointKeys || []) : undefined;
          c.joint = v !== undefined ? String(v) : c.joint ?? "";
        }
      }
    }

    // ---- groups ---------------------------------------------------------------------------
    const groups = new Map();
    const groupRels = ofType(S.groupRelationships);
    const symbolByNode = new Map([...symbols.values()].map((s) => [s.node.id, s]));
    const childParent = new Map();
    for (const r of groupRels) {
      if (childParent.has(r.end)) {
        if (childParent.get(r.end) !== r.start) notes.push({ level: "info", line: r.lines[0], message: `${keyOf(nodes.get(r.end))} has more than one container; drawn inside ${keyOf(nodes.get(childParent.get(r.end)))}.` });
        continue;
      }
      if (connectorOwner.has(r.end)) continue;
      childParent.set(r.end, r.start);
    }
    const ensureGroup = (nodeId) => {
      const gid = `g${nodeId}`;
      if (!groups.has(gid)) {
        const node = nodes.get(nodeId);
        groups.set(gid, { id: gid, node, key: keyOf(node), name: nameOf(node), subtitle: node.props.type ? String(node.props.type) : "", parent: null, symbols: [], groups: [], ports: [], rank: rankOf(nodeId) });
      }
      return groups.get(gid);
    };
    for (const [childId, parentId] of childParent) {
      const parent = ensureGroup(parentId);
      if (symbolByNode.has(childId)) { const s = symbolByNode.get(childId); s.parent = parent.id; parent.symbols.push(s.id); }
      else {
        const g = ensureGroup(childId);
        g.parent = parent.id;
        parent.groups.push(g.id);
      }
    }
    // Drop groups that contain nothing drawn.
    const hasContent = (g) => g.symbols.length > 0 || g.groups.some((x) => hasContent(groups.get(x)));
    for (const [gid, g] of [...groups]) {
      if (!hasContent(g)) {
        groups.delete(gid);
        if (g.parent && groups.has(g.parent)) groups.get(g.parent).groups = groups.get(g.parent).groups.filter((x) => x !== gid);
      }
    }
    for (const g of groups.values()) if (g.parent && !groups.has(g.parent)) g.parent = null;
    // A group node that is also drawn as a symbol keeps the symbol inside it.
    for (const g of groups.values()) {
      const s = symbolByNode.get(g.node.id);
      if (s && !s.parent) { s.parent = g.id; g.symbols.push(s.id); }
    }
    const ancestors = (containerId) => {
      const out = [];
      let cur = containerId;
      while (cur) { out.push(cur); cur = groups.get(cur)?.parent || null; }
      return out;
    };
    const containerOf = (symId) => symbols.get(symId)?.parent || null;
    const inside = (symId, groupId) => ancestors(containerOf(symId)).includes(groupId);

    // Interface ports: exposed contacts with nothing outside the enclosure get a boundary label.
    const interfaces = [];
    for (const [targetId, info] of exposedConnectors) {
      const gid = `g${info.groupNodeId}`;
      const group = groups.get(gid);
      const contacts = [];
      for (const sym of symbols.values()) {
        for (const c of sym.contacts.values()) {
          if (!c.visible) continue;
          if ((c.section?.node && c.section.node.id === targetId) || sym.node.id === targetId) contacts.push(c);
        }
      }
      const entry = { id: `i${info.rel.id}`, label: info.label, group: group ? group.id : null, target: info.target, contacts, crossings: [], ports: [] };
      for (const c of contacts) {
        const leaves = connections.some((conn) => (conn.a === c || conn.b === c) && group && !inside((conn.a === c ? conn.b : conn.a).symbolId, gid));
        if (leaves || !group) { entry.crossings.push(c); continue; }
        const port = { id: `ip${info.rel.id}:${c.symbolId}:${c.key}`, group: gid, label: `${info.label}`, sub: c.name, contact: c, iface: entry };
        group.ports.push(port);
        entry.ports.push(port);
        connections.push({ id: `if${port.id}`, rel: info.rel, type: "interface", style: "interface", attach: "tip", a: c, b: null, port, props: {}, color: null, group: null, inferred: false, net: c.net });
        c.net.connections.push(connections[connections.length - 1]);
      }
      interfaces.push(entry);
    }

    // ---- annotations ----------------------------------------------------------------------
    const annotations = [];
    for (const n of nodes.values()) {
      if (!isAnnotation(n)) continue;
      const targets = { connections: new Set(), contacts: new Set(), symbols: new Set() };
      for (const r of graph.relsOf(n.id, "out")) {
        if (!(P.annotations.relationships || []).includes(r.type)) continue;
        const t = nodes.get(r.end);
        const tkey = keyOf(t);
        const grouped = connections.filter((c) => c.group !== null && String(c.group) === tkey);
        grouped.forEach((c) => targets.connections.add(c));
        if (symbolByNode.has(t.id)) targets.symbols.add(symbolByNode.get(t.id));
        for (const sym of symbols.values()) for (const c of sym.contacts.values()) {
          if (c.visible && ((c.section?.node && c.section.node.id === t.id) || (c.pin && c.pin.id === t.id))) targets.contacts.add(c);
        }
      }
      annotations.push({
        id: `a${n.id}`, node: n, title: String(first(n.props, P.annotations.titleKeys) ?? nameOf(n)),
        connections: [...targets.connections], contacts: [...targets.contacts], symbols: [...targets.symbols],
      });
    }

    // ---- wire groups for the legend -----------------------------------------------------------
    const wireGroups = new Map();
    for (const c of connections) {
      if (c.group === null || c.group === undefined) continue;
      const k = String(c.group);
      if (!wireGroups.has(k)) {
        const node = nodeById.get(k) || null;
        wireGroups.set(k, { key: k, node, name: node ? nameOf(node) : prettyKey(k), connections: [] });
      }
      wireGroups.get(k).connections.push(c);
    }

    // ---- cables: conductors that share one jacket are routed as one bus ----------------------------
    const bundles = [];
    const bundleKeys = P.wireGroups?.bundleKeys || [];
    // Twisted pairs are routed together as one run when the pairs view is on (the default).
    const isPair = (g) => isPairGroupNode(g.node);
    const hasPairs = [...wireGroups.values()].some(isPair);
    for (const g of wireGroups.values()) {
      const pair = isPair(g);
      if (!g.node || !(bundleKeys.some((k) => g.node.props[k] === true) || (pair && options.pairs !== false))) continue;
      const members = g.connections.filter((c) => c.b && c.a);
      const ends = new Set(members.flatMap((c) => [c.a.symbolId, c.b.symbolId]));
      if (members.length < 2 || ends.size !== 2) {
        notes.push({ level: "info", line: g.node.lines[0], message: `${g.name} is ${pair ? "a twisted pair" : "jacketed"} but its conductors do not all run between the same two parts, so they are drawn as separate wires.` });
        continue;
      }
      const [endA, endB] = [...ends];
      const bundle = { id: `b${g.node.id}`, key: g.key, name: g.name, node: g.node, connections: members, ends: [endA, endB], style: pair ? "pair" : "bus" };
      for (const c of members) c.bundle = bundle;
      bundles.push(bundle);
    }

    // ---- reference designators ------------------------------------------------------------------
    // Only designators recorded in the graph are shown; the viewer does not invent any.
    for (const sym of symbols.values()) {
      const given = first(sym.node.props, T.referenceKeys);
      sym.ref = given !== undefined ? String(given) : "";
    }

    // ---- summary notes ------------------------------------------------------------------------
    let hidden = 0;
    for (const s of symbols.values()) for (const c of s.contacts.values()) if (!c.visible && !c.logical) hidden++;
    if (hidden && !options.showUnconnected) notes.push({ level: "info", code: "hidden-pins", message: `${hidden} unconnected pins are hidden. Turn on "Unconnected pins" to show them.` });
    const summarised = rels.filter((r) => r.__summarised);
    if (summarised.length) notes.push({ level: "info", message: `${summarised.length} part-level ${summarised[0].type} relationship${summarised.length > 1 ? "s are" : " is"} covered by pin-level ones and not drawn twice.` });

    return { symbols, groups, connections, nets, interfaces, annotations, wireGroups, bundles, hasPairs, buses, declaredNets, notes, graph, sourceGraph, model, profile: P, variationPoints: configured.points, partial: !!options.partial };
  }

  // ------------------------------------------------------------------ symbol rules

  function ruleMatches(rule, sym) {
    const cond = rule.if;
    if (!cond) return true;
    if (cond.label && !sym.node.labels.includes(cond.label)) return false;
    if (cond.role && cond.role !== sym.role) return false;
    if (cond.match) {
      const re = regexFrom(cond.match);
      const keys = cond.keys || Object.keys(sym.node.props);
      if (!keys.some((k) => sym.node.props[k] !== undefined && re.test(String(sym.node.props[k])))) return false;
    }
    return true;
  }

  function chooseSymbol(sym, profile, library, notes) {
    sym.kind = "box";
    sym.lib = null;
    if (!library) return;
    const contacts = [...sym.contacts.values()].filter((c) => !c.logical && (sym.role === "connector" || c.visible));
    // A connector with more positions than modelled contacts is drawn with all its positions,
    // unless the graph says only some are populated: then just those, under their own numbers.
    const recorded = Number(first(sym.node.props, (profile.structure || {}).positionKeys || []));
    const populated = sym.role === "connector" ? first(sym.node.props, (profile.structure || {}).populatedPositionKeys || []) : undefined;
    const sparse = Array.isArray(populated) && populated.length > 0 && contacts.every((c) => c.number);
    const n = sparse ? contacts.length : sym.role === "connector" && Number.isFinite(recorded) && recorded > contacts.length ? recorded : contacts.length;
    for (const rule of profile.symbols || []) {
      if (!ruleMatches(rule, sym)) continue;
      const libId = template(rule.use, { n: String(n).padStart(2, "0") }, sym.node.props);
      if (!libId) continue;
      let lib = library.get(libId);
      // As a KiCad user would, keep the library drawing and renumber its pins to the positions in use.
      if (lib && sparse) lib = renumbered(lib, contacts.map((c) => c.number).sort(compareNatural));
      if (!lib) {
        if (!rule.use.includes("{n}")) notes.push({ level: "info", line: sym.node.lines[0], message: `${sym.key}: symbol ${libId} is not in the loaded KiCad libraries; drawn as a box.` });
        continue;
      }
      const mapping = mapPins(contacts, lib);
      if (!mapping) continue;
      sym.kind = "lib";
      sym.lib = lib;
      sym.libId = lib.renumberedAs ? `${libId}, pins numbered ${lib.renumberedAs.join(", ")}` : libId;
      for (const [c, pin] of mapping) c.libPin = pin;
      // Contacts the library symbol cannot hold stay hidden rather than floating.
      for (const c of sym.contacts.values()) if (!mapping.has(c)) c.visible = false;
      return;
    }
  }

  /** A copy of a library symbol whose pins, in their own order, carry the given numbers. */
  function renumbered(lib, numbers) {
    const pins = lib.pins.map((p) => ({ ...p }));
    const order = pins.slice().sort((a, b) => compareNatural(String(a.number), String(b.number)));
    if (order.length !== numbers.length) return lib;
    order.forEach((p, i) => { p.number = String(numbers[i]); });
    return { ...lib, pins, renumberedAs: numbers.map(String) };
  }

  function mapPins(contacts, lib) {
    const pins = lib.pins.filter((p) => !(lib.power && p.hidden) && p.etype !== "no_connect");
    if (contacts.length > pins.length || contacts.length === 0) return null;
    if (lib.power) return null;
    const map = new Map();
    const free = new Set(pins);
    for (const c of contacts) {
      const p = [...free].find((p) => c.number && String(p.number) === String(c.number));
      if (p) { map.set(c, p); free.delete(p); }
    }
    for (const c of contacts) {
      if (map.has(c)) continue;
      const p = [...free].find((p) => norm(p.name) === norm(c.name) && p.name !== "~");
      if (p) { map.set(c, p); free.delete(p); }
    }
    const rest = contacts.filter((c) => !map.has(c)).sort(contactOrder);
    const restPins = [...free].sort((a, b) => compareNatural(a.number, b.number));
    rest.forEach((c, i) => map.set(c, restPins[i]));
    return map;
  }

  function contactOrder(a, b) {
    const oa = a.order ?? a.number, ob = b.order ?? b.number;
    if (oa !== undefined && oa !== null && ob !== undefined && ob !== null) return compareNatural(oa, ob);
    return compareNatural(a.name, b.name);
  }

  /**
   * The part of a graph around some nodes: what owns them (pin, connector, part, enclosure), the
   * nets and buses they are on, their configuration choices and the model metadata. Used for a
   * single net or bus drawn alone, and for one sheet of a large graph.
   */
  function subgraph(G, ids, rules) {
    const keep = new Set(ids);
    const S = rules.structure || {};
    const up = new Set([...(S.pinRelationships || []), ...(S.connectorRelationships || []), ...(S.groupRelationships || [])]);
    const across = new Set([...(rules.declaredNets?.memberRelationships || []), ...(rules.netNodes?.relationships || [])]);
    const toBus = new Set(rules.buses?.relationships || []);
    const groupRels = new Set(rules.wireGroups?.relationships || []);
    const always = new Set([...(rules.variants?.pointLabels || []), ...(rules.metadata?.labels || [])]);
    const byKey = new Map([...G.nodes.values()].map((n) => [String(n.props.id ?? ""), n]));
    for (let pass = 0; pass < 4; pass++) {
      for (const r of G.rels.values()) {
        if (up.has(r.type) && keep.has(r.end)) keep.add(r.start);         // pin -> connector -> part -> enclosure
        if (across.has(r.type) && keep.has(r.start)) keep.add(r.end);     // conductor or pin -> its declared net
        if (toBus.has(r.type) && keep.has(r.end)) keep.add(r.start);      // net -> its bus
      }
    }
    // A free connector (no part owns it) is drawn with a library symbol of its full position
    // count, so all of its pins stay; those of other nets are shown unconnected.
    const pinRels = new Set(S.pinRelationships || []), connRels = new Set(S.connectorRelationships || []);
    const owned = new Set([...G.rels.values()].filter((r) => connRels.has(r.type)).map((r) => r.end));
    // So is a connector that records its populated positions: its symbol holds all of them.
    const popKeys = S.populatedPositionKeys || [];
    const listsPositions = (n) => popKeys.some((k) => Array.isArray(n?.props[k]) && n.props[k].length);
    for (const r of [...G.rels.values()]) if (pinRels.has(r.type) && keep.has(r.start) && (!owned.has(r.start) || listsPositions(G.nodes.get(r.start))) && (S.connectorLabels || []).some((l) => G.nodes.get(r.start)?.labels.includes(l))) keep.add(r.end);
    const members = new Map();
    for (const r of G.rels.values()) if (groupRels.has(r.type) && keep.has(r.end)) members.set(r.start, (members.get(r.start) || 0) + 1);
    for (const [g, count] of members) if (count > 1) keep.add(g);
    for (const n of G.nodes.values()) if (n.labels.some((l) => always.has(l))) keep.add(n.id);
    for (const r of G.rels.values()) if ((rules.variants?.optionRelationships || []).includes(r.type) && keep.has(r.start)) keep.add(r.end);
    // A harness named on a kept conductor is kept too, so the cable keeps its name.
    const harnessKey = rules.wireGroups?.key;
    if (harnessKey) {
      for (const n of G.nodes.values()) if (keep.has(n.id) && n.props[harnessKey] !== undefined) { const h = byKey.get(String(n.props[harnessKey])); if (h) keep.add(h.id); }
      for (const r of G.rels.values()) if (keep.has(r.start) && keep.has(r.end) && r.props[harnessKey] !== undefined) { const h = byKey.get(String(r.props[harnessKey])); if (h) keep.add(h.id); }
    }
    const nodes = new Map([...G.nodes].filter(([id]) => keep.has(id)));
    const rels = new Map([...G.rels].filter(([, r]) => keep.has(r.start) && keep.has(r.end)));
    return { nodes, rels };
  }

  // A sheet is the part of the graph one system covers: the conductors carrying that system in
  // the profile's sheet key, with everything they end on.
  function sheetValues(n, rules) {
    const sh = rules.sheets;
    const v = n.props[sh.key];
    if (v === undefined || v === null) return [];
    return [].concat(v).flatMap((x) => String(x).split(sh.separator || "\u0000")).map((x) => x.trim()).filter(Boolean);
  }

  function sheetsOf(G, rules) {
    const sh = rules.sheets;
    if (!sh || !sh.key) return [];
    const seen = new Set();
    for (const n of G.nodes.values()) if ((sh.labels || []).some((l) => n.labels.includes(l))) for (const v of sheetValues(n, rules)) seen.add(v);
    return [...seen].sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
  }

  function sheetIds(G, rules, sheet) {
    const sh = rules.sheets;
    const ids = new Set();
    for (const n of G.nodes.values()) if ((sh.labels || []).some((l) => n.labels.includes(l)) && sheetValues(n, rules).includes(sheet)) ids.add(n.id);
    for (const r of G.rels.values()) if (ids.has(r.start) && !(rules.declaredNets?.memberRelationships || []).includes(r.type)) ids.add(r.end);
    return [...ids];
  }

  /**
   * The choices that show a sheet: where everything a sheet holds for a variation point belongs
   * to other choices than the one selected (a system of one engine while another engine is
   * chosen), the choice its elements name most often is taken instead; other points are kept.
   */
  function sheetChoices(G, rules, sheet, selection = {}) {
    const V = rules.variants, sh = rules.sheets;
    if (!V || !sh) return { ...selection };
    const { points } = configure(G, rules, selection);
    const out = { ...selection };
    const own = [...G.nodes.values()].filter((n) => (sh.labels || []).some((l) => n.labels.includes(l)) && sheetValues(n, rules).includes(sheet));
    const listOf = (props) => { for (const k of V.memberKeys || []) if (props[k] !== undefined) return [].concat(props[k]).map(String); return []; };
    for (const pt of points) {
      const ids = new Set(pt.options.map((o) => String(o.id)));
      const lists = own.map((n) => listOf(n.props).filter((v) => ids.has(v))).filter((l) => l.length);
      if (!lists.length || lists.some((l) => l.includes(String(pt.selected)))) continue;
      const count = new Map();
      for (const l of lists) for (const v of l) count.set(v, (count.get(v) || 0) + 1);
      out[pt.id] = [...count].sort((a, b) => b[1] - a[1])[0][0];
    }
    return out;
  }

  // ------------------------------------------------------------------ classes of connection
  // The profile's units.classes sort nets by what they carry (power, ground, comms, signals):
  // each class tests a net's declared properties, the first that matches wins, and a class with
  // otherwise takes the rest. A class is drawn for one unit, or across the whole graph.

  const classTest = (rule, props) => {
    for (const k of rule.keys || rule.netKeys || []) {
      const v = props?.[k];
      if (v === undefined || v === null) continue;
      const m = /^\/(.*)\/([a-z]*)$/.exec(rule.match || "");
      if (m ? new RegExp(m[1], m[2]).test(String(v)) : String(v) === String(rule.match)) return true;
    }
    return false;
  };

  /** The class a scene net belongs to, or null when the profile declares none. */
  function netClass(net, rules) {
    const props = Object.assign({}, ...(net.declared || []).map((d) => d.props || {}));
    for (const c of rules.units?.classes || []) {
      if (c.otherwise) return c.name;
      if (classTest(c, props) || (c.buses && (net.buses || []).length)) return c.name;
    }
    return null;
  }

  /** Graph nodes that make up these scene nets: conductors, pins, splices (and a part with no pins). */
  function netMemberIds(nets, scene) {
    const ids = new Set();
    for (const net of nets) {
      for (const c of net.connections) {
        if (c.node) ids.add(c.node.id);
        if (c.rel) { ids.add(c.rel.start); ids.add(c.rel.end); }
      }
      for (const c of net.contacts) {
        if (c.pin) ids.add(c.pin.id);
        else if (c.junctionNode) ids.add(c.junctionNode.id);
        else { const sy = scene.symbols.get(c.symbolId); if (sy?.node) ids.add(sy.node.id); }
      }
    }
    return [...ids];
  }

  /**
   * One class of connection across the whole graph: the nodes of every net of that class, and the
   * name each pin's net has in the whole graph (for pins kept only to complete a connector).
   * `opts.scene` is a scene of the whole graph already built in the configuration wanted.
   */
  function classView(G, rules, library, cls, opts = {}) {
    const whole = opts.scene || buildScene(G, rules, library, { variants: opts.variants || {}, pairs: true });
    const nets = [...whole.nets.values()].filter((n) => n.connections.length && netClass(n, rules) === cls);
    const netNames = new Map();
    for (const sy of whole.symbols.values()) for (const c of sy.contacts.values()) if (c.pin && c.net) netNames.set(c.pin.id, c.net.name);
    return { ids: netMemberIds(nets, whole), netNames, nets: nets.length };
  }

  return { buildScene, configure, readModel, wireColor, template, shortenAgainst, compareNatural, contactOrder, subgraph, sheetsOf, sheetValues, sheetIds, sheetChoices, netClass, netMemberIds, classView };
});
