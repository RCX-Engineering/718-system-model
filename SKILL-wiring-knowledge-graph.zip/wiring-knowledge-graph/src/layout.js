/* ============================================================================
 * Layout
 *
 * Places symbols and routes wires with the Eclipse Layout Kernel (elkjs):
 * layered placement, orthogonal routing, compound nodes for enclosures.
 *
 * Two passes. The first lets ELK choose which side of each part a contact
 * should face and in what order, using physical pin sides where the graph
 * records them. The second draws every symbol exactly on KiCad's 100 mil pin
 * grid, fixes each connection point in place, and routes the final wiring.
 * ========================================================================== */

(function (root, factory) {
  const api = factory(root.KGKicad || (typeof require === "function" ? require("./kicad.js") : null),
                      root.KGScene || (typeof require === "function" ? require("./scene.js") : null));
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.KGLayout = api;
})(typeof self !== "undefined" ? self : this, function (Kicad, Scene) {
  "use strict";

  const PITCH = 100;        // pin pitch, mils
  const PIN_LEN = 100;      // box pin length, mils
  const NAME_SIZE = 50;
  const FUNC_SIZE = 40;
  const NUM_SIZE = 40;
  const CAPTION_SIZE = 36;
  const TEXT_SIZE = 50;
  const NAME_OFFSET = 30;
  const LINE = 66;          // text line advance for 50 mil text
  const WRAP = 26;          // characters per line for part values

  const SIDES = ["WEST", "EAST", "NORTH", "SOUTH"];
  const ceilTo = (v, step) => Math.ceil(v / step) * step;

  function wrapText(text, width = WRAP) {
    const words = String(text || "").split(/\s+/).filter(Boolean);
    const lines = [];
    let cur = "";
    for (const w of words) {
      if (cur && (cur + " " + w).length > width) { lines.push(cur); cur = w; }
      else cur = cur ? cur + " " + w : w;
    }
    if (cur) lines.push(cur);
    return lines.length ? lines : [""];
  }

  // ------------------------------------------------------------------ box symbols

  /**
   * Sections of an edge list whose numbered pins are drawn in ascending number order. Only these
   * keep open rows for skipped positions: the gaps then read as the connector's real pitch.
   */
  function numberedRun(list) {
    const seq = new Map();
    for (const c of list) {
      const k = c.section?.key || "";
      if (!seq.has(k)) seq.set(k, []);
      seq.get(k).push(c.order !== undefined && c.order !== null && !isNaN(+c.order) ? +c.order : null);
    }
    const out = new Set();
    for (const [k, v] of seq) if (v.every((x, i) => x === null || i === 0 || v[i - 1] === null || x > v[i - 1])) out.add(k);
    return out;
  }

  /**
   * Geometry for a generated box symbol in local, Y-down coordinates.
   *
   * Pins always sit on the 100 mil grid, as KiCad requires. Two placements:
   *   physical  rows follow the part's recorded layout: header order, or millimetre
   *             coordinates quantised to the pitch, keeping empty positions so gaps read true;
   *   compact   pins packed one pitch apart in the order enforceRuns chose.
   * Either way a connector's positions form one unbroken run.
   */
  function boxGeometry(sym, sides, measure, opts = {}) {
    const W0 = sides.WEST, E0 = sides.EAST, N = sides.NORTH, S = sides.SOUTH;
    const labelWidth = (c) => measure(c.name, NAME_SIZE) + (c.func && c.func !== c.name ? measure(" " + c.func, FUNC_SIZE) : 0);
    const idle = (c) => !c.connected && !c.synthetic;
    // In the physical layout a pin whose position the graph does not record is marked as such.
    const unplaced = (c) => !!opts.physical && !c.pos && !(c.sideHint && c.order !== undefined && c.order !== null && !isNaN(+c.order));

    const left = W0.length ? PIN_LEN : 0;
    const top = (N.length ? PIN_LEN : 0) + 90;
    const bx = left, by = top;
    const pins = [];
    const captions = [];
    let bodyW, bodyH;

    {
      const caption = (c) => ({ caption: Scene.shortenAgainst(c.section.name, sym.name) });
      const named = (list) => new Set(list.map((c) => c.section?.key || "")).size > 1 || list.some((c) => c.section?.node || c.section?.lead);
      // Millimetre coordinates along a vertical edge, top first; header order otherwise.
      const yUp = sym.outline ? sym.outline.yUp : true;
      const coordOf = (c) => (c.pos ? (yUp ? -c.pos.y : c.pos.y) : null);
      const byCoords = (list) => !!opts.physical && list.length > 0 && list.every((c) => c.pos);
      const byOrder = (list) => !!opts.physical && list.length > 0 && list.every((c) => c.sideHint && c.order !== undefined && c.order !== null && !isNaN(+c.order))
        && new Set(list.map((c) => c.section?.key || "")).size === 1;
      // Both side rows count from one origin, so pins level with each other on the part stay level.
      const sideRows = [...W0, ...E0];
      const coordOrigin = Math.min(...sideRows.filter((c) => c.pos).map((c) => coordOf(c) / 2.54));
      const orderOrigin = Math.min(...sideRows.filter((c) => c.order !== undefined && c.order !== null && !isNaN(+c.order)).map((c) => +c.order));
      const rowsFor = (list) => {
        if (byCoords(list) || byOrder(list)) {
          // Slot each contact by its physical position, one pitch per 2.54 mm (or per header position).
          const key = byCoords(list) ? (c) => coordOf(c) / 2.54 : (c) => +c.order;
          const origin = byCoords(list) ? coordOrigin : orderOrigin;
          // Pins follow their recorded positions along the edge, even where two connectors interleave.
          const sorted = list.slice().sort((a, b) => key(a) - key(b) || Scene.contactOrder(a, b));
          const slots = [];
          let prev = null;
          for (const c of sorted) {
            const want = prev === null ? Math.max(0, Math.round(key(c) - origin)) : Math.max(slots[slots.length - 1].slot + 1, Math.round(key(c) - origin));
            slots.push({ c, slot: want });
            prev = c;
          }
          const rows = [];
          // Interleaved connectors cannot each take a title row; their pin names carry the connector.
          const runs = sorted.map((c) => c.section?.key || "").filter((k, i, a) => !i || k !== a[i - 1]);
          const showCaptions = named(list) && new Set(runs).size === runs.length;
          // Rows stay on their physical slots so both edges line up: a section title may take an
          // empty slot above its first pin, or a lead row shared by both edges, never a slot of its own.
          let last = null;
          rows.lead = null;
          for (const { c, slot } of slots) {
            while (rows.length < slot) rows.push({ empty: true });
            const sk = c.section?.key || "";
            if (showCaptions && sk && sk !== last) {
              if (rows.length && rows[rows.length - 1].empty) rows[rows.length - 1] = caption(c);
              else if (!rows.length) rows.lead = caption(c);
            }
            rows.push({ contact: c });
            last = sk;
          }
          return rows;
        }
        const rows = [];
        const showCaptions = named(list);
        const orderOf = (c) => (c.order !== undefined && c.order !== null && !isNaN(+c.order) ? +c.order : null);
        const inOrder = numberedRun(list);
        let last = null, prev = null;
        for (const c of list) {
          const sk = c.section?.key || "";
          if (showCaptions && sk && sk !== last) rows.push(caption(c));
          // Where a connector skips positions, an open row stands for each one, so the connector
          // keeps its real pitch and a mating plug lines up with it. A connector drawn out of
          // number order (the logical layout) has no pitch to keep, so it takes no open rows.
          else if (prev && sk === last && inOrder.has(sk) && !c.section?.sparse && orderOf(c) !== null && orderOf(prev) !== null && Math.abs(orderOf(c) - orderOf(prev)) > 1) {
            for (let k = 1; k < Math.min(Math.abs(orderOf(c) - orderOf(prev)), 16); k++) rows.push({ empty: true });
          }
          rows.push({ contact: c });
          last = sk;
          prev = c;
        }
        return rows;
      };
      let W = rowsFor(W0), E = rowsFor(E0);
      if (W.lead !== undefined || E.lead !== undefined) {
        if (W.lead || E.lead) { W = [W.lead || { empty: true }, ...W]; E = [E.lead || { empty: true }, ...E]; }
      }
      const rowWidth = (r) => (r.caption ? measure(r.caption, CAPTION_SIZE) : r.contact ? labelWidth(r.contact) : 0);
      const wW = Math.max(0, ...W.map(rowWidth));
      const wE = Math.max(0, ...E.map(rowWidth));
      const vN = Math.max(0, ...N.map(labelWidth));
      const vS = Math.max(0, ...S.map(labelWidth));
      // Rotated names of top and bottom pins take a band of the body, so side rows start below it.
      const bandTop = N.length ? ceilTo(vN + NAME_OFFSET + 30, PITCH) : 0;
      const bandBottom = S.length ? ceilTo(vS + NAME_OFFSET + 30, PITCH) : 0;
      // Top and bottom pins take one slot each; where a connector skips positions, the skipped
      // ones keep their slots, as on the side edges, so a mating plug lines up with it.
      const edgeSlots = (list) => {
        const out = [];
        const inOrder = numberedRun(list);
        list.forEach((c, j) => {
          const prev = list[j - 1];
          const oc = c.order !== undefined && c.order !== null && !isNaN(+c.order) ? +c.order : null;
          const op = prev && prev.order !== undefined && prev.order !== null && !isNaN(+prev.order) ? +prev.order : null;
          const gap = prev && (c.section?.key || "") === (prev.section?.key || "") && inOrder.has(c.section?.key || "") && !c.section?.sparse && oc !== null && op !== null ? Math.min(Math.abs(oc - op), 16) : 1;
          out.push(j ? out[j - 1] + Math.max(1, gap) : 0);
        });
        return out;
      };
      const slotN = edgeSlots(N), slotS = edgeSlots(S);
      const spanN = N.length ? slotN[N.length - 1] + 1 : 0, spanS = S.length ? slotS[S.length - 1] + 1 : 0;
      bodyW = ceilTo(Math.max(wW + wE + 2 * NAME_OFFSET + (wW && wE ? 120 : 60), (spanN + 1) * PITCH, (spanS + 1) * PITCH, 500), PITCH);
      bodyH = ceilTo(Math.max(bandTop + Math.max(W.length, E.length, 1) * PITCH + PITCH + bandBottom, 300), PITCH);
      W.forEach((r, i) => {
        const y = by + bandTop + (i + 1) * PITCH;
        if (r.caption) { captions.push({ text: r.caption, x: bx + NAME_OFFSET, y, anchor: "start" }); return; }
        if (r.empty) return;
        pins.push({ contact: r.contact, side: "WEST", tip: [bx - PIN_LEN, y], base: [bx, y], name: [bx + NAME_OFFSET, y], anchor: "start", num: [bx - PIN_LEN / 2, y - 14], idle: idle(r.contact) });
      });
      E.forEach((r, i) => {
        const y = by + bandTop + (i + 1) * PITCH;
        const x2 = bx + bodyW;
        if (r.caption) { captions.push({ text: r.caption, x: x2 - NAME_OFFSET, y, anchor: "end" }); return; }
        if (r.empty) return;
        pins.push({ contact: r.contact, side: "EAST", tip: [x2 + PIN_LEN, y], base: [x2, y], name: [x2 - NAME_OFFSET, y], anchor: "end", num: [x2 + PIN_LEN / 2, y - 14], idle: idle(r.contact) });
      });
      N.forEach((c, j) => {
        const x = bx + (slotN[j] + 1) * PITCH;
        pins.push({ contact: c, side: "NORTH", tip: [x, by - PIN_LEN], base: [x, by], name: [x, by + NAME_OFFSET], anchor: "end", rotate: -90, num: [x - 14, by - PIN_LEN / 2], idle: idle(c) });
      });
      S.forEach((c, j) => {
        const x = bx + (slotS[j] + 1) * PITCH;
        pins.push({ contact: c, side: "SOUTH", tip: [x, by + bodyH + PIN_LEN], base: [x, by + bodyH], name: [x, by + bodyH - NAME_OFFSET], anchor: "start", rotate: -90, num: [x - 14, by + bodyH + PIN_LEN / 2], idle: idle(c) });
      });
      // A connector along the top or bottom edge is titled just inside its band of pin names.
      if (named([...W0, ...E0, ...N, ...S])) {
        const titled = (list, slots, y) => {
          let last = null;
          list.forEach((c, j) => {
            const sk = c.section?.key || "";
            if (sk && sk !== last && (c.section.node || c.section.lead)) captions.push({ text: Scene.shortenAgainst(c.section.name, sym.name), x: bx + (slots[j] + 1) * PITCH - 20, y, anchor: "start" });
            last = sk;
          });
        };
        titled(N, slotN, by + bandTop + 45);
        titled(S, slotS, by + bodyH - bandBottom - 45);
      }
    }

    // Reference above and value below, as KiCad places them, moved clear of any top or bottom pins
    // so no wire leaving a pin runs through the text.
    const refText = sym.ref || "";
    const valueLines = wrapText(sym.name);
    const titleW = Math.max(measure(refText, TEXT_SIZE), ...valueLines.map((l) => measure(l, TEXT_SIZE)));
    const lastNorthX = N.length ? Math.max(...pins.filter((p) => p.side === "NORTH").map((p) => p.tip[0])) : bx;
    const textX = N.length ? lastNorthX + PITCH + 20 : bx;
    let ref, value, height;
    if (!S.length) {
      ref = { text: refText, x: textX, y: by - 26, anchor: "start", size: TEXT_SIZE };
      value = { lines: valueLines, x: bx, y: by + bodyH + 70, anchor: "start", size: TEXT_SIZE };
      height = value.y + (valueLines.length - 1) * LINE + 30;
    } else {
      const valueTop = by - 26 - (valueLines.length - 1) * LINE;
      value = { lines: valueLines, x: textX, y: valueTop, anchor: "start", size: TEXT_SIZE };
      ref = { text: refText, x: textX, y: valueTop - LINE, anchor: "start", size: TEXT_SIZE };
      height = by + bodyH + PIN_LEN + 20;
    }
    const minTop = ref.y - 60;
    const shift = minTop < 0 ? -minTop : 0;
    const width = Math.max(left + bodyW + (E0.length ? PIN_LEN : 0), textX + titleW + 20);
    const moved = (pt) => (pt ? [pt[0], pt[1] + shift] : pt);
    return {
      kind: "box", width, height: height + shift,
      body: { x: bx, y: by + shift, w: bodyW, h: bodyH },
      pins: pins.map((p) => ({ ...p, unplaced: unplaced(p.contact), gender: p.contact.section?.gender || null, tip: moved(p.tip), base: moved(p.base), name: moved(p.name), num: moved(p.num) })),
      captions: captions.map((c) => ({ ...c, y: c.y + shift })),
      ref: { ...ref, y: ref.y + shift }, value: { ...value, y: value.y + shift },
    };
  }

  // ------------------------------------------------------------------ junction symbols

  /**
   * Geometry for a part drawn as a KiCad junction (a splice). Each joint is a short vertical
   * trunk; each conductor reaches its joint from the west or east edge along its own row, on the
   * 100 mil grid, and a dot marks every point where three or more lines meet. Rows arrive in the
   * order given; there is no body outline and no pin text.
   */
  function junctionGeometry(sym, sides, measure) {
    const W = sides.WEST, E = sides.EAST;
    const joints = [...new Set([...W, ...E].map((c) => c.joint || ""))].sort(Scene.compareNatural);
    const bx = PIN_LEN, bodyW = Math.max(1, joints.length) * PITCH;
    const trunkX = (j) => bx + PITCH / 2 + joints.indexOf(j) * PITCH;
    const rows = Math.max(W.length, E.length, 1);
    const bodyH = (rows + 1) * PITCH;
    const pins = [];
    const idle = (c) => !c.connected && !c.synthetic;
    W.forEach((c, i) => {
      const y = (i + 1) * PITCH;
      pins.push({ contact: c, side: "WEST", tip: [0, y], base: [bx, y], name: [bx, y], anchor: "start", num: [bx / 2, y - 14], idle: idle(c), hideName: true, joint: c.joint || "", reach: trunkX(c.joint || "") });
    });
    E.forEach((c, i) => {
      const y = (i + 1) * PITCH;
      const x2 = bx + bodyW;
      pins.push({ contact: c, side: "EAST", tip: [x2 + PIN_LEN, y], base: [x2, y], name: [x2, y], anchor: "end", num: [x2 + PIN_LEN / 2, y - 14], idle: idle(c), hideName: true, joint: c.joint || "", reach: trunkX(c.joint || "") });
    });
    const trunks = joints.map((j) => {
      const ys = pins.filter((p) => p.joint === j).map((p) => p.tip[1]);
      return { joint: j, x: trunkX(j), y1: Math.min(...ys), y2: Math.max(...ys) };
    }).filter((t) => isFinite(t.y1));
    // A dot wherever three or more lines meet: stubs arriving at the trunk plus the trunk above or below.
    const dots = [];
    for (const t of trunks) {
      const at = new Map();
      for (const p of pins) if (p.joint === t.joint) at.set(p.tip[1], (at.get(p.tip[1]) || 0) + 1);
      for (const [y, n] of at) {
        const lines = n + (y > t.y1 ? 1 : 0) + (y < t.y2 ? 1 : 0);
        if (lines >= 3) dots.push({ joint: t.joint, x: t.x, y });
      }
    }
    // A junction carries no text, as in KiCad; its identity is in the inspector.
    const value = { lines: [], x: 0, y: bodyH, anchor: "start", size: TEXT_SIZE };
    const ref = { text: "", x: 0, y: 0, anchor: "start", size: TEXT_SIZE };
    const width = bx + bodyW + PIN_LEN;
    return {
      kind: "box", junction: true, width, height: bodyH + PITCH / 2,
      body: { x: bx, y: PITCH / 2, w: bodyW, h: bodyH - PITCH },
      pins: pins.map((p) => ({ ...p, unplaced: false, gender: null })),
      captions: [], trunks, dots, ref, value,
    };
  }

  // ------------------------------------------------------------------ library symbols

  /**
   * Geometry for a KiCad library symbol. `tf` mirrors and rotates it the way
   * KiCad places symbols: mirror about the Y axis first, then rotate
   * counter-clockwise by 0, 90, 180 or 270 degrees.
   */
  function libGeometry(sym, tf, measure) {
    const lib = sym.lib;
    const rot = ((tf.rot || 0) % 360 + 360) % 360;
    const T = ([x, y]) => {
      let X = tf.mirror ? -x : x, Y = y;
      if (rot === 90) [X, Y] = [-Y, X];
      else if (rot === 180) [X, Y] = [-X, -Y];
      else if (rot === 270) [X, Y] = [Y, -X];
      return [X, Y];
    };
    const TA = (a) => { let b = tf.mirror ? (a === 0 ? 180 : a === 180 ? 0 : a) : a; return (b + rot) % 360; };

    const shapes = [];
    const pts = [];
    const add = (x, y) => pts.push([x, y]);
    const body = { x1: Infinity, y1: Infinity, x2: -Infinity, y2: -Infinity };
    const addBody = ([x, y]) => { add(x, y); body.x1 = Math.min(body.x1, x); body.x2 = Math.max(body.x2, x); body.y1 = Math.min(body.y1, y); body.y2 = Math.max(body.y2, y); };
    for (const g of lib.graphics) {
      if (g.type === "rect") {
        const c = [T([g.x1, g.y1]), T([g.x2, g.y1]), T([g.x2, g.y2]), T([g.x1, g.y2])];
        c.forEach(addBody);
        shapes.push({ type: "poly", pts: [...c, c[0]], width: g.width, fill: g.fill });
      } else if (g.type === "polyline" || g.type === "bezier") {
        const q = g.pts.map(T); q.forEach(addBody);
        shapes.push({ type: "poly", pts: q, width: g.width, fill: g.fill });
      } else if (g.type === "circle") {
        const [cx, cy] = T([g.cx, g.cy]);
        addBody([cx - g.r, cy - g.r]); addBody([cx + g.r, cy + g.r]);
        shapes.push({ type: "circle", c: [cx, cy], r: g.r, width: g.width, fill: g.fill });
      } else if (g.type === "arc") {
        const q = Kicad.arcPoints(g, 16).map(T); q.forEach(addBody);
        shapes.push({ type: "poly", pts: q, width: g.width, fill: g.fill });
      } else if (g.type === "text") {
        const [x, y] = T([g.x, g.y]); add(x, y);
        shapes.push({ type: "text", text: g.text, at: [x, y], size: g.size });
      }
    }
    if (body.x1 === Infinity) Object.assign(body, { x1: -50, x2: 50, y1: -50, y2: 50 });

    const contacts = [...sym.contacts.values()].filter((c) => c.libPin);
    const byPin = new Map(contacts.map((c) => [c.libPin, c]));
    const faceUsed = contacts.some((c) => c.faceUsed);
    const pins = lib.pins.filter((p) => !p.hidden).map((p) => {
      const angle = TA(p.angle);
      const a = (angle * Math.PI) / 180;
      const tip = T([p.x, p.y]);
      const base = [tip[0] + Math.cos(a) * p.length, tip[1] + Math.sin(a) * p.length];
      add(...tip); add(...base);
      const side = angle === 0 ? "WEST" : angle === 180 ? "EAST" : angle === 90 ? "SOUTH" : "NORTH";
      let face;
      if (side === "WEST") face = [body.x2, tip[1]];
      else if (side === "EAST") face = [body.x1, tip[1]];
      else if (side === "SOUTH") face = [tip[0], body.y2];
      else face = [tip[0], body.y1];
      return { lib: p, contact: byPin.get(p) || null, side, tip, base, face, angle };
    });

    // Captions carry the graph's contact names, since library connector pins are unnamed.
    // A name the symbol already states (its own pin number or pin name) is not repeated. On a
    // part with pins on opposite sides (a diode, a switch) the far side belongs to other pins, so
    // a name sits on its own incoming wire instead of across the body.
    const sidesUsed = new Set(pins.filter((p) => p.contact).map((p) => p.side));
    const twoSided = (sidesUsed.has("WEST") && sidesUsed.has("EAST")) || (sidesUsed.has("NORTH") && sidesUsed.has("SOUTH"));
    const captions = [];
    for (const pin of pins) {
      const c = pin.contact;
      if (!c || !c.name || (!lib.pinNamesHidden && pin.lib.name && pin.lib.name !== "~")) continue;
      if (c.name === pin.lib.number || c.name === pin.lib.name) continue;
      const w = measure(c.name, CAPTION_SIZE + 4);
      if (pin.side === "WEST" || pin.side === "EAST") {
        if (!faceUsed && !twoSided) {
          const x = pin.side === "WEST" ? body.x2 + 30 : body.x1 - 30;
          captions.push({ text: c.name, x, y: pin.tip[1], anchor: pin.side === "WEST" ? "start" : "end" });
          add(pin.side === "WEST" ? x + w : x - w, pin.tip[1] - 30); add(x, pin.tip[1] + 30);
        } else {
          // The mating face is taken, so the name sits on the incoming wire like a KiCad net label.
          const x = pin.side === "WEST" ? pin.tip[0] - 24 : pin.tip[0] + 24;
          captions.push({ text: c.name, x, y: pin.tip[1] + 22, anchor: pin.side === "WEST" ? "end" : "start", onWire: true });
          add(pin.side === "WEST" ? x - w : x + w, pin.tip[1] + 60); add(x, pin.tip[1]);
        }
      } else {
        const y = (pin.tip[1] + pin.base[1]) / 2;
        captions.push({ text: c.name, x: pin.tip[0] + 30, y, anchor: "start" });
        add(pin.tip[0] + 30 + w, y + 30);
      }
    }

    // Reference above and value below the body, as KiCad lays out connector fields. A side
    // that has pins leaving it is taken by wiring, so the text moves to a free side instead.
    // A seated plug's name runs out along open space, so it stays on one line.
    const valueLines = wrapText(sym.name, tf.fields ? 80 : 22);
    let top = -Infinity, bottom = Infinity, right = -Infinity, leftX = Infinity;
    for (const [x, y] of pts) { top = Math.max(top, y); bottom = Math.min(bottom, y); right = Math.max(right, x); leftX = Math.min(leftX, x); }
    const taken = new Set(pins.map((p) => p.side));
    const cx = (body.x1 + body.x2) / 2, cy = (body.y1 + body.y2) / 2;
    const refW = sym.ref ? measure(sym.ref, TEXT_SIZE) : 0;
    const valW = Math.max(...valueLines.map((l) => measure(l, TEXT_SIZE)));
    const valH = (valueLines.length - 1) * LINE;
    let refPos, valPos;
    const sideX = !taken.has("EAST") ? right + 60 : !taken.has("WEST") ? leftX - 60 : null;
    const sideAnchor = !taken.has("EAST") ? "start" : "end";
    if (!taken.has("NORTH")) refPos = { x: cx, y: top + 50, anchor: "middle" };
    else if (sideX !== null) refPos = { x: sideX, y: cy + 60 + valH / 2, anchor: sideAnchor };
    else refPos = { x: cx, y: top + 50, anchor: "middle" };
    if (!taken.has("SOUTH")) valPos = { x: cx, y: bottom - 75, anchor: "middle" };
    else if (sideX !== null) valPos = { x: sideX, y: (taken.has("NORTH") ? refPos.y - LINE : cy + 20 + valH / 2), anchor: sideAnchor };
    else valPos = { x: cx, y: bottom - 75, anchor: "middle" };
    // A plug drawn against its mate keeps its text on the side away from the mate's other pins.
    // The text also runs away from the mate (tf.away is the direction the plug's wires leave).
    if (tf.fields) {
      const fx = tf.away === "WEST" ? body.x2 : tf.away === "EAST" ? body.x1 : cx;
      const anchor = tf.away === "WEST" ? "end" : tf.away === "EAST" ? "start" : "middle";
      if (tf.fields === "NORTH") { valPos = { x: fx, y: top + 50 + valH, anchor }; refPos = { x: fx, y: valPos.y + LINE, anchor }; }
      else { valPos = { x: fx, y: bottom - 75, anchor }; refPos = { x: fx, y: bottom - 75 - valH - LINE, anchor }; }
    }
    const extent = (pos, w) => (pos.anchor === "middle" ? [pos.x - w / 2, pos.x + w / 2] : pos.anchor === "start" ? [pos.x, pos.x + w] : [pos.x - w, pos.x]);
    if (sym.ref) { const [a, b] = extent(refPos, refW); add(a, refPos.y + 30); add(b, refPos.y - 20); }
    { const [a, b] = extent(valPos, valW); add(a, valPos.y + 30); add(b, valPos.y - valH - 25); }

    let x1 = Infinity, y1 = Infinity, x2 = -Infinity, y2 = -Infinity;
    for (const [x, y] of pts) { x1 = Math.min(x1, x); x2 = Math.max(x2, x); y1 = Math.min(y1, y); y2 = Math.max(y2, y); }
    const pad = 10;
    const L = ([x, y]) => [x - x1 + pad, y2 - y + pad];
    return {
      kind: "lib", tf: { mirror: !!tf.mirror, rot }, width: x2 - x1 + 2 * pad, height: y2 - y1 + 2 * pad,
      shapes: shapes.map((sh) => sh.type === "poly" ? { ...sh, pts: sh.pts.map(L) } : sh.type === "circle" ? { ...sh, c: L(sh.c) } : { ...sh, at: L(sh.at) }),
      pins: pins.map((p) => ({ ...p, tip: L(p.tip), base: L(p.base), face: L(p.face) })),
      captions: captions.map((c) => { const [x, y] = L([c.x, c.y]); return { ...c, x, y }; }),
      ref: (() => { const [x, y] = L([refPos.x, refPos.y]); return { text: sym.ref, x, y, anchor: refPos.anchor, size: TEXT_SIZE }; })(),
      value: (() => { const [x, y] = L([valPos.x, valPos.y]); return { lines: valueLines, x, y, anchor: valPos.anchor, size: TEXT_SIZE }; })(),
      numbersHidden: lib.pinNumbersHidden,
    };
  }

  // ------------------------------------------------------------------ ELK graph

  const BASE_OPTIONS = {
    "elk.algorithm": "layered",
    "elk.direction": "RIGHT",
    "elk.edgeRouting": "ORTHOGONAL",
    "elk.hierarchyHandling": "INCLUDE_CHILDREN",
    "elk.json.edgeCoords": "ROOT",
    "elk.json.shapeCoords": "ROOT",
    "elk.spacing.nodeNode": "260",
    "elk.layered.spacing.nodeNodeBetweenLayers": "420",
    "elk.spacing.edgeEdge": "60",
    "elk.spacing.edgeNode": "120",
    "elk.layered.spacing.edgeEdgeBetweenLayers": "60",
    "elk.layered.spacing.edgeNodeBetweenLayers": "140",
    "elk.spacing.portPort": "100",
    "elk.spacing.componentComponent": "400",
    "elk.layered.nodePlacement.strategy": "BRANDES_KOEPF",
    "elk.layered.nodePlacement.bk.fixedAlignment": "BALANCED",
    "elk.layered.nodePlacement.favorStraightEdges": "true",
    "elk.layered.unnecessaryBendpoints": "true",
    "elk.layered.mergeEdges": "false",
  };
  const GROUP_PADDING = "[top=260,left=160,bottom=160,right=160]";

  /**
   * Two nets whose runs sit on one line with a small gap read as one wire. Move an interior
   * run of one of them sideways, half a grid at a time, where that creates no new contact.
   */
  async function nudgeCollinear(out, progress = null) {
    const GAP = 400, E = 0.5;
    const items = [];
    for (const [id, e] of out.edges) {
      if (e.docked || e.bus) continue;
      // Drop repeated points and merge runs that continue in a straight line.
      e.sections = e.sections.map((sec) => {
        const pts = sec.filter((p, i) => !i || Math.abs(p[0] - sec[i - 1][0]) > E || Math.abs(p[1] - sec[i - 1][1]) > E);
        return pts.filter((p, i) => {
          if (!i || i === pts.length - 1) return true;
          const a = pts[i - 1], b = pts[i + 1];
          return !((Math.abs(a[0] - p[0]) < E && Math.abs(p[0] - b[0]) < E) || (Math.abs(a[1] - p[1]) < E && Math.abs(p[1] - b[1]) < E));
        });
      });
      e.sections.forEach((sec, si) => items.push({ id, e, sec, si }));
    }
    const netOf = new Map();
    for (const c of out.connections || []) netOf.set(c.id, c.net?.key || c.id);
    const segsOf = () => {
      const list = [];
      for (const it of items) for (let k = 1; k < it.sec.length; k++) list.push({ it, k, a: it.sec[k - 1], b: it.sec[k], net: it.e.netKey ?? netOf.get(it.id) ?? it.id });
      return list;
    };
    const vertical = (sg) => Math.abs(sg.a[0] - sg.b[0]) < E && Math.abs(sg.a[1] - sg.b[1]) > E;
    const horizontal = (sg) => Math.abs(sg.a[1] - sg.b[1]) < E && Math.abs(sg.a[0] - sg.b[0]) > E;
    const span = (sg, v) => (v ? [Math.min(sg.a[1], sg.b[1]), Math.max(sg.a[1], sg.b[1])] : [Math.min(sg.a[0], sg.b[0]), Math.max(sg.a[0], sg.b[0])]);
    const line = (sg, v) => (v ? sg.a[0] : sg.a[1]);
    // Same line with a small gap, or side by side closer than a wire is wide: both read wrongly.
    const SIDE = 40;
    const tooNear = (A, B, v) => {
      const d = Math.abs(line(A, v) - line(B, v));
      const [a1, a2] = span(A, v), [b1, b2] = span(B, v);
      if (d < E) { const gap = a2 < b1 ? b1 - a2 : b2 < a1 ? a1 - b2 : -1; return gap >= 0 && gap <= GAP; }
      return d < SIDE && Math.min(a2, b2) - Math.max(a1, b1) > E;
    };
    // Offsets to try when moving a run: the usual half-grid steps, then the middle of each gap
    // between neighbouring parallel runs of other nets, nearest first.
    const offsetsFor = (lineAt, lo, hi, v, net, others) => {
      const lines = others.filter((o) => (v ? vertical(o) : horizontal(o))).filter((o) => {
        const [a, b] = span(o, v); return Math.min(hi, b) - Math.max(lo, a) > E && Math.abs(line(o, v) - lineAt) < 400;
      }).map((o) => line(o, v)).sort((a, b) => a - b);
      const mids = [];
      for (let i = 1; i < lines.length; i++) if (lines[i] - lines[i - 1] >= 2 * SIDE) mids.push((lines[i] + lines[i - 1]) / 2 - lineAt);
      const extra = mids.filter((d) => Math.abs(d) > E).sort((a, b) => Math.abs(a) - Math.abs(b));
      // Where the half-grid steps and gaps are all taken, step clear of the crowd.
      return [50, -50, 100, -100, ...extra, 150, -150, 200, -200];
    };
    // A run laid on another conductor's run, even of its own net, reads as one wire spliced.
    const overlays = (sg, others) => others.some((o) => {
      const sv = vertical(sg);
      if (!(sv ? vertical(o) : horizontal(o)) || Math.abs(line(o, sv) - line(sg, sv)) > E) return false;
      const [a1, a2] = span(sg, sv), [b1, b2] = span(o, sv);
      return Math.min(a2, b2) - Math.max(a1, b1) > E;
    });
    const touches = (sg, others) => others.some((o) => {
      if (o.net === sg.net) return false;
      const [x1, x2] = [Math.min(o.a[0], o.b[0]), Math.max(o.a[0], o.b[0])], [y1, y2] = [Math.min(o.a[1], o.b[1]), Math.max(o.a[1], o.b[1])];
      const [sx1, sx2] = [Math.min(sg.a[0], sg.b[0]), Math.max(sg.a[0], sg.b[0])], [sy1, sy2] = [Math.min(sg.a[1], sg.b[1]), Math.max(sg.a[1], sg.b[1])];
      const overlapX = sx1 <= x2 + E && x1 <= sx2 + E, overlapY = sy1 <= y2 + E && y1 <= sy2 + E;
      if (!overlapX || !overlapY) return false;
      // Crossing at right angles is fine; sharing a line or ending on another run is not.
      const sv = vertical(sg), ov = vertical(o);
      if (sv !== ov) {
        const [px, py] = sv ? [sg.a[0], o.a[1]] : [o.a[0], sg.a[1]];
        const endOf = (q) => [q.a, q.b].some((p) => Math.abs(p[0] - px) < E && Math.abs(p[1] - py) < E);
        return endOf(sg) || endOf(o);
      }
      return true;
    });
    // Runs indexed by area: each test below reads only the runs whose extent can satisfy it,
    // so a large sheet costs what its crowded corners cost, not the square of its runs.
    // Every test keeps the result a scan of the whole sheet gives (the first match in run order).
    const CELL = 400;
    const cellKey = (gx, gy) => gx * 1048576 + gy;
    let stamp = 0;
    const indexOf = (list) => {
      const cells = new Map();
      list.forEach((sg, i) => {
        sg.i = i;
        const gx1 = Math.floor(Math.min(sg.a[0], sg.b[0]) / CELL), gx2 = Math.floor(Math.max(sg.a[0], sg.b[0]) / CELL);
        const gy1 = Math.floor(Math.min(sg.a[1], sg.b[1]) / CELL), gy2 = Math.floor(Math.max(sg.a[1], sg.b[1]) / CELL);
        for (let gx = gx1; gx <= gx2; gx++) for (let gy = gy1; gy <= gy2; gy++) {
          const k = cellKey(gx, gy);
          const c = cells.get(k);
          if (c) c.push(sg); else cells.set(k, [sg]);
        }
      });
      return cells;
    };
    // Runs whose extent meets the box [x1, y1]–[x2, y2], each once, in run order.
    const within = (cells, x1, y1, x2, y2) => {
      const mark = ++stamp, out = [];
      for (let gx = Math.floor(x1 / CELL); gx <= Math.floor(x2 / CELL); gx++) for (let gy = Math.floor(y1 / CELL); gy <= Math.floor(y2 / CELL); gy++) {
        for (const sg of cells.get(cellKey(gx, gy)) || []) if (sg.seen !== mark) { sg.seen = mark; out.push(sg); }
      }
      return out.sort((p, q) => p.i - q.i);
    };
    const boxOf = (sg, pad) => [Math.min(sg.a[0], sg.b[0]) - pad, Math.min(sg.a[1], sg.b[1]) - pad, Math.max(sg.a[0], sg.b[0]) + pad, Math.max(sg.a[1], sg.b[1]) + pad];
    // Runs that can be too near sg (tooNear): within SIDE across it, or GAP along its line.
    const nearRuns = (cells, sg, v) => {
      const [x1, y1, x2, y2] = boxOf(sg, 1);
      return v ? within(cells, x1 - SIDE, y1 - GAP, x2 + SIDE, y2 + GAP) : within(cells, x1 - GAP, y1 - SIDE, x2 + GAP, y2 + SIDE);
    };
    // Runs that can touch or overlay sg: their extents meet.
    const meetingRuns = (cells, sg) => within(cells, ...boxOf(sg, 1));
    // Runs within offsetsFor's reach of a line at lineAt spanning lo–hi.
    const reachRuns = (cells, lineAt, lo, hi, v) => (v ? within(cells, lineAt - 401, lo - 1, lineAt + 401, hi + 1) : within(cells, lo - 1, lineAt - 401, hi + 1, lineAt + 401));
    // One move at a time, re-reading the drawing after each, so two runs never dodge in step.
    // A large sheet can need a move for most of its runs, so the passes scale with the drawing.
    const passes = Math.max(40, 2 * items.length);
    let lastTick = Date.now();
    for (let pass = 0; pass < passes; pass++) {
      // A long sheet hands control back now and then, so a page can show progress or stop.
      if (progress && Date.now() - lastTick > 100) { await progress("separate"); lastTick = Date.now(); }
      let moved = false;
      const segs = segsOf();
      const cells = indexOf(segs);
      for (const A of segs) {
        if (moved) break;
        const v = vertical(A);
        if (!v && !horizontal(A)) continue;
        // A fixed run (a cable spine) never moves; the wire beside it does.
        if (A.it.e.fixed) continue;
        // A run too near another net's, or laid on another conductor's run of its own net (two
        // wires sharing a line read as one wire spliced where they part).
        const sameLine = (B) => B.it !== A.it && B.net === A.net && (v ? vertical(B) : horizontal(B)) && Math.abs(line(A, v) - line(B, v)) < E
          && (([a1, a2], [b1, b2]) => Math.min(a2, b2) - Math.max(a1, b1) > E)(span(A, v), span(B, v));
        const partner = nearRuns(cells, A, v).find((B) => (B.net !== A.net && (v ? vertical(B) : horizontal(B)) && tooNear(A, B, v)) || sameLine(B));
        if (!partner) continue;
        // The other runs near a trial position, never this conductor's own.
        const others = (list) => list.filter((o) => o.it !== A.it);
        const clear = (c) => { const rest = others(meetingRuns(cells, c)); return !(touches(c, rest) || ((vertical(c) || horizontal(c)) && overlays(c, rest))); };
        const crowded = (c) => others(nearRuns(cells, c, v)).some((B) => B.net !== A.net && (v ? vertical(B) : horizontal(B)) && tooNear(c, B, v));
        // Only interior runs move: both neighbours must exist and run across this one.
        const sec = A.it.sec, k = A.k;
        if (k < 2 || k > sec.length - 2) {
          // An end run (the one leaving a pin) cannot move whole. Where it has room between its pin
          // and the clash, a jog there turns its far part into an interior run that can.
          if (sec.length < 3 || (k !== 1 && k !== sec.length - 1)) continue;
          const atStart = k === 1;
          const pin = atStart ? sec[0] : sec[sec.length - 1], far = atStart ? sec[1] : sec[sec.length - 2];
          const along = v ? 1 : 0, dir = Math.sign(far[along] - pin[along]);
          if (!dir) continue;
          const [c1, c2] = span(partner, v);
          const clashNear = dir > 0 ? Math.max(c1, Math.min(pin[along], far[along])) : Math.min(c2, Math.max(pin[along], far[along]));
          const room = (clashNear - pin[along]) * dir;
          if (room < 140) continue;
          const jogAt = pin[along] + dir * Math.max(80, Math.round((room - 60) / 20) * 10);
          const J = pin.slice(); J[along] = jogAt;
          const [r1, r2] = [Math.min(J[along], far[along]), Math.max(J[along], far[along])];
          for (const d of offsetsFor(far[1 - along], r1, r2, v, A.net, others(reachRuns(cells, far[1 - along], r1, r2, v)))) {
            const J2 = J.slice(), F2 = far.slice();
            J2[1 - along] += d; F2[1 - along] += d;
            const trial = atStart ? [pin.slice(), J, J2, F2, ...sec.slice(2).map((q) => q.slice())]
              : [...sec.slice(0, -2).map((q) => q.slice()), F2, J2, J, pin.slice()];
            const at0 = atStart ? 1 : trial.length - 4;
            const changed = [0, 1, 2, 3].map((o) => at0 + o).filter((q) => q >= 1 && q < trial.length).map((q) => ({ it: A.it, k: q, a: trial[q - 1], b: trial[q], net: A.net }));
            if (!changed.every(clear)) continue;
            const movedRun = changed.find((c) => Math.abs(c.a[1 - along] - J2[1 - along]) < E && Math.abs(c.b[1 - along] - J2[1 - along]) < E && (v ? vertical(c) : horizontal(c)));
            if (!movedRun) continue;
            if (crowded(movedRun)) continue;
            // The run left at the pin must not itself sit beside another net.
            const stub = changed.find((c) => (Math.abs(c.a[0] - pin[0]) < E && Math.abs(c.a[1] - pin[1]) < E) || (Math.abs(c.b[0] - pin[0]) < E && Math.abs(c.b[1] - pin[1]) < E));
            if (stub && crowded(stub)) continue;
            sec.splice(0, sec.length, ...trial);
            moved = true;
            break;
          }
          continue;
        }
        // Both neighbours must cross this run at right angles, or moving it would bend them.
        const nb1 = { a: sec[k - 2], b: sec[k - 1] }, nb2 = { a: sec[k], b: sec[k + 1] };
        if (v ? !(horizontal(nb1) && horizontal(nb2)) : !(vertical(nb1) && vertical(nb2))) continue;
        const [s1, s2] = span(A, v);
        // Beyond the usual steps, a run may slide anywhere its two neighbours keep their direction
        // (a short jog between two long runs has the whole of their overlap to choose from), on the
        // 50 mil grid, nearest first.
        const ax = v ? 0 : 1, at0 = sec[k - 1][ax], f1 = sec[k - 2][ax], f2 = sec[k + 1][ax];
        const keeps = (x) => Math.sign(x - f1) === Math.sign(at0 - f1) && Math.abs(x - f1) >= 20 && Math.sign(f2 - x) === Math.sign(f2 - at0) && Math.abs(f2 - x) >= 20;
        const slides = [];
        for (let x = Math.ceil((Math.min(f1, f2) + 20) / 50) * 50; x <= Math.max(f1, f2) - 20; x += 50) if (keeps(x) && Math.abs(x - at0) > 200) slides.push(x - at0);
        slides.sort((p, q) => Math.abs(p) - Math.abs(q));
        for (const d of [...offsetsFor(line(A, v), s1, s2, v, A.net, others(reachRuns(cells, line(A, v), s1, s2, v))), ...slides.slice(0, 400)]) {
          // Its neighbours must keep their direction and some length, or the run folds onto them.
          if (!keeps(at0 + d)) continue;
          const trial = sec.map((p) => p.slice());
          if (v) { trial[k - 1][0] += d; trial[k][0] += d; } else { trial[k - 1][1] += d; trial[k][1] += d; }
          const changed = [k - 1, k, k + 1].map((q) => ({ it: A.it, k: q, a: trial[q - 1], b: trial[q], net: A.net }));
          if (!changed.every(clear)) continue;
          if (crowded(changed[1])) continue;
          for (let q = 0; q < sec.length; q++) sec[q] = trial[q];
          moved = true;
          break;
        }
      }
      if (!moved) break;
    }
  }

  function sideOfPoint(x, y, node) {
    const d = { WEST: Math.abs(x - node.x), EAST: Math.abs(x - (node.x + node.width)), NORTH: Math.abs(y - node.y), SOUTH: Math.abs(y - (node.y + node.height)) };
    return Object.entries(d).sort((a, b) => a[1] - b[1])[0][0];
  }

  /**
   * Lay out a scene. `elk` is an ELK instance; `measure(text, size)` returns a
   * text width in mils. Returns placed geometry for every symbol, group, port
   * and connection. `opts.progress(stage)`, when given, is awaited as each stage begins
   * ("place", "route", "separate") and now and then within a long one; it may throw to stop.
   */
  async function layoutScene(scene, elk, opts) {
    const measure = opts.measure;
    const progress = opts.progress || null;
    const physical = !!opts.physical;
    const symbols = [...scene.symbols.values()].filter((s) => [...s.contacts.values()].some((c) => c.visible) || s.kind === "lib");
    const symById = new Map(symbols.map((s) => [s.id, s]));
    const conns = scene.connections.filter((c) => symById.has(c.a.symbolId) && (c.port || symById.has(c.b.symbolId)) && c.a.visible && (c.port || c.b.visible));
    const hintSide = (sym, c) => (physical && sym.kind === "box" && c.sideHint) || null;

    // ---- rough left-to-right position (p) for each part ----------------------------------------
    const adj = new Map(symbols.map((s) => [s.id, []]));
    for (const c of conns) {
      if (c.port || c.a.symbolId === c.b.symbolId) continue;
      adj.get(c.a.symbolId).push({ conn: c, mine: c.a, other: c.b });
      adj.get(c.b.symbolId).push({ conn: c, mine: c.b, other: c.a });
    }
    const rank = (s) => (s.rank ?? 1e6);
    const p = new Map();
    const unvisited = new Set(symbols.map((s) => s.id));
    let offset = 0;
    while (unvisited.size) {
      const start = [...unvisited].map((id) => symById.get(id)).sort((a, b) => rank(a) - rank(b) || adj.get(b.id).length - adj.get(a.id).length)[0];
      p.set(start.id, offset);
      unvisited.delete(start.id);
      const queue = [start];
      let lo = offset, hi = offset;
      while (queue.length) {
        const u = queue.shift();
        const pu = p.get(u.id);
        const links = adj.get(u.id).slice().sort((a, b) => rank(symById.get(a.other.symbolId)) - rank(symById.get(b.other.symbolId)));
        for (const { mine, other } of links) {
          const v = symById.get(other.symbolId);
          if (!unvisited.has(v.id)) continue;
          const su = hintSide(u, mine), sv = hintSide(v, other);
          let pv;
          if (su === "WEST") pv = pu - 1;
          else if (su === "EAST") pv = pu + 1;
          else if (sv === "EAST") pv = pu - 1;
          else if (sv === "WEST") pv = pu + 1;
          else pv = pu + (Math.sign(pu - offset) || (rank(v) >= rank(u) ? 1 : -1));
          p.set(v.id, pv);
          lo = Math.min(lo, pv); hi = Math.max(hi, pv);
          unvisited.delete(v.id);
          queue.push(v);
        }
      }
      offset = hi + 3;
    }

    const orient = (c, sideA, sideB) => {
      // true when a -> b runs left to right. In the logical layout the author's ordering
      // hints win, then fixed pin sides; then the structural position from the walk above.
      // In the physical layout the pin sides come first, so parts land on the side of the
      // board their wires actually leave from.
      const sa = symById.get(c.a.symbolId), sb = c.port ? null : symById.get(c.b.symbolId);
      const byRank = sb && sa.rank !== undefined && sb.rank !== undefined && sa.rank !== sb.rank;
      if (byRank && !physical) return sa.rank < sb.rank;
      if (sideA === "EAST" || sideB === "WEST") return true;
      if (sideA === "WEST" || sideB === "EAST") return false;
      if (byRank) return sa.rank < sb.rank;
      if (!sb) return (p.get(sa.id) ?? 0) > 0;
      const pa = p.get(sa.id), pb = p.get(sb.id);
      if (pa !== pb) return pa < pb;
      if (rank(sa) !== rank(sb)) return rank(sa) < rank(sb);
      return sa.id < sb.id;
    };

    for (const c of symbols.flatMap((s) => [...s.contacts.values()])) c.faceUsed = false;
    for (const c of conns) {
      if (c.attach !== "face") continue;
      if (symById.get(c.a.symbolId).kind === "lib") c.a.faceUsed = true;
      if (c.b && symById.get(c.b.symbolId)?.kind === "lib") c.b.faceUsed = true;
    }

    // ---- containers ----------------------------------------------------------------------------
    const groups = [...scene.groups.values()];
    const docks = new Map();   // plug symbol id -> { hostId, off: [dx, dy] } in the host's local frame
    const dockedOn = new Map(); // host symbol id -> [plug symbol id]
    const containerOf = (symId) => symById.get(docks.get(symId)?.hostId || symId)?.parent || null;
    const ancestors = (gid) => { const out = []; let cur = gid; while (cur) { out.push(cur); cur = scene.groups.get(cur)?.parent || null; } out.push(null); return out; };
    const lca = (x, y) => { const ax = ancestors(x); return ancestors(y).find((g) => ax.includes(g)) ?? null; };
    // Only library symbols have a separate mating face; boxes take every connection at the pin tip.
    const endAttach = (c, attach) => (attach === "face" && symById.get(c.symbolId)?.kind === "lib" ? "face" : "tip");
    const portId = (c, attach) => `${c.symbolId}|${endAttach(c, attach) === "face" ? "f" : "t"}|${c.key}`;
    const order = (a, b) => (p.get(a.id) ?? 0) - (p.get(b.id) ?? 0) || rank(a) - rank(b) || String(a.key).localeCompare(String(b.key));

    const busPlans = new Map();
    const BUS_LABEL_SIZE = 44;
    const frames = new Map();          // symbol id -> offset inside its pass-2 node
    const dockedPorts = new Set();     // host ports covered by a plug
    const dockedMates = new Set();
    const isDockedMate = (c) => dockedMates.has(c);
    const FORK = 40;                   // spread of conductors doubled into one position, mils
    const FORK_SPAN = 80;              // widest fan at one pin: inside its 100 mil pitch
    const forks = new Map();           // port id -> connection ids ending there
    const forkEnds = [];               // { cid, sid, local, shifted }
    const forkPort = (pid, c) => ((forks.get(pid) || []).length > 1 ? `${pid}#${c.id}` : pid);
    const busPorts = new Map();

    function buildElk(pass, geo, sides) {
      const make = (gid) => {
        const kids = [];
        for (const s of symbols.filter((s) => (s.parent || null) === gid && !(pass === 2 && docks.has(s.id))).sort(order)) kids.push(symbolNode(s, pass, geo, sides));
        for (const g of groups.filter((g) => (g.parent || null) === gid).sort((a, b) => (a.rank ?? 1e6) - (b.rank ?? 1e6))) {
          kids.push({
            id: g.id,
            layoutOptions: { ...BASE_OPTIONS, "elk.padding": GROUP_PADDING, "elk.portConstraints": pass === 1 ? "FREE" : "FIXED_SIDE", "elk.nodeSize.constraints": "MINIMUM_SIZE", "elk.nodeSize.minimum": `(${Math.max(600, measure(g.name, 56) + 400)},400)` },
            ports: g.ports.map((pt) => ({ id: pt.id, width: 0, height: 0, layoutOptions: pass === 2 && sides.ports.get(pt.id) ? { "elk.port.side": sides.ports.get(pt.id) } : {} })),
            children: make(g.id).children,
            edges: [],
          });
        }
        return { children: kids };
      };
      const root = { id: "root", layoutOptions: { ...BASE_OPTIONS, "elk.padding": "[top=200,left=200,bottom=200,right=200]" }, ...make(null), edges: [] };
      const nodeById = new Map();
      const walk = (n) => { nodeById.set(n.id, n); (n.children || []).forEach(walk); };
      walk(root);
      for (const plan of pass === 2 ? busPlans.values() : []) {
        const [A, B] = plan.ends;
        const container = lca(containerOf(A.symId), containerOf(B.symId));
        const forward = orient(plan.bundle.connections[0].a.symbolId === A.symId ? plan.bundle.connections[0] : { ...plan.bundle.connections[0], a: plan.bundle.connections[0].b, b: plan.bundle.connections[0].a }, A.side, B.side);
        const edge = { id: plan.edgeId, sources: [forward ? A.portId : B.portId], targets: [forward ? B.portId : A.portId] };
        // The bus label is an ELK edge label, so the layout makes room for it along the run.
        edge.labels = [{ id: `${plan.edgeId}|label`, text: plan.label, width: measure(plan.label, BUS_LABEL_SIZE) + 40, height: BUS_LABEL_SIZE + 30 }];
        const holder = container ? nodeById.get(container) : root;
        (holder.edges || (holder.edges = [])).push(edge);
      }
      for (const c of conns) {
        if (pass === 2 && c.bundle && busPlans.has(c.bundle.id)) continue;
        if (pass === 2 && isDockedMate(c)) continue;
        const a = portId(c.a, c.attach);
        let b, container;
        if (c.port) { b = c.port.id; container = c.port.group; }
        else { b = portId(c.b, c.attach); container = lca(containerOf(c.a.symbolId), containerOf(c.b.symbolId)); }
        const sa = pass === 2 ? sides.port.get(a) : sidePass1(c.a, c.attach);
        const sb = pass === 2 ? (c.port ? sides.ports.get(c.port.id) : sides.port.get(b)) : c.port ? null : sidePass1(c.b, c.attach);
        const forward = orient(c, sa, c.port ? (sb === "WEST" ? "EAST" : sb === "EAST" ? "WEST" : null) : sb);
        // Conductors doubled into one position each get their own port, so none is drawn as a splice.
        const pa = pass === 2 ? forkPort(a, c) : a, pb = pass === 2 && !c.port ? forkPort(b, c) : b;
        const edge = { id: c.id, sources: [forward ? pa : pb], targets: [forward ? pb : pa] };
        const holder = container ? nodeById.get(container) : root;
        (holder.edges || (holder.edges = [])).push(edge);
      }
      return root;
    }

    const sidePass1 = (c, attach) => {
      const sym = symById.get(c.symbolId);
      if (sym.kind !== "box") return null;
      return hintSide(sym, c) || null;
    };

    function symbolNode(s, pass, geo, sides) {
      if (pass === 1) {
        const vis = [...s.contacts.values()].filter((c) => c.visible);
        const node = { id: s.id, width: s.kind === "lib" ? 300 : 700, height: Math.max(300, vis.length * 100 + 200), ports: [], layoutOptions: {} };
        const anyHint = s.kind === "box" && vis.some((c) => hintSide(s, c));
        for (const c of vis) {
          const port = { id: portId(c, "tip"), width: 0, height: 0, layoutOptions: {} };
          if (anyHint) port.layoutOptions["elk.port.side"] = hintSide(s, c) || guessSide(s, c);
          node.ports.push(port);
          if (c.faceUsed) node.ports.push({ id: portId(c, "face"), width: 0, height: 0, layoutOptions: {} });
        }
        node.layoutOptions["elk.portConstraints"] = anyHint ? "FIXED_SIDE" : "FREE";
        return node;
      }
      const g = geo.get(s.id);
      // A host and the plugs drawn against it travel as one node; frame records where each sits.
      const plugs = dockedOn.get(s.id) || [];
      let x1 = 0, y1 = 0, x2 = g.width, y2 = g.height;
      for (const pid of plugs) {
        const d = docks.get(pid), pg = geo.get(pid);
        x1 = Math.min(x1, d.off[0]); y1 = Math.min(y1, d.off[1]);
        x2 = Math.max(x2, d.off[0] + pg.width); y2 = Math.max(y2, d.off[1] + pg.height);
      }
      // A junction's cables start just off its joints; that strip is part of its footprint, so
      // nothing else is routed between the joints and where the cables begin.
      if (g.junction) for (const bp of busPorts.get(s.id) || []) {
        x1 = Math.min(x1, bp.at[0]); x2 = Math.max(x2, bp.at[0]);
        y1 = Math.min(y1, bp.at[1]); y2 = Math.max(y2, bp.at[1]);
      }
      const W = x2 - x1, H = y2 - y1;
      frames.set(s.id, [-x1, -y1]);
      for (const pid of plugs) frames.set(pid, [docks.get(pid).off[0] - x1, docks.get(pid).off[1] - y1]);
      const node = { id: s.id, width: W, height: H, ports: [], layoutOptions: { "elk.portConstraints": "FIXED_POS" } };
      // ELK snaps fixed ports to the node border unless told how far inside they sit.
      const fixedPort = (id, [x, y], side) => {
        const inset = side === "WEST" ? x : side === "EAST" ? W - x : side === "NORTH" ? y : H - y;
        const lo = { "elk.port.side": side };
        if (Math.abs(inset) > 0.5) lo["elk.port.borderOffset"] = String(-inset);
        return { id, x, y, width: 0, height: 0, layoutOptions: lo };
      };
      const addPins = (sid, gg, [ox, oy]) => {
        const at = ([x, y]) => [x + ox, y + oy];
        for (const bp of busPorts.get(sid) || []) node.ports.push(fixedPort(bp.id, at(bp.at), bp.side));
        for (const pin of gg.pins) {
          if (!pin.contact || !pin.contact.visible) continue;
          const place = (pid, local, side) => {
            if (dockedPorts.has(pid)) return;
            const list = forks.get(pid) || [];
            if (list.length < 2) { node.ports.push(fixedPort(pid, at(local), side)); return; }
            // Fan the doubled conductors out a little either side of the pin end; each is joined
            // back to the pin end after routing.
            // The fan stays within half a pitch of its own pin, clear of its neighbours' fans.
            const step = Math.min(FORK, FORK_SPAN / (list.length - 1));
            list.forEach((cid, i) => {
              const d = (i - (list.length - 1) / 2) * step;
              const shifted = side === "WEST" || side === "EAST" ? [local[0], local[1] + d] : [local[0] + d, local[1]];
              node.ports.push(fixedPort(`${pid}#${cid}`, at(shifted), side));
              forkEnds.push({ cid, sid, local, shifted });
            });
          };
          place(portId(pin.contact, "tip"), pin.tip, pin.side);
          if (pin.contact.faceUsed && pin.face) place(portId(pin.contact, "face"), pin.face, { WEST: "EAST", EAST: "WEST", NORTH: "SOUTH", SOUTH: "NORTH" }[pin.side]);
        }
      };
      addPins(s.id, g, frames.get(s.id));
      for (const pid of plugs) addPins(pid, geo.get(pid), frames.get(pid));
      return node;
    }

    /**
     * Logical order of one connector's pins. Pins whose nets belong to one bus (or whose
     * conductors belong to one wire group) are drawn together, members of each pair side by
     * side in the bus's declared role order (CAN_H before CAN_L), and each cluster sits where
     * routing wanted its pins on average. A connector mated to one already ordered takes its
     * mate's order, so mated positions still face each other.
     */
    const logicalRank = new Map();   // contact -> index along its edge, for mates ordered later
    function logicalBlock(cs, routed) {
      const at = (c) => { const i = routed.indexOf(c); return i < 0 ? routed.length : i; };
      const mateOf = (c) => { const m = conns.find((q) => q.style === "mate" && q.b && (q.a === c || q.b === c)); return m ? (m.a === c ? m.b : m.a) : null; };
      if (cs.every((c) => logicalRank.has(mateOf(c)))) return cs.slice().sort((a, b) => logicalRank.get(mateOf(a)) - logicalRank.get(mateOf(b)));
      // A library connector symbol draws its pins in its own numbered order, so a connector mated
      // to one keeps number order too, and each position still faces its mate.
      const posOf = (c) => { const v = c.number ?? c.order; return v === undefined || v === null || v === "" || isNaN(+v) ? null : +v; };
      const matesLib = cs.some((c) => { const m = mateOf(c); return m && symById.get(m.symbolId)?.kind === "lib"; });
      if (matesLib && cs.every((c) => posOf(c) !== null)) return cs.slice().sort((a, b) => posOf(a) - posOf(b));
      const wiresOf = (c) => conns.filter((q) => q.style !== "mate" && (q.a === c || q.b === c));
      const busOf = (c) => (c.net && c.net.buses && c.net.buses[0]) || null;
      const groupOf = (c) => { const q = wiresOf(c).find((x) => x.group && x.groupRole); return q ? { key: q.group, role: q.groupRole } : null; };
      const roleRank = (entry) => {
        if (!entry) return 0;
        const i = (entry.bus.members || []).findIndex((m) => m.role === entry.role);
        return i < 0 ? 1e3 : i;
      };
      // Clusters: a bus first, else a wire group, else the pin alone.
      const clusters = new Map();
      for (const c of cs) {
        const b = busOf(c), g = groupOf(c);
        const key = b ? `bus|${b.bus.id || b.bus.name}` : g ? `grp|${g.key}` : `pin|${c.key}`;
        if (!clusters.has(key)) clusters.set(key, []);
        clusters.get(key).push(c);
      }
      const ordered = [];
      const mean = (list) => list.reduce((acc, c) => acc + at(c), 0) / list.length;
      for (const list of [...clusters.values()].sort((x, y) => mean(x) - mean(y) || Scene.contactOrder(x[0], y[0]))) {
        // Within a bus, the two conductors of one twisted pair form a unit; pins without a pair
        // are paired role by role in routing order, so each H stands next to an L.
        const units = new Map();
        const loose = new Map();
        for (const c of list.slice().sort((a, b) => at(a) - at(b))) {
          const g = groupOf(c);
          if (g && list.filter((x) => groupOf(x)?.key === g.key).length > 1) {
            if (!units.has(g.key)) units.set(g.key, []);
            units.get(g.key).push(c);
            continue;
          }
          const role = busOf(c)?.role ?? g?.role ?? "";
          if (!loose.has(role)) loose.set(role, []);
          loose.get(role).push(c);
        }
        const roles = [...loose.keys()];
        const depth = Math.max(0, ...[...loose.values()].map((l) => l.length));
        for (let k = 0; k < depth; k++) units.set(`loose|${k}`, roles.map((r) => loose.get(r)[k]).filter(Boolean));
        const roleName = (c) => String(busOf(c)?.role ?? groupOf(c)?.role ?? "");
        for (const u of [...units.values()].sort((x, y) => mean(x) - mean(y))) {
          ordered.push(...u.sort((a, b) => roleRank(busOf(a)) - roleRank(busOf(b)) || Scene.compareNatural(roleName(a), roleName(b)) || at(a) - at(b)));
        }
      }
      return ordered;
    }

    /**
     * A connector's positions form one unbroken run on one edge. In the physical layout the
     * run is in position order, as KiCad numbers connector pins; in the logical layout the
     * order is chosen by logicalBlock. A multi-row header numbers each row on its own, so each
     * physical row is its own run.
     */
    function enforceRuns(s, buckets) {
      const posOf = (c) => { const v = c.number ?? c.order; return v === undefined || v === null || v === "" || isNaN(+v) ? null : +v; };
      const runs = new Map();
      for (const sd of SIDES) for (const c of buckets[sd]) {
        if (!c.section || (!c.section.node && posOf(c) === null)) continue;
        const k = `${c.section.key}|${c.sideHint || ""}`;
        if (!runs.has(k)) runs.set(k, []);
        runs.get(k).push({ sd, c });
      }
      for (const members of runs.values()) {
        if (members.length < 2) continue;
        // Unnumbered connectors still stay whole on one edge, in the order routing chose.
        const numbered = members.every((m) => posOf(m.c) !== null);
        if (physical && members.some((m) => m.c.pos)) continue;
        const count = (sd) => members.filter((m) => m.sd === sd).length;
        const hinted = members.find((m) => hintSide(s, m.c));
        const side = hinted ? hintSide(s, hinted.c) : SIDES.slice().sort((x, y) => count(y) - count(x))[0];
        const cs = members.map((m) => m.c);
        for (const sd of SIDES) if (sd !== side) buckets[sd] = buckets[sd].filter((c) => !cs.includes(c));
        const list = buckets[side];
        let at = list.findIndex((c) => cs.includes(c));
        if (at < 0) at = list.length;
        const before = list.slice(0, at).filter((c) => !cs.includes(c));
        const after = list.slice(at).filter((c) => !cs.includes(c));
        const routed = [...list.filter((c) => cs.includes(c)), ...cs.filter((c) => !list.includes(c))];
        // A position numbered with a letter (5S, a shield drain) has no place in the number order; it
        // follows the numbered positions, in the order routing chose.
        const numberedFirst = [...cs.filter((c) => posOf(c) !== null).sort((a, b) => posOf(a) - posOf(b)), ...routed.filter((c) => posOf(c) === null)];
        const block = !physical ? logicalBlock(cs, routed) : numbered || cs.some((c) => posOf(c) !== null) ? numberedFirst : routed;
        buckets[side] = [...before, ...block, ...after];
        block.forEach((c, i) => logicalRank.set(c, i));
      }
    }

    // Side for a contact with no physical side on a part whose other pins have one.
    function guessSide(s, c) {
      const links = adj.get(s.id).filter((l) => l.mine === c);
      if (links.length) {
        const mean = links.reduce((acc, l) => acc + (p.get(l.other.symbolId) ?? 0), 0) / links.length;
        return mean < (p.get(s.id) ?? 0) ? "WEST" : "EAST";
      }
      if (c.exposed) return (p.get(s.id) ?? 0) <= 0 ? "WEST" : "EAST";
      if (/OUT/.test(c.dir)) return "EAST";
      if (/IN/.test(c.dir)) return "WEST";
      return /power|ground/i.test(c.ptype) ? "WEST" : "EAST";
    }

    /**
     * Pick the mirror and rotation for a library symbol so its pins face the
     * sides their wiring arrived on in pass 1. Single-pin parts stay upright.
     */
    function chooseTransform(s, vis, sideOf) {
      const pins = s.lib.pins.filter((pp) => !pp.hidden);
      const options = [];
      for (const rot of pins.length > 1 ? [0, 90, 180, 270] : [0]) for (const mirror of [false, true]) options.push({ rot, mirror });
      const want = [];
      for (const c of vis) {
        if (!c.libPin) continue;
        for (const l of adj.get(s.id).filter((x) => x.mine === c)) {
          const attach = endAttach(c, l.conn.attach);
          let side = sideOf(c, attach);
          if (!side) {
            const otherLeft = (p.get(l.other.symbolId) ?? 0) < (p.get(s.id) ?? 0);
            side = otherLeft ? "WEST" : "EAST";
          }
          const tipSide = attach === "face" ? { WEST: "EAST", EAST: "WEST", NORTH: "SOUTH", SOUTH: "NORTH" }[side] : side;
          // A mating face must point at the part it plugs into; wires can bend to reach a tip.
          want.push({ pin: c.libPin, side: tipSide, weight: attach === "face" ? 4 : 1 });
        }
      }
      if (!want.length) return { rot: 0, mirror: false };
      const angleSide = (a) => (a === 0 ? "WEST" : a === 180 ? "EAST" : a === 90 ? "SOUTH" : "NORTH");
      let best = options[0], bestScore = -Infinity;
      for (const o of options) {
        let score = 0;
        for (const w of want) {
          let a = o.mirror ? (w.pin.angle === 0 ? 180 : w.pin.angle === 180 ? 0 : w.pin.angle) : w.pin.angle;
          a = (a + o.rot) % 360;
          const side = angleSide(a);
          score += w.weight * (side === w.side ? 2 : (side === "NORTH" || side === "SOUTH") !== (w.side === "NORTH" || w.side === "SOUTH") ? 0 : -1);
        }
        score -= (o.rot ? 0.5 : 0) + (o.mirror ? 0.25 : 0);
        if (score > bestScore) { bestScore = score; best = o; }
      }
      return best;
    }

    // ---- pass 1: sides and order -------------------------------------------------------------------
    if (progress) await progress("place");
    const g1 = await elk.layout(buildElk(1));
    const placed1 = new Map();
    const collect = (n) => { placed1.set(n.id, n); (n.ports || []).forEach((pt) => placed1.set(pt.id, { ...pt, owner: n })); (n.children || []).forEach(collect); };
    collect(g1);

    const sides = { port: new Map(), ports: new Map() };
    const geo = new Map();
    for (const s of symbols) {
      const node = placed1.get(s.id);
      const vis = [...s.contacts.values()].filter((c) => c.visible);
      const sideOf = (c, attach) => {
        const pt = placed1.get(portId(c, attach));
        return pt ? sideOfPoint(pt.x, pt.y, node) : null;
      };
      if (s.kind === "box") {
        const buckets = { WEST: [], EAST: [], NORTH: [], SOUTH: [] };
        for (const c of vis) {
          let side = hintSide(s, c) || sideOf(c, "tip") || guessSide(s, c);
          if (!hintSide(s, c) && (side === "NORTH" || side === "SOUTH") && !physical) side = guessSide(s, c);
          buckets[side].push(c);
        }
        for (const side of SIDES) {
          const list = buckets[side];
          const pos = (c) => { const pt = placed1.get(portId(c, "tip")); return pt ? (side === "WEST" || side === "EAST" ? pt.y : pt.x) : 0; };
          const hinted = list.every((c) => hintSide(s, c) && c.order !== undefined && c.order !== null);
          list.sort((a, b) => {
            if (hinted) return Scene.compareNatural(a.order, b.order);
            const sa = a.section?.key || "", sb = b.section?.key || "";
            if (sa !== sb) {
              const ma = Math.min(...list.filter((x) => (x.section?.key || "") === sa).map(pos));
              const mb = Math.min(...list.filter((x) => (x.section?.key || "") === sb).map(pos));
              return ma - mb;
            }
            return pos(a) - pos(b) || Scene.contactOrder(a, b);
          });
        }
        for (const bundle of scene.bundles || []) {
          if (!bundle.ends.includes(s.id)) continue;
          const mine = bundle.connections.map((c) => (c.a.symbolId === s.id ? c.a : c.b)).filter((c) => c.visible);
          const count = (side) => mine.filter((c) => buckets[side].includes(c)).length;
          const side = SIDES.slice().sort((x, y) => count(y) - count(x))[0];
          const movable = mine.filter((c) => !hintSide(s, c) || hintSide(s, c) === side);
          for (const sd of SIDES) {
            if (sd === side) continue;
            buckets[sd] = buckets[sd].filter((c) => !movable.includes(c));
          }
          const list = buckets[side];
          const at = Math.min(...movable.map((c) => (list.includes(c) ? list.indexOf(c) : list.length)));
          const rest = list.filter((c) => !movable.includes(c));
          const block = movable.slice().sort((x, y) => (list.includes(x) ? list.indexOf(x) : 1e9) - (list.includes(y) ? list.indexOf(y) : 1e9));
          const before = list.slice(0, at).filter((c) => !movable.includes(c)).length;
          buckets[side] = [...rest.slice(0, before), ...block, ...rest.slice(before)];
        }
        enforceRuns(s, buckets);
        let g;
        if (s.junction) {
          // A junction takes wires on its west and east edges only, each conductor beside the
          // others bound for the same part, joints in a fixed order so a pair stays side by side.
          for (const [from, to] of [["NORTH", "WEST"], ["SOUTH", "EAST"]]) { buckets[to].push(...buckets[from]); buckets[from] = []; }
          const partner = (c) => { const cn = conns.find((q) => q.a === c || q.b === c); return cn ? (cn.a === c ? cn.b?.symbolId : cn.a.symbolId) || "" : ""; };
          for (const side of ["WEST", "EAST"]) {
            const list = buckets[side];
            const firstAt = new Map();
            list.forEach((c, i) => { const k = partner(c); if (!firstAt.has(k)) firstAt.set(k, i); });
            buckets[side] = list.slice().sort((a, b) => firstAt.get(partner(a)) - firstAt.get(partner(b)) || Scene.compareNatural(a.joint || "", b.joint || "") || list.indexOf(a) - list.indexOf(b));
          }
          g = junctionGeometry(s, buckets, measure);
        } else g = boxGeometry(s, buckets, measure, { physical });
        geo.set(s.id, g);
        for (const pin of g.pins) sides.port.set(portId(pin.contact, "tip"), pin.side);
      } else {
        const tf = chooseTransform(s, vis, sideOf);
        const g = libGeometry(s, tf, measure);
        geo.set(s.id, g);
        for (const pin of g.pins) {
          if (!pin.contact) continue;
          sides.port.set(portId(pin.contact, "tip"), pin.side);
          sides.port.set(portId(pin.contact, "face"), { WEST: "EAST", EAST: "WEST", NORTH: "SOUTH", SOUTH: "NORTH" }[pin.side]);
        }
      }
    }
    for (const g of groups) {
      const gn = placed1.get(g.id);
      for (const pt of g.ports) {
        const placedPort = placed1.get(pt.id);
        let side = placedPort && gn ? sideOfPoint(placedPort.x, placedPort.y, gn) : null;
        if (side !== "WEST" && side !== "EAST") side = sides.port.get(portId(pt.contact, "tip")) === "EAST" ? "EAST" : "WEST";
        const contactSide = sides.port.get(portId(pt.contact, "tip"));
        if (contactSide === "WEST" || contactSide === "EAST") side = contactSide;
        sides.ports.set(pt.id, side);
      }
    }

    // ---- docking: a plug is drawn plugged into what it mates with ------------------------------------
    // KiCad's _Pin and _Socket connector symbols are drawn to meet nose to nose. A connector whose
    // every drawn contact mates with one other part is placed so each mating face touches its
    // partner, position for position; its wires then leave from its back. Anything that cannot
    // line up exactly keeps its own place and a drawn mate line.
    const OPP = { WEST: "EAST", EAST: "WEST", NORTH: "SOUTH", SOUTH: "NORTH" };
    const mateConns = conns.filter((c) => c.style === "mate" && c.b);
    const wireCount = (sid) => conns.filter((c) => c.style !== "mate" && (c.a.symbolId === sid || c.b?.symbolId === sid)).length;
    const textRows = new Map();  // host id|side -> along ranges taken by seated plugs and their names
    const candidates = symbols.filter((s) => s.kind === "lib" && s.role === "connector").sort((a, b) => wireCount(a.id) - wireCount(b.id) || rank(b) - rank(a));
    for (const P of candidates) {
      if (dockedOn.has(P.id)) continue;
      const mine = mateConns.filter((m) => m.a.symbolId === P.id || m.b.symbolId === P.id);
      if (!mine.length) continue;
      const hostIds = new Set(mine.map((m) => (m.a.symbolId === P.id ? m.b.symbolId : m.a.symbolId)));
      if (hostIds.size !== 1) continue;
      const hostId = [...hostIds][0];
      if (docks.has(hostId) || hostId === P.id) continue;
      const H = symById.get(hostId), hg = geo.get(hostId);
      const plugContacts = [...P.contacts.values()].filter((c) => c.visible && c.libPin);
      if (plugContacts.some((c) => !mine.some((m) => m.a === c || m.b === c))) continue;
      const pairs = mine.map((m) => {
        const plugC = m.a.symbolId === P.id ? m.a : m.b, hostC = m.a.symbolId === P.id ? m.b : m.a;
        const hp = hg.pins.find((pp) => pp.contact === hostC);
        if (!hp) return null;
        return { m, plugC, hostC, hostPt: H.kind === "box" ? hp.tip : hp.face, dir: H.kind === "box" ? hp.side : OPP[hp.side], hostSide: hp.side };
      });
      if (pairs.some((x) => !x || !x.hostPt) || new Set(pairs.map((x) => x.dir)).size !== 1) continue;
      // A box pin covered by the plug can carry nothing else: any other wire would have to reach
      // a point the plug now occupies.
      if (H.kind === "box" && pairs.some((x) => conns.some((c) => c !== x.m && (c.a === x.hostC || c.b === x.hostC)))) continue;
      const dir = pairs[0].dir;
      // Keep the plug's name clear of the host's other pins on that edge.
      const horizontal = dir === "WEST" || dir === "EAST";
      const alongPt = (pt) => (horizontal ? pt[1] : pt[0]);
      const lo = Math.min(...pairs.map((x) => alongPt(x.hostPt))), hi = Math.max(...pairs.map((x) => alongPt(x.hostPt)));
      const others = hg.pins.filter((pp) => pp.side === pairs[0].hostSide && !pairs.some((x) => x.hostC === pp.contact) && pp.contact?.visible);
      // The name runs away from the mate, beyond the pin ends, so only a wired neighbour pin (whose
      // wire leaves along that row) can collide with it; unwired neighbours leave the row free.
      const busy = textRows.get(`${hostId}|${pairs[0].hostSide}`) || [];
      const wiredNear = (lo2, hi2) => others.some((pp) => !pp.idle && alongPt(pp.tip) >= lo2 && alongPt(pp.tip) <= hi2) || busy.some(([a, b]) => a <= hi2 && b >= lo2);
      const fields = !horizontal ? undefined : !wiredNear(lo - 150, lo - 1) ? "NORTH" : !wiredNear(hi + 1, hi + 150) ? "SOUTH" : "NORTH";
      // A plug whose positions the graph does not number takes its mate's order, so the two
      // line up without inventing a numbering for either.
      if (!plugContacts.some((c) => c.number) && plugContacts.every((c) => c.libPin)) {
        const libPins = plugContacts.map((c) => c.libPin).sort((a, b) => Scene.compareNatural(String(a.number), String(b.number)));
        pairs.slice().sort((a, b) => alongPt(a.hostPt) - alongPt(b.hostPt)).forEach((x, i) => { x.plugC.libPin = libPins[i]; });
      }
      // Of the orientations that seat every position, take the one whose other parts (a coax
      // shield pin, say) reach least into rows its neighbours already use.
      const taken = [...(textRows.get(`${hostId}|${pairs[0].hostSide}`) || []),
        ...others.map((pp) => [alongPt(pp.tip) - 50, alongPt(pp.tip) + 50])];
      let found = null, bestCost = Infinity;
      for (const rot of [0, 90, 180, 270]) for (const mirror of [false, true]) {
        const g = libGeometry(P, { rot, mirror, fields, away: dir }, measure);
        const offs = pairs.map((x) => {
          const pp = g.pins.find((q) => q.contact === x.plugC);
          return pp && pp.side === dir ? [x.hostPt[0] - pp.face[0], x.hostPt[1] - pp.face[1]] : null;
        });
        if (offs.some((o) => !o)) continue;
        if (!offs.every((o) => Math.abs(o[0] - offs[0][0]) < 0.5 && Math.abs(o[1] - offs[0][1]) < 0.5)) continue;
        const [e0, e1] = horizontal ? [offs[0][1], offs[0][1] + g.height] : [offs[0][0], offs[0][0] + g.width];
        const cost = taken.reduce((acc, [a, b]) => acc + Math.max(0, Math.min(b, e1) - Math.max(a, e0)), 0) + (rot ? 1 : 0) + (mirror ? 0.5 : 0);
        if (cost < bestCost) { bestCost = cost; found = { g, off: offs[0] }; }
      }
      if (!found) continue;
      // The plug and its name now occupy this stretch of the host's edge.
      if (!textRows.has(`${hostId}|${pairs[0].hostSide}`)) textRows.set(`${hostId}|${pairs[0].hostSide}`, []);
      // Everything the plug draws (body, shield pins, name) counts, not just its mated positions.
      const [ex0, ex1] = horizontal ? [found.off[1], found.off[1] + found.g.height] : [found.off[0], found.off[0] + found.g.width];
      textRows.get(`${hostId}|${pairs[0].hostSide}`).push([Math.min(ex0, lo - 40), Math.max(ex1, hi + 40)]);
      // Seated on its mate, the plug's positions read from the mate's names; its own captions go.
      found.g.captions = [];
      geo.set(P.id, found.g);
      docks.set(P.id, { hostId, off: found.off, pairs });
      if (!dockedOn.has(hostId)) dockedOn.set(hostId, []);
      dockedOn.get(hostId).push(P.id);
      for (const x of pairs) { dockedPorts.add(portId(x.hostC, H.kind === "box" ? "tip" : "face")); dockedMates.add(x.m); }
      // The plug's contacts now take their wires where the plug actually sits.
      for (const pin of found.g.pins) if (pin.contact) sides.port.set(portId(pin.contact, "tip"), pin.side);
    }

    // ---- cables: one bus route per jacket, KiCad style ------------------------------------------------------
    // Each end gets a bus spine a short gap beyond the pins; every conductor joins it through a
    // 45 degree bus entry. The bus itself is routed by ELK between the two spine centres.
    const BUS_GAP = 220, BUS_STEP = 120;
    const outward = { WEST: [-1, 0], EAST: [1, 0], NORTH: [0, -1], SOUTH: [0, 1] };
    // Several cables leaving one edge of a part each get their own spine, one step further out
    // wherever their spans would otherwise share a line.
    const spineLevels = new Map(); // "symId|side" -> [{ lo, hi, level }]
    const pairStarts = new Map();  // "symId|side" -> along-edge positions where pairs already begin
    for (const bundle of scene.bundles || []) {
      const ends = [];
      for (const symId of bundle.ends) {
        const g = geo.get(symId);
        if (!g) break;
        const members = bundle.connections.map((c) => {
          const contact = c.a.symbolId === symId ? c.a : c.b;
          const pin = g.pins.find((pp) => pp.contact === contact);
          return pin ? { conn: c, contact, pin } : null;
        });
        if (members.some((m) => !m)) break;
        const side = members[0].pin.side;
        const horizontal = side === "WEST" || side === "EAST";
        const along = (pt) => (horizontal ? pt[1] : pt[0]);
        const across = (pt) => (horizontal ? pt[0] : pt[1]);
        if (members.some((m) => m.pin.side !== side || Math.abs(across(m.pin.tip) - across(members[0].pin.tip)) > 0.5)) break;
        const [ox, oy] = outward[side];
        let centre = members.reduce((a, m) => a + along(m.pin.tip), 0) / members.length;
        const key = `${symId}|${side}`;
        if (bundle.style === "pair") {
          // A pair begins between pin rows, clear of every wire leaving this edge (a doubled crimp
          // fans its wires either side of its row) and of the other pairs starting here, so it
          // never runs along another conductor.
          const busy = [...(pairStarts.get(key) || [])];
          for (const pp of g.pins) {
            if (pp.side !== side || !pp.contact) continue;
            const at = along(pp.tip);
            busy.push(at);
            const wires = conns.filter((q) => (q.a === pp.contact || q.b === pp.contact) && q.style !== "mate" && q.style !== "join").length;
            if (wires > 1) busy.push(at - FORK / 2, at + FORK / 2);
          }
          const first = along(members[0].pin.tip);
          const half = first + Math.round((centre - first - PITCH / 2) / PITCH) * PITCH + PITCH / 2;
          for (let k = 0; k < 40; k++) {
            const cand = half + (k % 2 ? -1 : 1) * Math.ceil(k / 2) * PITCH;
            if (busy.every((b) => Math.abs(b - cand) >= 40)) { centre = cand; break; }
          }
        }
        // A bus spine reaches a pitch past its outer entries; a pair's runs between its pins and its start.
        const reach = bundle.style === "pair" ? 0 : PITCH;
        const tips = members.map((m) => along(m.pin.tip));
        const lo = Math.min(...tips, centre) - reach, hi = Math.max(...tips, centre) + reach;
        const taken = spineLevels.get(key) || [];
        let level = 0;
        while (taken.some((t) => t.level === level && t.lo <= hi && lo <= t.hi)) level++;
        // At a junction the pair begins close to the joint; elsewhere it clears the pin text, and
        // always the part's whole footprint (its name included), so the route starts in the open.
        const tip0 = members[0].pin.tip;
        const room = side === "EAST" ? g.width - tip0[0] : side === "WEST" ? tip0[0] : side === "SOUTH" ? g.height - tip0[1] : tip0[1];
        const gap = Math.max(g.junction ? PITCH + 20 : BUS_GAP, room > 0.5 ? ceilTo(room + 60, 10) : 0) + level * BUS_STEP;
        const spineAcross = across(members[0].pin.tip) + (horizontal ? ox : oy) * gap;
        const at = horizontal ? [spineAcross, centre] : [centre, spineAcross];
        ends.push({ symId, side, members, at, portId: `bus|${bundle.id}|${symId}`, horizontal, centre, spineAcross, gap, key, lo, hi, level });
      }
      if (ends.length !== 2) {
        scene.notes.push({ level: "info", message: `${bundle.name}: its conductors do not leave each part from one edge, so they are drawn as separate wires.` });
        continue;
      }
      for (const e of ends) {
        if (!spineLevels.has(e.key)) spineLevels.set(e.key, []);
        spineLevels.get(e.key).push({ lo: e.lo, hi: e.hi, level: e.level });
        if (bundle.style === "pair") { if (!pairStarts.has(e.key)) pairStarts.set(e.key, []); pairStarts.get(e.key).push(e.centre); }
      }
      // KiCad bus label syntax: name{member member ...}.
      const label = bundle.style === "pair" ? bundle.name : `${bundle.name}{${bundle.connections.map((c) => c.net?.name || c.a.name).join(" ")}}`;
      busPlans.set(bundle.id, { bundle, ends, edgeId: `bus:${bundle.id}`, label });
      for (const e of ends) {
        if (!busPorts.has(e.symId)) busPorts.set(e.symId, []);
        busPorts.get(e.symId).push({ id: e.portId, at: e.at, side: e.side });
      }
    }

    // ---- pass 2: exact geometry and final routing --------------------------------------------------------
    for (const c of conns) {
      // Conductors fan out; a net drawn through a net node keeps one trunk with junctions.
      if ((c.bundle && busPlans.has(c.bundle.id)) || isDockedMate(c) || c.netNode) continue;
      for (const end of c.port ? [c.a] : [c.a, c.b]) {
        const pid = portId(end, c.attach);
        if (!forks.has(pid)) forks.set(pid, []);
        forks.get(pid).push(c.id);
      }
    }
    if (progress) await progress("route");
    const g2 = await elk.layout(buildElk(2, geo, sides));
    const out = { symbols: new Map(), groups: new Map(), edges: new Map(), ports: new Map(), bounds: { x: 0, y: 0, w: g2.width, h: g2.height } };
    const walk = (n) => {
      if (symById.has(n.id)) {
        for (const sid of [n.id, ...(dockedOn.get(n.id) || [])]) {
          const [fx, fy] = frames.get(sid) || [0, 0];
          const g = geo.get(sid);
          out.symbols.set(sid, { x: n.x + fx, y: n.y + fy, w: g.width, h: g.height, geo: g, sym: symById.get(sid) });
        }
      }
      else if (scene.groups.has(n.id)) {
        out.groups.set(n.id, { x: n.x, y: n.y, w: n.width, h: n.height, group: scene.groups.get(n.id) });
        for (const pt of n.ports || []) out.ports.set(pt.id, { x: pt.x, y: pt.y, side: sides.ports.get(pt.id), group: n.id });
      }
      for (const e of n.edges || []) {
        const sections = (e.sections || []).map((s) => [[s.startPoint.x, s.startPoint.y], ...(s.bendPoints || []).map((b) => [b.x, b.y]), [s.endPoint.x, s.endPoint.y]]);
        out.edges.set(e.id, { sections, junctions: (e.junctionPoints || []).map((j) => [j.x, j.y]), labels: (e.labels || []).map((l) => ({ text: l.text, x: l.x, y: l.y, w: l.width, h: l.height })) });
      }
      (n.children || []).forEach(walk);
    };
    walk(g2);
    // Separate nets that happen to share a line, before any fan-out or seating is added. Each
    // cable's spine is known by now (its part is placed), so it stands in as a fixed run that
    // other wires must keep clear of.
    out.connections = conns;
    const spineIds = [];
    for (const plan of busPlans.values()) for (const end of plan.ends) {
      const sp = out.symbols.get(end.symId);
      if (!sp) continue;
      const a = end.horizontal ? [sp.x + end.at[0], sp.y + end.lo] : [sp.x + end.lo, sp.y + end.at[1]];
      const b = end.horizontal ? [sp.x + end.at[0], sp.y + end.hi] : [sp.x + end.hi, sp.y + end.at[1]];
      const id = `spine:${plan.bundle.id}:${end.symId}`;
      // The spine belongs to its own cable's route, so that route may meet it.
      out.edges.set(id, { sections: [[a, b]], junctions: [], labels: [], fixed: true, netKey: plan.edgeId });
      spineIds.push(id);
    }
    // The short runs that later join each fanned conductor back to its pin are fixed too, so a
    // wire is never moved alongside one of them.
    const connById = new Map(conns.map((c) => [c.id, c]));
    for (const fe of forkEnds) {
      const sp = out.symbols.get(fe.sid);
      if (!sp) continue;
      const tip = [sp.x + fe.local[0], sp.y + fe.local[1]], sh = [sp.x + fe.shifted[0], sp.y + fe.shifted[1]];
      if (Math.abs(tip[0] - sh[0]) < 0.5 && Math.abs(tip[1] - sh[1]) < 0.5) continue;
      const id = `forkend:${fe.cid}:${spineIds.length}`;
      out.edges.set(id, { sections: [[sh, tip]], junctions: [], labels: [], fixed: true, netKey: connById.get(fe.cid)?.net?.key || fe.cid });
      spineIds.push(id);
    }
    if (progress) await progress("separate");
    await nudgeCollinear(out, progress);
    for (const id of spineIds) out.edges.delete(id);
    // Join each fanned conductor back to its pin end.
    for (const fe of forkEnds) {
      const e = out.edges.get(fe.cid), sp = out.symbols.get(fe.sid);
      if (!e || !e.sections.length || !sp) continue;
      const tip = [sp.x + fe.local[0], sp.y + fe.local[1]], sh = [sp.x + fe.shifted[0], sp.y + fe.shifted[1]];
      if (Math.abs(tip[0] - sh[0]) < 0.5 && Math.abs(tip[1] - sh[1]) < 0.5) continue;
      const first = e.sections[0], last = e.sections[e.sections.length - 1];
      const at = (p) => Math.abs(p[0] - sh[0]) < 1 && Math.abs(p[1] - sh[1]) < 1;
      if (at(first[0])) first.unshift(tip);
      else if (at(last[last.length - 1])) last.push(tip);
    }
    // A docked mate is the touching point itself: a zero-length joint, face on pin.
    for (const [pid, d] of docks) {
      const ps = out.symbols.get(pid), hs = out.symbols.get(d.hostId);
      for (const x of d.pairs) {
        const pp = ps.geo.pins.find((q) => q.contact === x.plugC);
        const a = [hs.x + x.hostPt[0], hs.y + x.hostPt[1]], b = [ps.x + pp.face[0], ps.y + pp.face[1]];
        out.edges.set(x.m.id, { sections: [x.m.a === x.hostC ? [a, b] : [b, a]], junctions: [], docked: true });
      }
    }
    out.docks = docks;

    out.bundles = [];
    const entryUsers = new Map(); // contact -> bundle ids whose entries leave it
    for (const plan of busPlans.values()) for (const end of plan.ends) for (const m of end.members) {
      if (!entryUsers.has(m.contact)) entryUsers.set(m.contact, []);
      entryUsers.get(m.contact).push(plan.bundle.id);
    }
    for (const plan of busPlans.values()) {
      const e = out.edges.get(plan.edgeId);
      if (!e || !e.sections.length) continue;
      let path = e.sections.flatMap((sec, i) => (i ? sec.slice(1) : sec));
      const placedEnd = (end) => { const s = out.symbols.get(end.symId); return [s.x + end.at[0], s.y + end.at[1]]; };
      const [A, B] = plan.ends;
      const pa = placedEnd(A);
      if (Math.hypot(path[0][0] - pa[0], path[0][1] - pa[1]) > Math.hypot(path[path.length - 1][0] - pa[0], path[path.length - 1][1] - pa[1])) path = path.slice().reverse();
      const ends = plan.ends.map((end) => {
        const s = out.symbols.get(end.symId);
        const abs = ([x, y]) => [s.x + x, s.y + y];
        const centre = abs(end.at);
        const entries = end.members.map((m) => {
          const tip = abs(m.pin.tip);
          const [ox, oy] = outward[end.side];
          // A pin taking conductors of more than one cable fans them apart at 45 degrees first,
          // as a doubled crimp is drawn, so no two of them share a run.
          const users = entryUsers.get(m.contact) || [plan.bundle.id];
          const d = (users.indexOf(plan.bundle.id) - (users.length - 1) / 2) * FORK;
          const off = (pt) => (end.horizontal ? [pt[0], pt[1] + d] : [pt[0] + d, pt[1]]);
          const fan = d ? [[tip[0] + ox * Math.abs(d), tip[1] + oy * Math.abs(d)]].map(off) : [];
          const pre = off([tip[0] + ox * (end.gap - 100), tip[1] + oy * (end.gap - 100)]);
          // KiCad bus entries are 100 mil by 100 mil at 45 degrees. Each leans toward where the bus
          // leaves, so the entries stay within the connector's own span and clear its neighbours.
          if (plan.bundle.style === "pair") {
            // A twisted pair's conductors run straight out to where the pair begins; they twist
            // together from there, so no bus entry is drawn.
            const join = end.horizontal ? [centre[0], tip[1] + d] : [tip[0] + d, centre[1]];
            return { conn: m.conn, contact: m.contact, pts: [tip, ...fan, join] };
          }
          const lean = ((end.horizontal ? tip[1] - centre[1] : tip[0] - centre[0]) + d) > 0 ? -100 : 100;
          const join = end.horizontal ? [centre[0], tip[1] + d + lean] : [tip[0] + d + lean, centre[1]];
          return { conn: m.conn, contact: m.contact, pts: [tip, ...fan, pre, join] };
        });
        const alongOf = (pt) => (end.horizontal ? pt[1] : pt[0]);
        const lo = Math.min(alongOf(centre), ...entries.map((en) => alongOf(en.pts[en.pts.length - 1])));
        const hi = Math.max(alongOf(centre), ...entries.map((en) => alongOf(en.pts[en.pts.length - 1])));
        const spine = end.horizontal ? [[centre[0], lo], [centre[0], hi]] : [[lo, centre[1]], [hi, centre[1]]];
        return { symId: end.symId, side: end.side, centre, entries, spine };
      });
      const lab = e.labels[0];
      out.bundles.push({ bundle: plan.bundle, path, ends, label: { text: plan.label, ...(lab && isFinite(lab.x) ? { x: lab.x, y: lab.y, w: lab.w, h: lab.h } : {}) } });
      out.edges.delete(plan.edgeId);
      // Each conductor's full run (pin, entry, spine, bus, spine, entry, pin) keeps net tracing,
      // boundary crossings and annotations working as for any other wire.
      for (const c of plan.bundle.connections) {
        const ea = ends.find((en) => en.symId === c.a.symbolId), eb = ends.find((en) => en.symId === c.b.symbolId);
        const ia = ea.entries.find((en) => en.conn === c), ib = eb.entries.find((en) => en.conn === c);
        const run = ea === ends[0] ? path : path.slice().reverse();
        const full = [...ia.pts, ea.centre, ...run, eb.centre, ...ib.pts.slice().reverse()];
        out.edges.set(c.id, { sections: [full], junctions: [], bus: true });
      }
    }
    out.connections = conns;
    out.physical = physical;
    out.p = p;
    return out;
  }

  return { layoutScene, boxGeometry, libGeometry, wrapText, PITCH };
});
