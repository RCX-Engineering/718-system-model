/* ============================================================================
 * Cypher interpreter
 *
 * Reads openCypher scripts into an in-memory property graph. Covers the
 * write-oriented subset used for authoring and revising design graphs:
 *
 *   CREATE    nodes, relationships and paths
 *   MATCH     node and single-hop relationship patterns, with WHERE
 *   OPTIONAL MATCH
 *   MERGE     with ON CREATE SET / ON MATCH SET
 *   SET       a.key = v, a = {map}, a += {map}, a:Label
 *   REMOVE    a.key, a:Label
 *   DELETE / DETACH DELETE
 *   RETURN / WITH are accepted and skipped, so pasted queries do not fail.
 *
 * Scripts are run the way authoring tools run them: statements end at a
 * semicolon or where a MATCH begins after an updating clause, and node
 * variables bound by CREATE or MERGE stay visible for the rest of the script.
 * Every problem is reported as a diagnostic with its source line rather than
 * stopping the run, so one bad line never hides the rest of the graph.
 * ========================================================================== */

(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.KGCypher = api;
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";

  // ------------------------------------------------------------------ lexer

  const PUNCT3 = [];
  const PUNCT2 = ["->", "<-", "<>", "<=", ">=", "=~", "+=", ".."];
  const PUNCT1 = "()[]{}:,.-><=+*/%|;$^";

  class CypherSyntaxError extends Error {
    constructor(message, token) {
      super(message);
      this.line = token ? token.line : 0;
      this.col = token ? token.col : 0;
    }
  }

  function tokenize(src) {
    const tokens = [];
    let i = 0, line = 1, lineStart = 0;
    const n = src.length;
    const push = (t, v, start, extra) =>
      tokens.push(Object.assign({ t, v, pos: start, line: tokLine, col: start - tokLineStart + 1, bol: atBol }, extra));
    let tokLine = 1, tokLineStart = 0, atBol = true;

    while (i < n) {
      const c = src[i];
      if (c === "\n") { i++; line++; lineStart = i; atBol = true; continue; }
      if (c === " " || c === "\t" || c === "\r" || c === "\f" || c === "\uFEFF") { i++; continue; }
      if (c === "/" && src[i + 1] === "/") { while (i < n && src[i] !== "\n") i++; continue; }
      if (c === "/" && src[i + 1] === "*") {
        const end = src.indexOf("*/", i + 2);
        const stop = end < 0 ? n : end + 2;
        for (let k = i; k < stop; k++) if (src[k] === "\n") { line++; lineStart = k + 1; }
        i = stop;
        continue;
      }
      tokLine = line; tokLineStart = lineStart;
      const start = i;

      if (c === "'" || c === '"') {
        let out = "";
        i++;
        while (i < n && src[i] !== c) {
          if (src[i] === "\\" && i + 1 < n) {
            const e = src[i + 1];
            const map = { n: "\n", t: "\t", r: "\r", b: "\b", f: "\f", "\\": "\\", "'": "'", '"': '"' };
            if (e === "u" && /^[0-9a-fA-F]{4}$/.test(src.substr(i + 2, 4))) {
              out += String.fromCharCode(parseInt(src.substr(i + 2, 4), 16));
              i += 6;
              continue;
            }
            out += e in map ? map[e] : e;
            i += 2;
            continue;
          }
          if (src[i] === "\n") { line++; lineStart = i + 1; }
          out += src[i++];
        }
        if (i >= n) throw new CypherSyntaxError("Unterminated string literal", { line: tokLine, col: start - tokLineStart + 1 });
        i++;
        push("str", out, start);
        atBol = false;
        continue;
      }
      if (c === "`") {
        const end = src.indexOf("`", i + 1);
        if (end < 0) throw new CypherSyntaxError("Unterminated `quoted` name", { line: tokLine, col: start - tokLineStart + 1 });
        push("id", src.slice(i + 1, end), start, { quoted: true });
        i = end + 1;
        atBol = false;
        continue;
      }
      if (/[0-9]/.test(c) || (c === "." && /[0-9]/.test(src[i + 1] || ""))) {
        const m = /^(?:0x[0-9a-fA-F]+|\d*\.?\d+(?:[eE][+-]?\d+)?)/.exec(src.slice(i, i + 64));
        const text = m[0];
        push("num", text.startsWith("0x") ? parseInt(text, 16) : Number(text), start, { raw: text });
        i += text.length;
        atBol = false;
        continue;
      }
      if (/[A-Za-z_\u00C0-\uFFFF]/.test(c)) {
        let j = i + 1;
        while (j < n && /[A-Za-z0-9_\u00C0-\uFFFF]/.test(src[j])) j++;
        push("id", src.slice(i, j), start);
        i = j;
        atBol = false;
        continue;
      }
      const two = src.substr(i, 2);
      if (PUNCT3.includes(src.substr(i, 3))) { push("p", src.substr(i, 3), start); i += 3; atBol = false; continue; }
      if (PUNCT2.includes(two)) { push("p", two, start); i += 2; atBol = false; continue; }
      if (PUNCT1.includes(c)) { push("p", c, start); i++; atBol = false; continue; }
      throw new CypherSyntaxError(`Unexpected character '${c}'`, { line: tokLine, col: start - tokLineStart + 1 });
    }
    tokens.push({ t: "eof", v: null, pos: n, line, col: n - lineStart + 1, bol: true });
    return tokens;
  }

  // ------------------------------------------------------------------ parser

  const CLAUSE_WORDS = new Set(["MATCH", "OPTIONAL", "CREATE", "MERGE", "SET", "REMOVE", "DELETE", "DETACH", "RETURN", "WITH", "UNWIND", "WHERE"]);
  const UPDATING = new Set(["CREATE", "MERGE", "SET", "REMOVE", "DELETE"]);

  class Parser {
    constructor(tokens) { this.toks = tokens; this.i = 0; }
    peek(o = 0) { return this.toks[Math.min(this.i + o, this.toks.length - 1)]; }
    next() { return this.toks[this.i++]; }
    isKw(word, o = 0) { const t = this.peek(o); return t.t === "id" && !t.quoted && t.v.toUpperCase() === word; }
    isP(v, o = 0) { const t = this.peek(o); return t.t === "p" && t.v === v; }
    eatKw(word) { if (this.isKw(word)) return this.next(); return null; }
    eatP(v) { if (this.isP(v)) return this.next(); return null; }
    expectKw(word) { const t = this.eatKw(word); if (!t) throw new CypherSyntaxError(`Expected ${word}`, this.peek()); return t; }
    expectP(v) { const t = this.eatP(v); if (!t) throw new CypherSyntaxError(`Expected '${v}' but found ${describe(this.peek())}`, this.peek()); return t; }
    ident() {
      const t = this.peek();
      if (t.t !== "id") throw new CypherSyntaxError(`Expected a name but found ${describe(t)}`, t);
      this.i++;
      return t.v;
    }

    /** Parse the whole script into statements; a statement is a list of clauses. */
    script() {
      const statements = [];
      let clauses = [];
      let lastWasUpdate = false;
      const flush = () => { if (clauses.length) statements.push(clauses); clauses = []; lastWasUpdate = false; };
      while (this.peek().t !== "eof") {
        if (this.eatP(";")) { flush(); continue; }
        const t = this.peek();
        const word = t.t === "id" && !t.quoted ? t.v.toUpperCase() : "";
        const startsReading = word === "MATCH" || word === "OPTIONAL" || word === "UNWIND";
        if (startsReading && lastWasUpdate) flush();
        const clause = this.clause();
        if (clause) {
          clauses.push(clause);
          lastWasUpdate = UPDATING.has(clause.kind);
          if (clause.kind === "RETURN") flush();
        }
      }
      flush();
      return statements;
    }

    clause() {
      const t = this.peek();
      if (t.t !== "id") throw new CypherSyntaxError(`Expected a clause (CREATE, MATCH, MERGE, ...) but found ${describe(t)}`, t);
      const word = t.v.toUpperCase();
      const line = t.line;
      switch (word) {
        case "CREATE": this.next(); return { kind: "CREATE", line, patterns: this.patternList() };
        case "MATCH": {
          this.next();
          const patterns = this.patternList();
          const where = this.eatKw("WHERE") ? this.expr() : null;
          return { kind: "MATCH", line, optional: false, patterns, where };
        }
        case "OPTIONAL": {
          this.next(); this.expectKw("MATCH");
          const patterns = this.patternList();
          const where = this.eatKw("WHERE") ? this.expr() : null;
          return { kind: "MATCH", line, optional: true, patterns, where };
        }
        case "MERGE": {
          this.next();
          const pattern = this.pattern();
          const onCreate = [], onMatch = [];
          while (this.isKw("ON")) {
            this.next();
            const which = this.eatKw("CREATE") ? onCreate : (this.expectKw("MATCH"), onMatch);
            this.expectKw("SET");
            which.push(...this.setItems());
          }
          return { kind: "MERGE", line, pattern, onCreate, onMatch };
        }
        case "SET": this.next(); return { kind: "SET", line, items: this.setItems() };
        case "REMOVE": {
          this.next();
          const items = [];
          do {
            const v = this.ident();
            if (this.eatP(".")) items.push({ kind: "prop", variable: v, key: this.ident() });
            else { const labels = []; while (this.eatP(":")) labels.push(this.ident()); items.push({ kind: "labels", variable: v, labels }); }
          } while (this.eatP(","));
          return { kind: "REMOVE", line, items };
        }
        case "DETACH": case "DELETE": {
          const detach = !!this.eatKw("DETACH");
          this.expectKw("DELETE");
          const targets = [];
          do targets.push(this.expr()); while (this.eatP(","));
          return { kind: "DELETE", line, detach, targets };
        }
        case "RETURN": case "WITH": case "UNWIND": {
          this.next();
          this.skipToClauseBoundary();
          return { kind: word, line };
        }
        default:
          throw new CypherSyntaxError(`Unsupported clause '${t.v}'`, t);
      }
    }

    /** Skip tokens until a semicolon or a clause keyword that starts a line. */
    skipToClauseBoundary() {
      let depth = 0;
      while (this.peek().t !== "eof") {
        const t = this.peek();
        if (t.t === "p" && "([{".includes(t.v)) depth++;
        if (t.t === "p" && ")]}".includes(t.v)) depth--;
        if (depth <= 0 && t.t === "p" && t.v === ";") return;
        if (depth <= 0 && t.bol && t.t === "id" && CLAUSE_WORDS.has(t.v.toUpperCase())) return;
        this.next();
      }
    }

    setItems() {
      const items = [];
      do {
        const v = this.ident();
        if (this.eatP(".")) { const key = this.ident(); this.expectP("="); items.push({ kind: "prop", variable: v, key, value: this.expr() }); }
        else if (this.eatP("+=")) items.push({ kind: "merge", variable: v, value: this.expr() });
        else if (this.eatP("=")) items.push({ kind: "replace", variable: v, value: this.expr() });
        else if (this.isP(":")) { const labels = []; while (this.eatP(":")) labels.push(this.ident()); items.push({ kind: "labels", variable: v, labels }); }
        else throw new CypherSyntaxError(`Expected '.', '=', '+=' or ':' after ${v}`, this.peek());
      } while (this.eatP(","));
      return items;
    }

    patternList() {
      const list = [this.pattern()];
      while (this.eatP(",")) list.push(this.pattern());
      return list;
    }

    pattern() {
      let pathVar = null;
      if (this.peek().t === "id" && this.isP("=", 1)) { pathVar = this.ident(); this.next(); }
      const first = this.nodePattern();
      const steps = [];
      while (this.isP("-") || this.isP("<-") || this.isP("<")) {
        const rel = this.relPattern();
        steps.push({ rel, node: this.nodePattern() });
      }
      return { pathVar, first, steps, line: first.line };
    }

    nodePattern() {
      const open = this.expectP("(");
      let variable = null;
      const labels = [];
      let props = null;
      if (this.peek().t === "id") variable = this.ident();
      while (this.eatP(":")) labels.push(this.ident());
      if (this.isP("{")) props = this.mapLiteral();
      this.expectP(")");
      return { variable, labels, props, line: open.line };
    }

    relPattern() {
      let left = false, right = false;
      if (this.eatP("<-")) left = true;
      else if (this.eatP("<")) { left = true; this.expectP("-"); }
      else this.expectP("-");
      let variable = null, types = [], props = null;
      if (this.eatP("[")) {
        if (this.peek().t === "id") variable = this.ident();
        if (this.eatP(":")) {
          types.push(this.ident());
          while (this.eatP("|")) { this.eatP(":"); types.push(this.ident()); }
        }
        if (this.isP("*")) throw new CypherSyntaxError("Variable-length relationships are not supported", this.peek());
        if (this.isP("{")) props = this.mapLiteral();
        this.expectP("]");
      }
      if (this.eatP("->")) right = true;
      else this.expectP("-");
      if (!right && this.eatP(">")) right = true;
      return { variable, types, props, direction: left && !right ? "left" : right && !left ? "right" : "both" };
    }

    mapLiteral() {
      this.expectP("{");
      const entries = [];
      if (!this.isP("}")) {
        do {
          const t = this.peek();
          let key;
          if (t.t === "id" || t.t === "str") { key = t.v; this.next(); }
          else throw new CypherSyntaxError(`Expected a property name but found ${describe(t)}`, t);
          this.expectP(":");
          entries.push([key, this.expr()]);
        } while (this.eatP(","));
      }
      this.expectP("}");
      return { type: "map", entries };
    }

    // expression grammar ----------------------------------------------------
    expr() { return this.orExpr(); }
    orExpr() {
      let left = this.xorExpr();
      while (this.eatKw("OR")) left = { type: "or", left, right: this.xorExpr() };
      return left;
    }
    xorExpr() {
      let left = this.andExpr();
      while (this.eatKw("XOR")) left = { type: "xor", left, right: this.andExpr() };
      return left;
    }
    andExpr() {
      let left = this.notExpr();
      while (this.eatKw("AND")) left = { type: "and", left, right: this.notExpr() };
      return left;
    }
    notExpr() {
      if (this.eatKw("NOT")) return { type: "not", arg: this.notExpr() };
      return this.comparison();
    }
    comparison() {
      let left = this.additive();
      for (;;) {
        const t = this.peek();
        if (t.t === "p" && ["=", "<>", "<", ">", "<=", ">=", "=~"].includes(t.v)) {
          this.next();
          left = { type: "cmp", op: t.v, left, right: this.additive() };
        } else if (this.isKw("IN")) { this.next(); left = { type: "cmp", op: "IN", left, right: this.additive() }; }
        else if (this.isKw("CONTAINS")) { this.next(); left = { type: "cmp", op: "CONTAINS", left, right: this.additive() }; }
        else if (this.isKw("STARTS")) { this.next(); this.expectKw("WITH"); left = { type: "cmp", op: "STARTS", left, right: this.additive() }; }
        else if (this.isKw("ENDS")) { this.next(); this.expectKw("WITH"); left = { type: "cmp", op: "ENDS", left, right: this.additive() }; }
        else if (this.isKw("IS")) {
          this.next();
          const negate = !!this.eatKw("NOT");
          this.expectKw("NULL");
          left = { type: "isnull", negate, arg: left };
        } else return left;
      }
    }
    additive() {
      let left = this.unary();
      for (;;) {
        if (this.eatP("+")) left = { type: "bin", op: "+", left, right: this.unary() };
        else if (this.isP("-") && !this.isP("[", 1) && !this.isP(">", 1)) { this.next(); left = { type: "bin", op: "-", left, right: this.unary() }; }
        else if (this.eatP("*")) left = { type: "bin", op: "*", left, right: this.unary() };
        else if (this.eatP("/")) left = { type: "bin", op: "/", left, right: this.unary() };
        else return left;
      }
    }
    unary() {
      if (this.eatP("-")) return { type: "neg", arg: this.unary() };
      if (this.eatP("+")) return this.unary();
      return this.postfix();
    }
    postfix() {
      let e = this.primary();
      for (;;) {
        if (this.isP(".") && this.peek(1).t === "id") { this.next(); e = { type: "prop", obj: e, key: this.ident() }; }
        else if (this.eatP("[")) { const index = this.expr(); this.expectP("]"); e = { type: "index", obj: e, index }; }
        else return e;
      }
    }
    primary() {
      const t = this.peek();
      if (t.t === "str") { this.next(); return { type: "lit", value: t.v }; }
      if (t.t === "num") { this.next(); return { type: "lit", value: t.v }; }
      if (t.t === "p" && t.v === "[") {
        this.next();
        const items = [];
        if (!this.isP("]")) do items.push(this.expr()); while (this.eatP(","));
        this.expectP("]");
        return { type: "list", items };
      }
      if (t.t === "p" && t.v === "{") return this.mapLiteral();
      if (t.t === "p" && t.v === "(") { this.next(); const e = this.expr(); this.expectP(")"); return e; }
      if (t.t === "p" && t.v === "$") throw new CypherSyntaxError("Query parameters ($name) are not supported in scripts", t);
      if (t.t === "id") {
        const up = t.quoted ? "" : t.v.toUpperCase();
        if (up === "TRUE") { this.next(); return { type: "lit", value: true }; }
        if (up === "FALSE") { this.next(); return { type: "lit", value: false }; }
        if (up === "NULL") { this.next(); return { type: "lit", value: null }; }
        if (this.isP("(", 1)) {
          const name = this.ident().toLowerCase();
          this.next();
          const args = [];
          if (!this.isP(")")) do args.push(this.expr()); while (this.eatP(","));
          this.expectP(")");
          return { type: "call", name, args };
        }
        this.next();
        return { type: "var", name: t.v };
      }
      throw new CypherSyntaxError(`Unexpected ${describe(t)}`, t);
    }
  }

  function describe(t) {
    if (!t || t.t === "eof") return "end of file";
    if (t.t === "str") return `string '${t.v}'`;
    return `'${t.v}'`;
  }

  // ------------------------------------------------------------------ graph

  class Graph {
    constructor() {
      this.nodes = new Map();
      this.rels = new Map();
      this.out = new Map();
      this.in = new Map();
      this.seq = 0;
      this._index = new Map();
    }
    createNode(labels, props, line) {
      const node = { id: ++this.seq, labels: [...new Set(labels)], props: { ...props }, lines: [line] };
      this.nodes.set(node.id, node);
      this.out.set(node.id, new Set());
      this.in.set(node.id, new Set());
      this._index.clear();
      return node;
    }
    createRel(type, start, end, props, line) {
      const rel = { id: ++this.seq, type, start, end, props: { ...props }, lines: [line] };
      this.rels.set(rel.id, rel);
      this.out.get(start).add(rel.id);
      this.in.get(end).add(rel.id);
      return rel;
    }
    deleteRel(id) {
      const rel = this.rels.get(id);
      if (!rel) return;
      this.out.get(rel.start)?.delete(id);
      this.in.get(rel.end)?.delete(id);
      this.rels.delete(id);
    }
    deleteNode(id, detach) {
      const attached = [...(this.out.get(id) || []), ...(this.in.get(id) || [])];
      if (attached.length && !detach) return false;
      attached.forEach((r) => this.deleteRel(r));
      this.nodes.delete(id);
      this.out.delete(id);
      this.in.delete(id);
      this._index.clear();
      return true;
    }
    touched() { this._index.clear(); }
    /** Candidate nodes for a pattern, using a lazily built index on the first property. */
    candidates(labels, props) {
      const keys = props ? Object.keys(props) : [];
      let pool;
      if (keys.length) {
        const key = keys[0];
        if (!this._index.has(key)) {
          const idx = new Map();
          for (const n of this.nodes.values()) {
            if (!(key in n.props)) continue;
            const k = valueKey(n.props[key]);
            if (!idx.has(k)) idx.set(k, []);
            idx.get(k).push(n);
          }
          this._index.set(key, idx);
        }
        pool = this._index.get(key).get(valueKey(props[key])) || [];
      } else pool = this.nodes.values();
      const out = [];
      for (const n of pool) {
        if (labels.some((l) => !n.labels.includes(l))) continue;
        if (keys.some((k) => !(k in n.props) || !deepEqual(n.props[k], props[k]))) continue;
        out.push(n);
      }
      return out;
    }
    relsOf(nodeId, direction) {
      if (direction === "out") return [...(this.out.get(nodeId) || [])].map((r) => this.rels.get(r));
      if (direction === "in") return [...(this.in.get(nodeId) || [])].map((r) => this.rels.get(r));
      return [...this.relsOf(nodeId, "out"), ...this.relsOf(nodeId, "in")];
    }
  }

  function valueKey(v) { return typeof v === "object" && v !== null ? JSON.stringify(v) : typeof v + ":" + String(v); }
  function deepEqual(a, b) {
    if (a === b) return true;
    if (typeof a === "number" && typeof b === "number") return a === b;
    if (Array.isArray(a) && Array.isArray(b)) return a.length === b.length && a.every((x, i) => deepEqual(x, b[i]));
    if (a && b && typeof a === "object" && typeof b === "object") {
      const ka = Object.keys(a), kb = Object.keys(b);
      return ka.length === kb.length && ka.every((k) => deepEqual(a[k], b[k]));
    }
    return false;
  }

  // ------------------------------------------------------------------ executor

  const NODE = "node", REL = "rel";

  class Executor {
    constructor(graph, diagnostics) {
      this.g = graph;
      this.diag = diagnostics;
      this.scriptScope = new Map();
    }

    run(statements) {
      for (const clauses of statements) {
        try { this.statement(clauses); }
        catch (err) { this.diag.push({ level: "error", line: err.line || clauses[0].line, message: err.message }); }
      }
    }

    statement(clauses) {
      let rows = [new Map()];
      for (const clause of clauses) {
        const before = rows.length;
        switch (clause.kind) {
          case "MATCH": rows = this.match(rows, clause); break;
          case "CREATE": rows.forEach((row) => this.create(row, clause)); break;
          case "MERGE": rows = this.merge(rows, clause); break;
          case "SET": rows.forEach((row) => this.set(row, clause.items, clause.line)); break;
          case "REMOVE": rows.forEach((row) => this.remove(row, clause)); break;
          case "DELETE": rows.forEach((row) => this.del(row, clause)); break;
          case "RETURN": case "WITH": case "UNWIND":
            if (clause.kind !== "RETURN") this.diag.push({ level: "warning", line: clause.line, message: `${clause.kind} is not interpreted; the rest of this statement runs against the rows before it.` });
            break;
        }
        if (clause.kind === "MATCH" && before > 0 && rows.length === 0 && !clause.optional) {
          const rest = clauses.slice(clauses.indexOf(clause) + 1).filter((c) => UPDATING.has(c.kind));
          if (rest.length) this.explainEmptyMatch(clause, rest);
          return;
        }
      }
      // Promote single-row CREATE/MERGE bindings to script scope.
      if (rows.length === 1) {
        for (const [k, v] of rows[0]) if (v && v.kind === NODE && v.created) this.scriptScope.set(k, v);
      }
    }

    explainEmptyMatch(clause, rest) {
      const missing = [];
      for (const p of clause.patterns) {
        for (const np of [p.first, ...p.steps.map((s) => s.node)]) {
          if (!np.labels.length && !np.props) continue;
          const props = np.props ? this.evalMap(np.props, new Map()) : null;
          if (!this.g.candidates(np.labels, props).length) missing.push(describeNodePattern(np, props));
        }
      }
      const what = rest.map((c) => c.kind).join(" + ");
      const why = missing.length ? `no node matches ${missing.join(" or ")}` : "the pattern has no match";
      this.diag.push({ level: "warning", line: clause.line, code: "empty-match", message: `MATCH found nothing (${why}), so the ${what} on this line did nothing.` });
    }

    lookup(row, name) {
      if (row.has(name)) return row.get(name);
      if (this.scriptScope.has(name)) {
        const v = this.scriptScope.get(name);
        if (v.kind === NODE && !this.g.nodes.has(v.id)) return undefined;
        return v;
      }
      return undefined;
    }

    // MATCH ----------------------------------------------------------------
    match(rows, clause) {
      const out = [];
      for (const row of rows) {
        let partial = [new Map(row)];
        for (const pattern of clause.patterns) {
          const next = [];
          for (const r of partial) next.push(...this.matchPattern(r, pattern));
          partial = next;
          if (!partial.length) break;
        }
        if (clause.where) partial = partial.filter((r) => truthy(this.evaluate(clause.where, r)));
        if (partial.length) out.push(...partial);
        else if (clause.optional) {
          const r = new Map(row);
          for (const p of clause.patterns) for (const v of patternVariables(p)) if (!r.has(v)) r.set(v, null);
          out.push(r);
        }
      }
      return out;
    }

    matchPattern(row, pattern) {
      const results = [];
      const nodes = [pattern.first, ...pattern.steps.map((s) => s.node)];
      const walk = (idx, r, usedRels) => {
        if (idx === nodes.length) { results.push(r); return; }
        const np = nodes[idx];
        const props = np.props ? this.evalMap(np.props, r) : null;
        let candidates;
        const bound = np.variable && r.has(np.variable) ? r.get(np.variable) : undefined;
        if (idx === 0) {
          candidates = bound ? (bound && bound.kind === NODE && this.g.nodes.has(bound.id) ? [this.g.nodes.get(bound.id)] : [])
                             : this.g.candidates(np.labels, props);
          candidates = candidates.filter((n) => nodeFits(n, np.labels, props));
          for (const n of candidates) {
            const r2 = new Map(r);
            if (np.variable) r2.set(np.variable, { kind: NODE, id: n.id });
            walk(1, r2, usedRels);
          }
          return;
        }
        const step = pattern.steps[idx - 1];
        const prev = r.get(nodes[idx - 1].variable) || r.get(`#n${idx - 1}`);
        const rp = step.rel;
        const relProps = rp.props ? this.evalMap(rp.props, r) : null;
        const dirs = rp.direction === "right" ? ["out"] : rp.direction === "left" ? ["in"] : ["out", "in"];
        for (const d of dirs) {
          for (const rel of this.g.relsOf(prev.id, d)) {
            if (usedRels.has(rel.id)) continue;
            if (rp.types.length && !rp.types.includes(rel.type)) continue;
            if (relProps && Object.keys(relProps).some((k) => !deepEqual(rel.props[k], relProps[k]))) continue;
            const otherId = d === "out" ? rel.end : rel.start;
            const other = this.g.nodes.get(otherId);
            if (bound && bound.id !== otherId) continue;
            if (!nodeFits(other, np.labels, props)) continue;
            if (rp.variable && r.has(rp.variable) && r.get(rp.variable).id !== rel.id) continue;
            const r2 = new Map(r);
            if (rp.variable) r2.set(rp.variable, { kind: REL, id: rel.id });
            r2.set(np.variable || `#n${idx}`, { kind: NODE, id: other.id });
            walk(idx + 1, r2, new Set([...usedRels, rel.id]));
          }
        }
      };
      // Anonymous first node needs a synthetic name so steps can find it.
      if (!pattern.first.variable) {
        const tmp = { ...pattern, first: { ...pattern.first, variable: "#n0" } };
        nodes[0] = tmp.first;
      }
      walk(0, row, new Set());
      return results.map((r) => { for (const k of [...r.keys()]) if (k.startsWith("#n")) r.delete(k); return r; });
    }

    // CREATE ---------------------------------------------------------------
    create(row, clause) {
      for (const pattern of clause.patterns) this.createPattern(row, pattern, clause.line);
    }

    createPattern(row, pattern, line) {
      const resolveNode = (np) => {
        if (np.variable) {
          const existing = this.lookup(row, np.variable);
          if (existing) {
            if (existing.kind !== NODE) throw Object.assign(new Error(`${np.variable} is a relationship, not a node`), { line: np.line });
            if (np.labels.length || np.props) {
              throw Object.assign(new Error(`Variable '${np.variable}' is already bound; CREATE cannot redeclare it with labels or properties`), { line: np.line });
            }
            return this.g.nodes.get(existing.id);
          }
        }
        const props = np.props ? this.evalMap(np.props, row) : {};
        const node = this.g.createNode(np.labels, stripNulls(props), np.line || line);
        if (np.variable) row.set(np.variable, { kind: NODE, id: node.id, created: true });
        return node;
      };
      let prev = resolveNode(pattern.first);
      for (const step of pattern.steps) {
        const next = resolveNode(step.node);
        const rp = step.rel;
        if (rp.types.length !== 1) throw Object.assign(new Error("CREATE needs exactly one relationship type"), { line });
        let [a, b] = [prev, next];
        if (rp.direction === "left") [a, b] = [next, prev];
        else if (rp.direction === "both") this.diag.push({ level: "warning", line, message: "CREATE with an undirected relationship; it was stored left to right." });
        const props = rp.props ? this.evalMap(rp.props, row) : {};
        const rel = this.g.createRel(rp.types[0], a.id, b.id, stripNulls(props), line);
        if (rp.variable) row.set(rp.variable, { kind: REL, id: rel.id });
        prev = next;
      }
    }

    // MERGE ----------------------------------------------------------------
    merge(rows, clause) {
      const out = [];
      for (const row of rows) {
        const found = this.matchPattern(new Map(row), clause.pattern);
        if (found.length) {
          for (const r of found) { this.set(r, clause.onMatch, clause.line); out.push(r); }
        } else {
          const r = new Map(row);
          const pattern = clause.pattern;
          // Reuse any node in the path that is already bound or matchable on its own.
          this.createPattern(r, pattern, clause.line);
          for (const v of patternVariables(pattern)) { const b = r.get(v); if (b && b.kind === NODE) b.created = true; }
          this.set(r, clause.onCreate, clause.line);
          out.push(r);
        }
      }
      return out;
    }

    // SET / REMOVE / DELETE -------------------------------------------------
    target(row, variable, line) {
      const ref = this.lookup(row, variable);
      if (!ref) throw Object.assign(new Error(`Unknown variable '${variable}'`), { line });
      const obj = ref.kind === NODE ? this.g.nodes.get(ref.id) : this.g.rels.get(ref.id);
      if (!obj) throw Object.assign(new Error(`'${variable}' was deleted earlier in this statement`), { line });
      return { ref, obj };
    }

    set(row, items, line) {
      for (const item of items) {
        const { ref, obj } = this.target(row, item.variable, line);
        if (item.kind === "prop") {
          const v = this.evaluate(item.value, row);
          if (v === null || v === undefined) delete obj.props[item.key];
          else obj.props[item.key] = v;
        } else if (item.kind === "merge") {
          const m = this.evaluate(item.value, row);
          for (const [k, v] of Object.entries(m || {})) { if (v === null) delete obj.props[k]; else obj.props[k] = v; }
        } else if (item.kind === "replace") {
          const m = this.evaluate(item.value, row);
          obj.props = stripNulls({ ...(m || {}) });
        } else if (item.kind === "labels") {
          if (ref.kind !== NODE) throw Object.assign(new Error("Labels can only be set on nodes"), { line });
          for (const l of item.labels) if (!obj.labels.includes(l)) obj.labels.push(l);
        }
        if (!obj.lines.includes(line)) obj.lines.push(line);
        this.g.touched();
      }
    }

    remove(row, clause) {
      for (const item of clause.items) {
        const { obj } = this.target(row, item.variable, clause.line);
        if (item.kind === "prop") delete obj.props[item.key];
        else obj.labels = obj.labels.filter((l) => !item.labels.includes(l));
        if (!obj.lines.includes(clause.line)) obj.lines.push(clause.line);
        this.g.touched();
      }
    }

    del(row, clause) {
      for (const expr of clause.targets) {
        const ref = this.evaluate(expr, row, true);
        if (!ref) continue;
        if (ref.kind === REL) this.g.deleteRel(ref.id);
        else if (ref.kind === NODE) {
          if (!this.g.deleteNode(ref.id, clause.detach)) {
            this.diag.push({ level: "error", line: clause.line, message: "DELETE of a node that still has relationships; use DETACH DELETE." });
          }
        }
      }
    }

    // expressions ----------------------------------------------------------
    evalMap(mapExpr, row) {
      const out = {};
      for (const [k, e] of mapExpr.entries) out[k] = this.evaluate(e, row);
      return out;
    }

    evaluate(e, row, wantRef) {
      switch (e.type) {
        case "lit": return e.value;
        case "list": return e.items.map((x) => this.evaluate(x, row));
        case "map": return this.evalMap(e, row);
        case "var": {
          const v = this.lookup(row, e.name);
          if (v === undefined) throw new Error(`Unknown variable '${e.name}'`);
          return wantRef ? v : v;
        }
        case "prop": {
          const base = this.evaluate(e.obj, row);
          if (base === null || base === undefined) return null;
          if (base.kind === NODE) return this.g.nodes.get(base.id)?.props[e.key] ?? null;
          if (base.kind === REL) return this.g.rels.get(base.id)?.props[e.key] ?? null;
          if (typeof base === "object") return base[e.key] ?? null;
          return null;
        }
        case "index": {
          const base = this.evaluate(e.obj, row), i = this.evaluate(e.index, row);
          if (Array.isArray(base)) return base[i < 0 ? base.length + i : i] ?? null;
          if (base && typeof base === "object") return base[i] ?? null;
          return null;
        }
        case "neg": return -this.evaluate(e.arg, row);
        case "not": { const v = this.evaluate(e.arg, row); return v === null ? null : !truthy(v); }
        case "and": { const a = this.evaluate(e.left, row); if (a === false) return false; const b = this.evaluate(e.right, row); return a === null || b === null ? (b === false ? false : null) : truthy(a) && truthy(b); }
        case "or": { const a = this.evaluate(e.left, row); if (a === true) return true; const b = this.evaluate(e.right, row); return a === null || b === null ? (b === true ? true : null) : truthy(a) || truthy(b); }
        case "xor": { const a = this.evaluate(e.left, row), b = this.evaluate(e.right, row); return a === null || b === null ? null : truthy(a) !== truthy(b); }
        case "isnull": { const v = this.evaluate(e.arg, row); const isNull = v === null || v === undefined; return e.negate ? !isNull : isNull; }
        case "bin": {
          const a = this.evaluate(e.left, row), b = this.evaluate(e.right, row);
          if (a === null || b === null) return null;
          if (e.op === "+") return Array.isArray(a) ? a.concat(b) : a + b;
          if (e.op === "-") return a - b;
          if (e.op === "*") return a * b;
          return a / b;
        }
        case "cmp": {
          const a = this.evaluate(e.left, row), b = this.evaluate(e.right, row);
          if (e.op === "IN") return Array.isArray(b) ? b.some((x) => deepEqual(x, a)) : null;
          if (a === null || b === null) return null;
          switch (e.op) {
            case "=": return deepEqual(a, b);
            case "<>": return !deepEqual(a, b);
            case "<": return a < b;
            case ">": return a > b;
            case "<=": return a <= b;
            case ">=": return a >= b;
            case "=~": return new RegExp(`^(?:${b})$`).test(String(a));
            case "CONTAINS": return String(a).includes(String(b));
            case "STARTS": return String(a).startsWith(String(b));
            case "ENDS": return String(a).endsWith(String(b));
          }
          return null;
        }
        case "call": return this.call(e, row);
      }
      throw new Error(`Cannot evaluate ${e.type}`);
    }

    call(e, row) {
      const args = e.args.map((a) => this.evaluate(a, row));
      const a = args[0];
      switch (e.name) {
        case "tolower": return a == null ? null : String(a).toLowerCase();
        case "toupper": return a == null ? null : String(a).toUpperCase();
        case "trim": return a == null ? null : String(a).trim();
        case "tostring": return a == null ? null : String(a);
        case "tointeger": return a == null ? null : parseInt(a, 10);
        case "tofloat": return a == null ? null : parseFloat(a);
        case "coalesce": return args.find((x) => x !== null && x !== undefined) ?? null;
        case "size": return a == null ? null : (Array.isArray(a) || typeof a === "string" ? a.length : null);
        case "labels": return a && a.kind === NODE ? [...this.g.nodes.get(a.id).labels] : null;
        case "type": return a && a.kind === REL ? this.g.rels.get(a.id).type : null;
        case "keys": { if (!a) return null; const o = a.kind === NODE ? this.g.nodes.get(a.id).props : a.kind === REL ? this.g.rels.get(a.id).props : a; return Object.keys(o); }
        case "exists": return a !== null && a !== undefined;
      }
      throw new Error(`Unsupported function ${e.name}()`);
    }
  }

  function truthy(v) { return v === true || (v !== false && v !== null && v !== undefined && v !== 0 && v !== ""); }
  function stripNulls(o) { for (const k of Object.keys(o)) if (o[k] === null || o[k] === undefined) delete o[k]; return o; }
  function nodeFits(n, labels, props) {
    if (!n) return false;
    if (labels.some((l) => !n.labels.includes(l))) return false;
    if (props && Object.keys(props).some((k) => !deepEqual(n.props[k], props[k]))) return false;
    return true;
  }
  function patternVariables(p) {
    const vars = [];
    if (p.first.variable) vars.push(p.first.variable);
    for (const s of p.steps) { if (s.rel.variable) vars.push(s.rel.variable); if (s.node.variable) vars.push(s.node.variable); }
    return vars;
  }
  function describeNodePattern(np, props) {
    const labels = np.labels.map((l) => ":" + l).join("");
    const body = props ? (labels ? " " : "") + "{" + Object.entries(props).map(([k, v]) => `${k}: ${JSON.stringify(v)}`).join(", ") + "}" : "";
    return `(${labels}${body})`;
  }

  // ------------------------------------------------------------------ lint

  function lint(graph, diagnostics) {
    const seen = new Map();
    for (const rel of graph.rels.values()) {
      const key = `${rel.type}|${rel.start}|${rel.end}`;
      if (!seen.has(key)) seen.set(key, []);
      seen.get(key).push(rel);
    }
    const label = (id) => { const n = graph.nodes.get(id); return n.props.id ?? n.props.name ?? `#${id}`; };
    for (const list of seen.values()) {
      if (list.length < 2) continue;
      const r = list[0];
      diagnostics.push({
        level: "info", line: list[1].lines[0], code: "duplicate-rel",
        message: `${r.type} from ${label(r.start)} to ${label(r.end)} is created ${list.length} times (lines ${list.map((x) => x.lines[0]).join(", ")}).`,
      });
    }
    const ids = new Map();
    for (const n of graph.nodes.values()) {
      if (n.props.id === undefined) continue;
      const k = valueKey(n.props.id);
      if (ids.has(k)) diagnostics.push({ level: "warning", line: n.lines[0], code: "duplicate-id", message: `Two nodes share id ${JSON.stringify(n.props.id)} (lines ${ids.get(k).lines[0]} and ${n.lines[0]}).` });
      else ids.set(k, n);
    }
  }

  /** Parse and run a script. Returns the graph plus diagnostics. */
  function load(source) {
    const diagnostics = [];
    const graph = new Graph();
    let statements = [];
    try {
      statements = new Parser(tokenize(source)).script();
    } catch (err) {
      if (!(err instanceof CypherSyntaxError)) throw err;
      diagnostics.push({ level: "error", line: err.line, col: err.col, code: "syntax", message: err.message });
      // Recover: run every line that parses on its own so the rest still renders.
      statements = recoverStatements(source, diagnostics, err.line);
    }
    new Executor(graph, diagnostics).run(statements);
    lint(graph, diagnostics);
    diagnostics.sort((a, b) => (a.line || 0) - (b.line || 0));
    return { graph, diagnostics, statementCount: statements.length };
  }

  function recoverStatements(source, diagnostics, badLine) {
    const lines = source.split("\n");
    const statements = [];
    let chunk = [], chunkStart = 1;
    const tryChunk = () => {
      if (!chunk.length) return;
      const text = "\n".repeat(chunkStart - 1) + chunk.join("\n");
      try { statements.push(...new Parser(tokenize(text)).script()); }
      catch (err) {
        if (err.line !== badLine) diagnostics.push({ level: "error", line: err.line, col: err.col, code: "syntax", message: err.message });
      }
      chunk = [];
    };
    lines.forEach((text, i) => {
      if (/^\s*(CREATE|MATCH|MERGE|OPTIONAL|SET|REMOVE|DETACH|DELETE|RETURN|WITH|UNWIND)\b/i.test(text) && !/^\s*(SET|REMOVE|DELETE|RETURN|WITH)\b/i.test(text)) {
        tryChunk();
        chunkStart = i + 1;
      }
      chunk.push(text);
    });
    tryChunk();
    return statements;
  }

  return { load, tokenize, Parser, Graph, CypherSyntaxError };
});
