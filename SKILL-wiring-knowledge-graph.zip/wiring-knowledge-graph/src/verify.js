/* ============================================================================
 * Drawing checks
 *
 * Audits a laid-out scene against the graph it came from and against KiCad's
 * schematic conventions, so a drawing that misrepresents a pin, a connector or
 * a connection is reported rather than trusted.
 *
 * Fidelity to the graph
 *   pin-once          every drawn contact appears exactly once, on its own part
 *   pin-number        a shown pin number is the graph's number, and only the graph's
 *   connector-order   a connector's positions sit on one edge, contiguous; in the physical layout
 *                     (and on library symbols) in number order
 *   pair-adjacent     in the logical layout, pins of one bus or one twisted pair on a connector
 *                     stand next to each other
 *   mate-order        mated connectors line up position for position, so mates never cross
 *   connector-symbol  a free connector's library symbol matches its gender and position count
 *   connector-shown   a part with several connectors names each one
 *   pin-in-connector  every physical pin belongs to a connector, unless the graph marks it a lead
 *   connector-whole   an unnumbered connector's pins still share one edge, unbroken
 *   location-claim    in the physical layout, a pin the graph does not locate is marked so
 *   physical-order    in the physical layout, pins recorded higher on the part are drawn higher,
 *                     across both edges
 *   no-splice         conductors meet only where the graph says they do: at a pin, never mid-run
 *
 * Schematic conventions (KiCad)
 *   pin-grid          pin connection points on the 100 mil grid
 *   wire-endpoint     every wire ends exactly on the connection point it belongs to
 *   false-connection  no wire passes over another net's connection point
 *   net-overlap       no two nets share a stretch of line
 *   wire-orthogonal   wires run horizontally and vertically (bus entries at 45 degrees)
 *   junction-net      a junction dot joins one net only
 *   wire-through-body no wire crosses a symbol body
 *   text-clear        part names, references and pin captions stay off wires, parts and each other
 *   part-overlap      no two symbols overlap (a plug seated on its mate may touch it, face to pin)
 *   mate-direct       a plug sits against what it mates with: straight, short mate lines
 *   pin-number-unique no number appears twice on one symbol (KiCad reads that as one pad)
 *   collinear-gap     two nets never continue each other's line across a small gap
 *   side-by-side      two nets never run alongside each other closer than a wire is wide
 *   term-defined      when the graph embeds a vocabulary, every label, relationship type and
 *                     property it uses is defined there
 *   term-usage        and used as defined: relationship ends, which labels carry a property,
 *                     value types, value sets and required properties
 *   net-declared      a net the graph declares by name is one connected net, and two declared
 *                     nets are never joined by the connectivity
 *
 * Each finding: { check, level: "error" | "warning", message, at: [x, y] | null, refs }.
 * ========================================================================== */

(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.KGVerify = api;
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";

  const GRID = 100;
  const EPS = 1;
  const OPPOSITE = { WEST: "EAST", EAST: "WEST", NORTH: "SOUTH", SOUTH: "NORTH" };

  const CHECKS = [
    ["pin-once", "Each contact drawn once, on its own part"],
    ["pin-number", "Pin numbers come from the graph"],
    ["connector-order", "Connector positions contiguous (number order in the physical layout)"],
    ["pair-adjacent", "Pins of one bus or twisted pair side by side (logical layout)"],
    ["mate-order", "Mated connectors line up position for position"],
    ["connector-symbol", "Connector symbol matches gender and position count"],
    ["connector-shown", "Each connector on a part is named"],
    ["pin-in-connector", "Every physical pin belongs to a connector"],
    ["connector-whole", "Each connector's pins kept together on one edge"],
    ["location-claim", "Unrecorded pin positions marked in the physical layout"],
    ["physical-order", "Recorded pin heights kept across both edges"],
    ["pin-number-unique", "No pin number repeated within a symbol"],
    ["pin-grid", "Pin connection points on the 100 mil grid"],
    ["wire-endpoint", "Wires end on their own connection points"],
    ["false-connection", "No wire crosses another net's connection point"],
    ["net-overlap", "No two nets share a stretch of line"],
    ["wire-orthogonal", "Wires run horizontally and vertically"],
    ["no-splice", "Conductors meet only at pins"],
    ["shared-terminal", "Conductors on one terminal part within its lead (noted)"],
    ["collinear-gap", "No two nets line up across a small gap"],
    ["side-by-side", "No two nets run closer than a wire's width"],
    ["net-declared", "Each declared net is one connected net, and no two declared nets are connected"],
    ["term-defined", "Every label, relationship type and property is defined in the graph's vocabulary"],
    ["term-usage", "Names used as the vocabulary defines them: ends, carriers, value types, value sets, required properties"],
    ["junction-net", "Junction dots join one net"],
    ["wire-through-body", "No wire crosses a symbol body"],
    ["text-clear", "Text stays off the wires"],
    ["part-overlap", "No two symbols overlap"],
    ["mate-direct", "Mated connectors sit face to face"],
  ];

  // How far conductors on one terminal may run together from it before parting (a pin's lead).
  const TERMINAL_LEAD = 100;
  const near = (a, b, eps = EPS) => Math.abs(a[0] - b[0]) <= eps && Math.abs(a[1] - b[1]) <= eps;
  const numeric = (v) => (v === undefined || v === null || v === "" || isNaN(+v) ? null : +v);
  const label = (sym, c) => `${sym.ref || sym.name} · ${c.name}`;

  /** Distance from point p to segment ab, and whether the foot lies strictly inside it. */
  function toSegment(p, a, b) {
    const dx = b[0] - a[0], dy = b[1] - a[1];
    const L2 = dx * dx + dy * dy;
    if (!L2) return { d: Math.hypot(p[0] - a[0], p[1] - a[1]), inside: false };
    const t = ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / L2;
    const u = Math.max(0, Math.min(1, t));
    const q = [a[0] + u * dx, a[1] + u * dy];
    const len = Math.sqrt(L2);
    return { d: Math.hypot(p[0] - q[0], p[1] - q[1]), inside: t * len > EPS && (1 - t) * len > EPS };
  }

  /** Length over which two axis-aligned segments lie on the same line. */
  function sharedRun(a1, a2, b1, b2) {
    const horiz = (p, q) => Math.abs(p[1] - q[1]) <= EPS && Math.abs(p[0] - q[0]) > EPS;
    const vert = (p, q) => Math.abs(p[0] - q[0]) <= EPS && Math.abs(p[1] - q[1]) > EPS;
    if (horiz(a1, a2) && horiz(b1, b2) && Math.abs(a1[1] - b1[1]) <= EPS) {
      const lo = Math.max(Math.min(a1[0], a2[0]), Math.min(b1[0], b2[0]));
      const hi = Math.min(Math.max(a1[0], a2[0]), Math.max(b1[0], b2[0]));
      return hi - lo > EPS ? { len: hi - lo, at: [(lo + hi) / 2, a1[1]] } : null;
    }
    if (vert(a1, a2) && vert(b1, b2) && Math.abs(a1[0] - b1[0]) <= EPS) {
      const lo = Math.max(Math.min(a1[1], a2[1]), Math.min(b1[1], b2[1]));
      const hi = Math.min(Math.max(a1[1], a2[1]), Math.max(b1[1], b2[1]));
      return hi - lo > EPS ? { len: hi - lo, at: [a1[0], (lo + hi) / 2] } : null;
    }
    return null;
  }

  /**
   * Items indexed by their boxes [x1, y1, x2, y2]. The returned query lists, in item order and
   * each once, the items whose box meets a given box: a check that can only fire between nearby
   * things reads those, and finds exactly what a scan of every item finds.
   */
  function boxIndex(items, boxOf, cell = 400) {
    const boxes = items.map(boxOf);
    const cells = new Map();
    const key = (gx, gy) => gx * 1048576 + gy;
    boxes.forEach((b, i) => {
      for (let gx = Math.floor(b[0] / cell); gx <= Math.floor(b[2] / cell); gx++) for (let gy = Math.floor(b[1] / cell); gy <= Math.floor(b[3] / cell); gy++) {
        const k = key(gx, gy), c = cells.get(k);
        if (c) c.push(i); else cells.set(k, [i]);
      }
    });
    const seen = new Int32Array(items.length);
    let stamp = 0;
    return (x1, y1, x2, y2) => {
      const mark = ++stamp, out = [];
      for (let gx = Math.floor(x1 / cell); gx <= Math.floor(x2 / cell); gx++) for (let gy = Math.floor(y1 / cell); gy <= Math.floor(y2 / cell); gy++) {
        for (const i of cells.get(key(gx, gy)) || []) {
          if (seen[i] === mark) continue;
          seen[i] = mark;
          const b = boxes[i];
          if (b[0] <= x2 && x1 <= b[2] && b[1] <= y2 && y1 <= b[3]) out.push(i);
        }
      }
      return out.sort((a, b) => a - b);
    };
  }
  const segBox = (sg, pad = 0) => [Math.min(sg.a[0], sg.b[0]) - pad, Math.min(sg.a[1], sg.b[1]) - pad, Math.max(sg.a[0], sg.b[0]) + pad, Math.max(sg.a[1], sg.b[1]) + pad];
  const rectBox = (r, pad = 0) => [r.x - pad, r.y - pad, r.x + r.w + pad, r.y + r.h + pad];

  /** Does segment ab pass through the open interior of rectangle r? */
  function crossesRect(a, b, r) {
    const x1 = r.x + EPS, y1 = r.y + EPS, x2 = r.x + r.w - EPS, y2 = r.y + r.h - EPS;
    if (x2 <= x1 || y2 <= y1) return false;
    // Liang-Barsky clip of the segment against the shrunken rectangle.
    let t0 = 0, t1 = 1;
    const dx = b[0] - a[0], dy = b[1] - a[1];
    for (const [p, q] of [[-dx, a[0] - x1], [dx, x2 - a[0]], [-dy, a[1] - y1], [dy, y2 - a[1]]]) {
      if (p === 0) { if (q < 0) return false; continue; }
      const t = q / p;
      if (p < 0) { if (t > t1) return false; if (t > t0) t0 = t; }
      else { if (t < t0) return false; if (t < t1) t1 = t; }
    }
    return t1 - t0 > 1e-6;
  }

  function run(scene, layout, options = {}) {
    const opts = { physical: !!layout.physical, ...options };
    const findings = [];
    const add = (check, level, message, at = null, refs = {}) => findings.push({ check, level, message, at, refs });

    // ---- placed pins in drawing coordinates ------------------------------------------------------
    const placed = new Map(); // contact -> [{ sym, pin, tip, face }]
    const pinsBySym = new Map();
    for (const [sid, s] of layout.symbols) {
      const abs = (pt) => (pt ? [s.x + pt[0], s.y + pt[1]] : null);
      const list = [];
      for (const pin of s.geo.pins) {
        if (!pin.contact) continue;
        const rec = { sym: s.sym, sid, pin, side: pin.side, tip: abs(pin.tip), face: abs(pin.face), contact: pin.contact };
        list.push(rec);
        if (!placed.has(pin.contact)) placed.set(pin.contact, []);
        placed.get(pin.contact).push(rec);
      }
      pinsBySym.set(sid, list);
    }

    // ---- pin-once -------------------------------------------------------------------------------------
    for (const s of scene.symbols.values()) {
      if (!layout.symbols.has(s.id)) continue;
      for (const c of s.contacts.values()) {
        if (!c.visible || c.logical) continue;
        const recs = placed.get(c) || [];
        if (recs.length === 0 && !(s.kind === "lib" && !c.libPin)) add("pin-once", "error", `${label(s, c)} is in the graph but not drawn.`, null, { sym: s.id, contact: c.key });
        if (recs.length > 1) add("pin-once", "error", `${label(s, c)} is drawn ${recs.length} times.`, recs[0].tip, { sym: s.id, contact: c.key });
        for (const r of recs) if (r.sid !== c.symbolId) add("pin-once", "error", `${label(s, c)} is drawn on ${r.sym.name}.`, r.tip, { sym: s.id, contact: c.key });
      }
    }

    // ---- pin-number -----------------------------------------------------------------------------------
    for (const [sid, list] of pinsBySym) {
      const s = layout.symbols.get(sid);
      for (const r of list) {
        const c = r.contact;
        if (s.geo.kind === "lib" && c.number && r.pin.lib && String(r.pin.lib.number) !== String(c.number)) {
          add("pin-number", "error", `${label(s.sym, c)} is graph position ${c.number} but sits on library pin ${r.pin.lib.number}.`, r.tip, { sym: sid, contact: c.key });
        }
      }
    }

    // ---- connector-order ------------------------------------------------------------------------------
    // A connector's positions, drawn: one edge, one unbroken run, ascending (KiCad draws pin 1 first).
    const along = (r) => (r.side === "WEST" || r.side === "EAST" ? r.tip[1] : r.tip[0]);
    const posOf = (c) => numeric(c.number) ?? numeric(c.order);
    const sections = new Map();
    for (const [sid, list] of pinsBySym) {
      const s = layout.symbols.get(sid);
      for (const r of list) {
        // Only connectors have positions in a row; a resistor's two ends belong on opposite sides.
        if (s.geo.kind === "lib" && s.sym.role !== "connector") continue;
        if (s.geo.kind === "box" && !r.contact.section) continue;
        // A multi-row header numbers each row on its own, so each physical row is one run.
        const row = s.geo.kind === "box" && r.contact.sideHint ? `|${r.contact.sideHint}` : "";
        const key = s.geo.kind === "lib" ? `${sid}|lib` : `${sid}|${r.contact.section.key}${row}`;
        const rowName = row ? ` (${r.contact.sideHint.toLowerCase()} row)` : "";
        if (!sections.has(key)) sections.set(key, { sid, sym: s.sym, kind: s.geo.kind, name: s.geo.kind === "lib" ? s.sym.name : r.contact.section.name + rowName, recs: [] });
        sections.get(key).recs.push(r);
      }
    }
    for (const sec of sections.values()) {
      const recs = sec.recs.filter((r) => posOf(r.contact) !== null);
      if (recs.length < 2) continue;
      const sides = new Set(recs.map((r) => r.side));
      if (sides.size > 1) { add("connector-order", "error", `${sec.name}: positions are split across ${[...sides].map((x) => x.toLowerCase()).join(" and ")} edges.`, recs[0].tip, { sym: sec.sid }); continue; }
      const byAlong = recs.slice().sort((a, b) => along(a) - along(b));
      const seq = byAlong.map((r) => posOf(r.contact));
      const asc = seq.every((v, i) => !i || v > seq[i - 1]);
      const desc = seq.every((v, i) => !i || v < seq[i - 1]);
      // Number order is a physical-layout promise; the logical layout orders a box connector's
      // pins by what they carry (see pair-adjacent), and only keeps them together on one edge,
      // unless it mates with a library connector symbol, whose pins keep their numbered order.
      const matesLib = sec.recs.some((r) => layout.connections.some((q) => {
        if (q.style !== "mate" || !q.b || (q.a !== r.contact && q.b !== r.contact)) return false;
        const other = q.a === r.contact ? q.b : q.a;
        return layout.symbols.get(other.symbolId)?.geo.kind === "lib";
      }));
      const numberOrder = opts.physical || sec.kind === "lib" || matesLib;
      // Library symbols may be rotated or mirrored, which legitimately reverses the run.
      if (numberOrder && !(asc || (sec.kind === "lib" && desc))) add("connector-order", "error", `${sec.name}: positions run ${seq.join(", ")} along the edge.`, byAlong[0].tip, { sym: sec.sid });
      else if (numberOrder && sec.kind === "box" && !asc) add("connector-order", "error", `${sec.name}: positions run backwards (${seq.join(", ")}).`, byAlong[0].tip, { sym: sec.sid });
      // Contiguity: no pin of another connector between the first and last position.
      const lo = along(byAlong[0]), hi = along(byAlong[byAlong.length - 1]);
      const side = byAlong[0].side;
      // In the physical layout a pin recorded between two positions of another connector belongs there.
      const recordedBetween = (r) => opts.physical && r.contact.pos && sec.recs.every((x) => x.contact.pos);
      const intruders = (pinsBySym.get(sec.sid) || []).filter((r) => r.side === side && !sec.recs.includes(r) && along(r) > lo + EPS && along(r) < hi - EPS && !recordedBetween(r));
      if (intruders.length) add("connector-order", "error", `${sec.name}: ${intruders.map((r) => r.contact.name).join(", ")} sit between its positions.`, intruders[0].tip, { sym: sec.sid });
    }

    // ---- pair-adjacent --------------------------------------------------------------------------------
    // In the logical layout the two members of a pair on one connector (the CAN_H and CAN_L pins
    // of one bus, or the two conductors of one twisted pair) stand next to each other.
    if (!opts.physical) {
      const groupsOf = (c) => {
        const out = [];
        for (const b of (c.net && c.net.buses) || []) out.push(`bus|${b.bus.id}`);
        for (const q of layout.connections) if (q.style !== "mate" && (q.a === c || q.b === c) && q.group && q.groupRole) out.push(`grp|${q.group}`);
        return out;
      };
      for (const sec of sections.values()) {
        if (sec.kind !== "box") continue;
        const bySide = new Map();
        for (const r of sec.recs) { if (!bySide.has(r.side)) bySide.set(r.side, []); bySide.get(r.side).push(r); }
        for (const list of bySide.values()) {
          list.sort((a, b) => along(a) - along(b));
          const keys = list.map((r) => groupsOf(r.contact));
          const seen = new Set();
          for (const k of new Set(keys.flat())) {
            if (seen.has(k)) continue; seen.add(k);
            const idx = keys.map((ks, i) => (ks.includes(k) ? i : -1)).filter((i) => i >= 0);
            if (idx.length < 2) continue;
            if (idx[idx.length - 1] - idx[0] !== idx.length - 1) add("pair-adjacent", "warning", `${sec.name}: ${idx.map((i) => list[i].contact.name).join(", ")} belong together but are drawn apart.`, list[idx[0]].tip, { sym: sec.sid });
          }
        }
      }
    }

    // ---- mate-order -----------------------------------------------------------------------------------
    const mates = layout.connections.filter((c) => c.style === "mate" && c.b);
    const pairs = new Map();
    for (const m of mates) {
      const ka = `${m.a.symbolId}|${m.a.section?.key || ""}`, kb = `${m.b.symbolId}|${m.b.section?.key || ""}`;
      const key = ka < kb ? `${ka}~${kb}` : `${kb}~${ka}`;
      if (!pairs.has(key)) pairs.set(key, []);
      pairs.get(key).push(ka < kb ? [m.a, m.b] : [m.b, m.a]);
    }
    for (const list of pairs.values()) {
      if (list.length < 2) continue;
      const pos = (c) => { const r = (placed.get(c) || [])[0]; return r ? along(r) : null; };
      const rows = list.map(([a, b]) => [pos(a), pos(b), a, b]).filter((x) => x[0] !== null && x[1] !== null).sort((x, y) => x[0] - y[0]);
      const seq = rows.map((x) => x[1]);
      const mono = seq.every((v, i) => !i || v >= seq[i - 1]) || seq.every((v, i) => !i || v <= seq[i - 1]);
      if (!mono) {
        const [ , , a, b] = rows[0];
        const sa = scene.symbols.get(a.symbolId), sb = scene.symbols.get(b.symbolId);
        add("mate-order", "error", `${a.section?.name || sa.name} and ${b.section?.name || sb.name}: mated positions are drawn in different orders, so their mates cross (${rows.map((x) => `${x[2].name}↔${x[3].name}`).join(", ")}).`, (placed.get(a) || [])[0]?.tip || null, { sym: a.symbolId });
      }
    }

    // ---- connector-symbol -----------------------------------------------------------------------------
    for (const s of scene.symbols.values()) {
      if (!layout.symbols.has(s.id) || s.kind !== "lib" || s.role !== "connector") continue;
      const props = s.node.props;
      const gender = String(props.user_gender ?? props.gender ?? "").toLowerCase();
      const id = s.libId || "";
      if (/\bfemale\b|socket|receptacle/.test(gender) && !/_Female|_Socket/.test(id)) add("connector-symbol", "error", `${s.name} is ${gender} but drawn with ${id}.`, null, { sym: s.id });
      if (/\bmale\b|\bplug\b|header/.test(gender) && !/female/.test(gender) && !/_Male|_Pin\b|_Pin$/.test(id)) add("connector-symbol", "warning", `${s.name} is ${gender} but drawn with ${id}.`, null, { sym: s.id });
      const populated = Array.isArray(props.populated_positions) ? props.populated_positions.length : null;
      const positions = populated ?? numeric(props.positions);
      const m = /01x(\d+)/.exec(id);
      if (positions && m && +m[1] !== positions) add("connector-symbol", "error", `${s.name} has ${positions} positions but is drawn as a 1x${+m[1]} connector.`, null, { sym: s.id });
    }

    // ---- connector-shown ------------------------------------------------------------------------------
    for (const [sid, s] of layout.symbols) {
      if (s.geo.kind !== "box") continue;
      const named = [...new Set(s.geo.pins.map((p) => p.contact.section?.node ? p.contact.section.key : null).filter(Boolean))];
      if (named.length < 2) continue;
      const captions = new Set((s.geo.captions || []).map((c) => c.text));
      for (const key of named) {
        const c = s.geo.pins.find((p) => p.contact.section?.key === key).contact;
        // Named by a title, or by pin names that carry the connector's own words ("CANL screw terminal").
        const own = String(c.section.name).toLowerCase().split(/\s+/).filter((w) => w.length > 2 && !String(s.sym.name).toLowerCase().includes(w));
        const pinsOf = s.geo.pins.filter((p) => p.contact.section?.key === key);
        const shown = [...captions].some((t) => c.section.name.includes(t) || t.includes(c.section.name))
          || (own.length && pinsOf.every((p) => own.some((w) => p.contact.name.toLowerCase().includes(w.replace(/s$/, "")))));
        if (!shown) add("connector-shown", "warning", `${s.sym.name}: ${c.section.name} is not named on the part.`, null, { sym: sid });
      }
    }

    // ---- pin-in-connector -----------------------------------------------------------------------------
    // Read from the graph, drawn or not: a gap here is a gap in the model, reported so it can be filled.
    // Only a graph that models connectors at all makes this claim; a chip-level design does not.
    const connectorLabels = new Set(scene.profile?.structure?.connectorLabels || []);
    const modelsConnectors = [...(scene.graph?.nodes?.values() || [])].some((n) => n.labels.some((l) => connectorLabels.has(l)));
    if (modelsConnectors) for (const s of scene.symbols.values()) for (const c of s.contacts.values()) {
      if (!c.pin || c.logical || c.lead || c.section?.node) continue;
      add("pin-in-connector", "warning", `${label(s, c)} is not part of any connector in the graph, and is not marked as a lead.`, (placed.get(c) || [])[0]?.tip || null, { sym: s.id, contact: c.key });
    }

    // ---- connector-whole ------------------------------------------------------------------------------
    for (const [sid, list] of pinsBySym) {
      const s = layout.symbols.get(sid);
      if (s.geo.kind !== "box") continue;
      const groups = new Map();
      for (const r of list) {
        const c = r.contact;
        if (!c.section?.node || posOf(c) !== null) continue;
        const k = `${c.section.key}|${c.sideHint || ""}`;
        if (!groups.has(k)) groups.set(k, []);
        groups.get(k).push(r);
      }
      for (const rs of groups.values()) {
        if (rs.length < 2) continue;
        const name = rs[0].contact.section.name;
        const sides = new Set(rs.map((r) => r.side));
        if (sides.size > 1) { if (!(opts.physical && rs.some((r) => r.contact.sideHint))) add("connector-whole", "error", `${name}: its pins are split across ${[...sides].map((x) => x.toLowerCase()).join(" and ")} edges.`, rs[0].tip, { sym: sid }); continue; }
        const vals = rs.map(along).sort((a, b) => a - b);
        const others = list.filter((r) => r.side === rs[0].side && !rs.includes(r) && along(r) > vals[0] + EPS && along(r) < vals[vals.length - 1] - EPS && !(opts.physical && r.contact.pos));
        if (others.length) add("connector-whole", "error", `${name}: ${others.map((r) => r.contact.name).join(", ")} sit among its pins.`, others[0].tip, { sym: sid });
      }
    }

    // ---- term-defined, term-usage: the graph uses its own vocabulary as it defines it --------------
    // Runs over the whole graph, every configuration and the metadata nodes included, whenever the
    // graph embeds a vocabulary. Repeated findings are counted once per name.
    const M = scene.model;
    if (M && M.scheme && scene.sourceGraph) {
      const G = scene.sourceGraph;
      const { labels: labelT, rels: relT, props: propT, valueSets: setT } = M.terms;
      const agg = new Map();
      const note = (check, key, message, line) => {
        if (!agg.has(key)) agg.set(key, { check, message, count: 0, line });
        agg.get(key).count++;
      };
      const permitted = new Map();
      for (const [name, t] of setT) permitted.set(name, new Set((t.values || []).map((v) => String(v).split(":")[0].trim())));
      const setOf = (t) => (/value set (\S+)/.exec(t.value_type || "") || [])[1];
      const required = new Map(); // carrier -> required property names
      for (const [name, t] of propT) for (const c of Array.isArray(t.required) ? t.required : t.required ? t.applies_to || [] : []) {
        if (!required.has(c)) required.set(c, []);
        required.get(c).push(name);
      }
      const typeOk = (t, v) => {
        const vt = String(t.value_type || "").replace(/^list of /, "");
        const list = /^list of /.test(t.value_type || "");
        if (list !== Array.isArray(v)) return false;
        const vals = Array.isArray(v) ? v : [v];
        if (vt === "integer") return vals.every((x) => Number.isInteger(x));
        if (vt === "number") return vals.every((x) => typeof x === "number");
        if (vt === "boolean") return vals.every((x) => typeof x === "boolean");
        if (vt === "text" || vt === "IRI" || vt === "date") return vals.every((x) => typeof x === "string");
        return true;
      };
      const checkProps = (el, carrier, what) => {
        for (const [k, v] of Object.entries(el.props)) {
          const t = propT.get(k);
          if (!t) { note("term-defined", `p|${k}`, `Property ${k} is not defined in the vocabulary`, el.lines?.[0]); continue; }
          if (t.applies_to && !t.applies_to.includes(carrier)) note("term-usage", `pa|${k}|${carrier}`, `Property ${k} is not defined for ${carrier}`, el.lines?.[0]);
          if (!typeOk(t, v)) note("term-usage", `pt|${k}|${carrier}`, `Property ${k} on ${carrier} should be ${t.value_type}`, el.lines?.[0]);
          if (t.value_pattern && typeof v === "string" && !new RegExp(t.value_pattern).test(v)) note("term-usage", `pp|${k}|${v}`, `${k} value ${v} does not match ${t.value_pattern}`, el.lines?.[0]);
          for (const x of Array.isArray(v) ? v : [v]) {
            if (typeof x === "number" && ((t.value_minimum !== undefined && x < t.value_minimum) || (t.value_maximum !== undefined && x > t.value_maximum))) note("term-usage", `pm|${k}|${x}`, `${k} value ${x} is outside ${t.value_minimum ?? "…"} to ${t.value_maximum ?? "…"}`, el.lines?.[0]);
          }
          const set = setOf(t);
          if (set && permitted.has(set)) for (const x of Array.isArray(v) ? v : [v]) {
            if (!permitted.get(set).has(String(x))) note("term-usage", `pv|${k}|${x}`, `${k} value ${x} is not in the value set ${set}`, el.lines?.[0]);
          }
        }
        for (const k of required.get(carrier) || []) if (el.props[k] === undefined) note("term-usage", `pr|${k}|${carrier}`, `${what} is missing required property ${k}`, el.lines?.[0]);
      };
      for (const n of G.nodes.values()) {
        const known = n.labels.filter((l) => labelT.has(l));
        for (const l of n.labels) if (!labelT.has(l)) note("term-defined", `l|${l}`, `Label ${l} is not defined in the vocabulary`, n.lines?.[0]);
        checkProps(n, known[0] || n.labels[0], `A ${known[0] || n.labels[0]} node`);
      }
      for (const r of G.rels.values()) {
        const t = relT.get(r.type);
        if (!t) { note("term-defined", `r|${r.type}`, `Relationship type ${r.type} is not defined in the vocabulary`, r.lines?.[0]); continue; }
        const a = G.nodes.get(r.start), b = G.nodes.get(r.end);
        if (t.from_labels && !a.labels.some((l) => t.from_labels.includes(l))) note("term-usage", `rf|${r.type}|${a.labels.join(":")}`, `${r.type} may start from ${t.from_labels.join(" or ")}, not ${a.labels.join(":")}`, r.lines?.[0]);
        if (t.to_labels && !b.labels.some((l) => t.to_labels.includes(l))) note("term-usage", `rt|${r.type}|${b.labels.join(":")}`, `${r.type} may point to ${t.to_labels.join(" or ")}, not ${b.labels.join(":")}`, r.lines?.[0]);
        checkProps(r, r.type, `A ${r.type} relationship`);
      }
      for (const f of agg.values()) add(f.check, "error", `${f.message}${f.count > 1 ? ` (${f.count} times)` : ""}${f.line ? `; first on line ${f.line}` : ""}.`, null, {});
    }

    // ---- net-declared: the named nets agree with what the conductors actually connect ------------
    for (const d of scene.declaredNets || []) {
      // A sheet draws part of a net; the rest is on other sheets, so pieces apart are expected there.
      // In a configuration that leaves out some of its conductors, a net may be in pieces.
      if (d.nets.length > 1 && !scene.partial) {
        if (d.reduced) add("net-declared", "warning", `Net ${d.name} is in ${d.nets.length} pieces in this configuration; conductors of other configurations join them.`, null, {});
        else add("net-declared", "error", `Net ${d.name} is declared as one net, but its conductors form ${d.nets.length} separate nets.`, null, {});
      }
    }
    for (const net of scene.nets.values()) {
      const names = [...new Set((net.declared || []).map((n) => n.props.name ?? n.id))];
      if (names.length > 1) add("net-declared", "error", `Nets ${names.join(" and ")} are declared separately, but the conductors connect them.`, null, {});
    }

    // ---- geometry sanity: every placed part has a finite position and size ----------------------------
    for (const [sid, sv] of layout.symbols) {
      if ([sv.x, sv.y, sv.w, sv.h].every(Number.isFinite)) continue;
      add("part-overlap", "error", `${sv.sym.name} has no finite position or size, so it cannot be drawn or checked.`, null, { sym: sid });
    }

    // ---- location-claim -------------------------------------------------------------------------------
    if (opts.physical) {
      for (const [sid, list] of pinsBySym) {
        const s = layout.symbols.get(sid);
        // A junction (splice) has no pin layout to claim: its joints are drawn in routing order.
        if (s.geo.kind !== "box" || s.geo.junction) continue;
        for (const r of list) {
          const c = r.contact;
          const located = c.pos || (c.sideHint && numeric(c.order) !== null);
          if (!located && !c.synthetic && !r.pin.unplaced) add("location-claim", "error", `${label(s.sym, c)} is drawn in the physical layout as if its position were known; the graph does not record it.`, r.tip, { sym: sid, contact: c.key });
        }
      }
    }

    // ---- physical-order -------------------------------------------------------------------------------
    if (opts.physical) {
      for (const [sid, list] of pinsBySym) {
        const s = layout.symbols.get(sid);
        if (s.geo.kind !== "box") continue;
        const yUp = s.sym.outline ? s.sym.outline.yUp : true;
        const rows = list.filter((r) => r.contact.pos && (r.side === "WEST" || r.side === "EAST"));
        let reported = false;
        for (let i = 0; i < rows.length && !reported; i++) for (let j = 0; j < rows.length && !reported; j++) {
          const A = rows[i], B = rows[j];
          const higher = (yUp ? A.contact.pos.y - B.contact.pos.y : B.contact.pos.y - A.contact.pos.y);
          // A clearly higher on the part (a full pitch) must not be drawn lower.
          if (higher >= 2.54 && A.tip[1] > B.tip[1] + EPS) {
            add("physical-order", "error", `${s.sym.name}: ${A.contact.name} sits ${higher.toFixed(2)} mm above ${B.contact.name} on the part but is drawn below it.`, A.tip, { sym: sid });
            reported = true;
          }
        }
      }
    }

    // ---- pin-number-unique ----------------------------------------------------------------------------
    for (const [sid, list] of pinsBySym) {
      const s = layout.symbols.get(sid);
      const seen = new Map();
      for (const r of list) {
        const n = r.contact.number;
        if (!n) continue;
        if (!seen.has(String(n))) seen.set(String(n), []);
        seen.get(String(n)).push(r);
      }
      for (const [n, rs] of seen) if (rs.length > 1) add("pin-number-unique", "warning", `${s.sym.name}: number ${n} is shown on ${rs.map((r) => r.contact.name).join(", ")}; the graph numbers each connector separately.`, rs[0].tip, { sym: sid });
    }

    // ---- pin-grid -------------------------------------------------------------------------------------
    for (const [sid, list] of pinsBySym) {
      const s = layout.symbols.get(sid);
      const bySide = new Map();
      for (const r of list) { if (!bySide.has(r.side)) bySide.set(r.side, []); bySide.get(r.side).push(r); }
      for (const [side, rs] of bySide) {
        const vals = rs.map(along).sort((a, b) => a - b);
        for (let i = 1; i < vals.length; i++) {
          const gap = vals[i] - vals[i - 1];
          if (Math.abs(gap / GRID - Math.round(gap / GRID)) * GRID > EPS) {
            add("pin-grid", "warning", `${s.sym.name}: ${side.toLowerCase()} pins are ${gap.toFixed(1)} mil apart, off the ${GRID} mil grid.`, rs[i]?.tip || null, { sym: sid });
            break;
          }
        }
      }
    }

    // ---- wires ----------------------------------------------------------------------------------------
    const entryRuns = new Map();
    for (const b of layout.bundles || []) for (const end of b.ends) for (const en of end.entries) {
      if (!entryRuns.has(en.conn.id)) entryRuns.set(en.conn.id, []);
      entryRuns.get(en.conn.id).push(en.pts);
    }
    const segs = []; // { a, b, net, conn }
    const attachPoint = (c, contact) => {
      const r = (placed.get(contact) || [])[0];
      if (!r) return null;
      const face = c.attach === "face" && r.pin.face && layout.symbols.get(r.sid).geo.kind === "lib";
      return face ? r.face : r.tip;
    };
    for (const c of layout.connections) {
      const e = layout.edges.get(c.id);
      if (!e || !e.sections.length) continue;
      const netKey = c.net?.key || c.id;
      const runs = e.bus ? entryRuns.get(c.id) || [] : e.sections;
      for (const sec of runs) for (let i = 1; i < sec.length; i++) segs.push({ a: sec[i - 1], b: sec[i], net: netKey, conn: c });
      // Endpoints: the route must start and end on this connection's own attach points.
      const full = e.sections.flat();
      const ends = [full[0], full[full.length - 1]];
      const want = [attachPoint(c, c.a), c.port ? null : attachPoint(c, c.b)].filter(Boolean);
      for (const w of want) {
        if (!ends.some((p) => near(p, w))) {
          const who = w === want[0] ? c.a : c.b;
          add("wire-endpoint", "error", `${c.type} ${c.props?.id || ""}: the line stops short of ${label(scene.symbols.get(who.symbolId), who)}.`, w, { conn: c.id });
        }
      }
    }

    // wire-orthogonal: a slanted run is a routing fault (bus entries are 45 degrees by design).
    const slanted = new Set();
    for (const sg of segs) {
      const dx = Math.abs(sg.a[0] - sg.b[0]), dy = Math.abs(sg.a[1] - sg.b[1]);
      if (dx <= EPS || dy <= EPS || (sg.conn.bundle && Math.abs(dx - dy) <= EPS)) continue;
      if (slanted.has(sg.conn.id)) continue;
      slanted.add(sg.conn.id);
      add("wire-orthogonal", "error", `A ${sg.conn.type} wire on net ${sg.conn.net?.name || "?"} runs at a slant.`, [(sg.a[0] + sg.b[0]) / 2, (sg.a[1] + sg.b[1]) / 2], { conn: sg.conn.id });
    }

    // false-connection: a line over a connection point of another net.
    const points = [];
    for (const recs of placed.values()) for (const r of recs) if (r.contact.visible && r.contact.net) points.push({ p: r.tip, net: r.contact.net.key, netName: r.contact.net.name, what: label(r.sym, r.contact) });
    const segsNear = boxIndex(segs, (sg) => segBox(sg));
    const pointsNear = boxIndex(points, (pt) => [pt.p[0], pt.p[1], pt.p[0], pt.p[1]]);
    for (const sg of segs) {
      for (const pi of pointsNear(...segBox(sg, EPS))) {
        const pt = points[pi];
        if (pt.net === sg.net) continue;
        const t = toSegment(pt.p, sg.a, sg.b);
        if (t.d <= EPS && t.inside) add("false-connection", "error", `A ${sg.conn.type} wire on net ${sg.conn.net?.name || "?"} runs across ${pt.what} (net ${pt.netName}).`, pt.p, { conn: sg.conn.id });
        else if (t.d <= EPS && (near(pt.p, sg.a) || near(pt.p, sg.b))) add("false-connection", "error", `A ${sg.conn.type} wire on net ${sg.conn.net?.name || "?"} ends on ${pt.what} (net ${pt.netName}).`, pt.p, { conn: sg.conn.id });
      }
    }

    // The pair checks below fire only between runs within GAP (400 mil) of each other; each reads
    // the later runs within reach of each run, in order, as a scan of every pair would.
    const REACH = 402;
    const later = segs.map((sg, i) => segsNear(...segBox(sg, REACH)).filter((j) => j > i));

    // net-overlap: two nets drawn on the same stretch of line read as one conductor.
    const seen = new Set();
    for (let i = 0; i < segs.length; i++) for (const j of later[i]) {
      const A = segs[i], B = segs[j];
      if (A.net === B.net) continue;
      const s = sharedRun(A.a, A.b, B.a, B.b);
      if (!s || s.len < 20) continue;
      const k = [A.conn.id, B.conn.id].sort().join("~");
      if (seen.has(k)) continue;
      seen.add(k);
      add("net-overlap", "error", `Nets ${A.conn.net?.name || "?"} and ${B.conn.net?.name || "?"} share ${Math.round(s.len)} mil of line.`, s.at, { conn: A.conn.id });
    }

    // cable runs: a bus or twisted pair must not lie on, or crowd, any other wire or cable run.
    const cableSegs = [];
    for (const b of layout.bundles || []) for (const run of [b.path, ...b.ends.map((en) => en.spine)]) {
      for (let i = 1; i < run.length; i++) cableSegs.push({ a: run[i - 1], b: run[i], bundle: b.bundle });
    }
    const cableSeen = new Set();
    const cableCheck = (A, B, what) => {
      const vA = Math.abs(A.a[0] - A.b[0]) <= EPS, vB = Math.abs(B.a[0] - B.b[0]) <= EPS;
      const hA = Math.abs(A.a[1] - A.b[1]) <= EPS, hB = Math.abs(B.a[1] - B.b[1]) <= EPS;
      let d = null, run = 0, at = null;
      if (vA && vB) {
        d = Math.abs(A.a[0] - B.a[0]);
        const lo = Math.max(Math.min(A.a[1], A.b[1]), Math.min(B.a[1], B.b[1])), hi = Math.min(Math.max(A.a[1], A.b[1]), Math.max(B.a[1], B.b[1]));
        run = hi - lo; at = [A.a[0], (lo + hi) / 2];
      } else if (hA && hB) {
        d = Math.abs(A.a[1] - B.a[1]);
        const lo = Math.max(Math.min(A.a[0], A.b[0]), Math.min(B.a[0], B.b[0])), hi = Math.min(Math.max(A.a[0], A.b[0]), Math.max(B.a[0], B.b[0]));
        run = hi - lo; at = [(lo + hi) / 2, A.a[1]];
      }
      if (d === null || run < 20 || d >= 40) return;
      const k = `${A.bundle.id}~${what}`;
      if (cableSeen.has(k)) return;
      cableSeen.add(k);
      add(d <= EPS ? "net-overlap" : "side-by-side", "error", `${A.bundle.name} runs ${d <= EPS ? "on" : `${Math.round(d)} mil from`} ${what} for ${Math.round(run)} mil.`, at, { bundle: A.bundle.id });
    };
    const cablesNear = boxIndex(cableSegs, (sg) => segBox(sg));
    for (const A of cableSegs) {
      for (const j of segsNear(...segBox(A, 41))) { const B = segs[j]; if (!(A.bundle.connections || []).includes(B.conn)) cableCheck(A, B, `${B.conn.type} wire on net ${B.conn.net?.name || "?"}`); }
      for (const j of cablesNear(...segBox(A, 41))) { const B = cableSegs[j]; if (B.bundle !== A.bundle && A.bundle.id < B.bundle.id) cableCheck(A, B, `cable ${B.bundle.name} (${B.bundle.id})`); }
    }

    // no-splice: a junction away from every pin, or two conductors sharing a run, reads as a splice.
    const pinEnds = [];
    for (const recs of placed.values()) for (const r of recs) { pinEnds.push(r.tip); if (r.face) pinEnds.push(r.face); }
    const pinsNear = boxIndex(pinEnds, (q) => [q[0], q[1], q[0], q[1]]);
    const atPin = (p) => pinsNear(p[0] - EPS, p[1] - EPS, p[0] + EPS, p[1] + EPS).some((i) => near(p, pinEnds[i]));
    for (const c of layout.connections) {
      const e = layout.edges.get(c.id);
      // A connection through a named net node is the net itself, so its trunk may branch anywhere.
      if (c.netNode) continue;
      for (const j of e?.junctions || []) if (!atPin(j)) add("no-splice", "error", `Net ${c.net?.name || "?"} is drawn with a splice here, but the graph joins its conductors only at pins.`, j, { conn: c.id });
    }
    const conductor = (sg) => sg.conn.style !== "join" && sg.conn.style !== "interface" && !sg.conn.netNode;
    const splices = new Set();
    for (let i = 0; i < segs.length; i++) for (const j of later[i]) {
      const A = segs[i], B = segs[j];
      if (A.net !== B.net || A.conn === B.conn || !conductor(A) || !conductor(B)) continue;
      const sh = sharedRun(A.a, A.b, B.a, B.b);
      if (!sh || sh.len < 2) continue;
      const k = [A.conn.id, B.conn.id].sort().join("~");
      if (splices.has(k)) continue;
      splices.add(k);
      // Several conductors on one terminal (ring terminals on a ground stud) leave it along the
      // pin's one lead; parting within a short lead of it reads as the terminal they share.
      const tips = (c) => { const sec = layout.edges.get(c.id)?.sections || []; return sec.length ? [sec[0][0], sec[sec.length - 1][sec[sec.length - 1].length - 1]] : []; };
      const common = tips(A.conn).find((p) => tips(B.conn).some((q) => near(p, q)) && atPin(p));
      const onRun = common && [[A.a, A.b], [B.a, B.b]].every(([p, q]) => near(p, common) || near(q, common));
      if (onRun && sh.len <= TERMINAL_LEAD) {
        add("shared-terminal", "warning", `Two ${A.conn.type} conductors on net ${A.conn.net?.name || "?"} leave one terminal together for ${Math.round(sh.len)} mil before parting.`, sh.at, { conn: A.conn.id });
        continue;
      }
      add("no-splice", "error", `Two ${A.conn.type} conductors on net ${A.conn.net?.name || "?"} share ${Math.round(sh.len)} mil of line, so they read as one wire spliced.`, sh.at, { conn: A.conn.id });
    }

    // collinear-gap: two nets on one line with a small gap read as one continuous wire.
    const GAP = 400;
    const gapSeen = new Set();
    for (let i = 0; i < segs.length; i++) for (const j of later[i]) {
      const A = segs[i], B = segs[j];
      if (A.net === B.net) continue;
      // Short jogs at pin ends are not runs anyone would read on.
      const lenOf = (sg) => Math.hypot(sg.a[0] - sg.b[0], sg.a[1] - sg.b[1]);
      if (lenOf(A) < 200 || lenOf(B) < 200) continue;
      const vA = Math.abs(A.a[0] - A.b[0]) <= EPS, vB = Math.abs(B.a[0] - B.b[0]) <= EPS;
      const hA = Math.abs(A.a[1] - A.b[1]) <= EPS, hB = Math.abs(B.a[1] - B.b[1]) <= EPS;
      let gap = null, at = null;
      if (vA && vB && Math.abs(A.a[0] - B.a[0]) <= EPS) {
        const [a1, a2] = [Math.min(A.a[1], A.b[1]), Math.max(A.a[1], A.b[1])], [b1, b2] = [Math.min(B.a[1], B.b[1]), Math.max(B.a[1], B.b[1])];
        gap = a2 < b1 ? b1 - a2 : b2 < a1 ? a1 - b2 : null;
        at = [A.a[0], a2 < b1 ? (a2 + b1) / 2 : (b2 + a1) / 2];
      } else if (hA && hB && Math.abs(A.a[1] - B.a[1]) <= EPS) {
        const [a1, a2] = [Math.min(A.a[0], A.b[0]), Math.max(A.a[0], A.b[0])], [b1, b2] = [Math.min(B.a[0], B.b[0]), Math.max(B.a[0], B.b[0])];
        gap = a2 < b1 ? b1 - a2 : b2 < a1 ? a1 - b2 : null;
        at = [a2 < b1 ? (a2 + b1) / 2 : (b2 + a1) / 2, A.a[1]];
      }
      if (gap === null || gap > GAP) continue;
      // Wires meeting a part from both sides (a resistor in line) end on its pins; that is not a gap.
      const facing = (sg) => [sg.a, sg.b].filter((p) => Math.hypot(p[0] - at[0], p[1] - at[1]) <= gap / 2 + EPS);
      if ([...facing(A), ...facing(B)].some(atPin)) continue;
      const k = [A.conn.id, B.conn.id].sort().join("~");
      if (gapSeen.has(k)) continue;
      gapSeen.add(k);
      add("collinear-gap", "warning", `Nets ${A.conn.net?.name || "?"} and ${B.conn.net?.name || "?"} run on one line with a ${Math.round(gap)} mil gap, so they read as one wire.`, at, { conn: A.conn.id });
    }

    // side-by-side: parallel runs of two nets closer than a drawn wire is wide merge on screen.
    const SIDE = 40;
    const sideSeen = new Set();
    for (let i = 0; i < segs.length; i++) for (const j of later[i]) {
      const A = segs[i], B = segs[j];
      if (A.net === B.net) continue;
      const vA = Math.abs(A.a[0] - A.b[0]) <= EPS, vB = Math.abs(B.a[0] - B.b[0]) <= EPS;
      const hA = Math.abs(A.a[1] - A.b[1]) <= EPS, hB = Math.abs(B.a[1] - B.b[1]) <= EPS;
      let d = null, run = 0, at = null;
      if (vA && vB) {
        d = Math.abs(A.a[0] - B.a[0]);
        const lo = Math.max(Math.min(A.a[1], A.b[1]), Math.min(B.a[1], B.b[1])), hi = Math.min(Math.max(A.a[1], A.b[1]), Math.max(B.a[1], B.b[1]));
        run = hi - lo; at = [(A.a[0] + B.a[0]) / 2, (lo + hi) / 2];
      } else if (hA && hB) {
        d = Math.abs(A.a[1] - B.a[1]);
        const lo = Math.max(Math.min(A.a[0], A.b[0]), Math.min(B.a[0], B.b[0])), hi = Math.min(Math.max(A.a[0], A.b[0]), Math.max(B.a[0], B.b[0]));
        run = hi - lo; at = [(lo + hi) / 2, (A.a[1] + B.a[1]) / 2];
      }
      if (d === null || d <= EPS || d >= SIDE || run < 20) continue;
      const k = [A.conn.id, B.conn.id].sort().join("~");
      if (sideSeen.has(k)) continue;
      sideSeen.add(k);
      add("side-by-side", "error", `Nets ${A.conn.net?.name || "?"} and ${B.conn.net?.name || "?"} run ${Math.round(d)} mil apart for ${Math.round(run)} mil, closer than a wire is wide.`, at, { conn: A.conn.id });
    }

    // junction-net: a dot where another net's line also passes.
    for (const c of layout.connections) {
      const e = layout.edges.get(c.id);
      for (const j of e?.junctions || []) {
        const other = segsNear(j[0] - EPS, j[1] - EPS, j[0] + EPS, j[1] + EPS).map((i) => segs[i]).find((sg) => sg.net !== (c.net?.key || c.id) && toSegment(j, sg.a, sg.b).d <= EPS);
        if (other) add("junction-net", "error", `A junction on net ${c.net?.name || "?"} also touches net ${other.conn.net?.name || "?"}.`, j, { conn: c.id });
      }
    }

    // wire-through-body.
    const bodies = [];
    for (const [sid, s] of layout.symbols) {
      if (s.geo.kind === "box") bodies.push({ sid, name: s.sym.name, r: { x: s.x + s.geo.body.x, y: s.y + s.geo.body.y, w: s.geo.body.w, h: s.geo.body.h } });
      else {
        let x1 = Infinity, y1 = Infinity, x2 = -Infinity, y2 = -Infinity;
        for (const sh of s.geo.shapes) {
          const ptsList = sh.type === "poly" ? sh.pts : sh.type === "circle" ? [[sh.c[0] - sh.r, sh.c[1] - sh.r], [sh.c[0] + sh.r, sh.c[1] + sh.r]] : [];
          for (const [x, y] of ptsList) { x1 = Math.min(x1, x); x2 = Math.max(x2, x); y1 = Math.min(y1, y); y2 = Math.max(y2, y); }
        }
        // Where pins leave a side, the body ends at their inner ends: graphics reaching out past a
        // pin (a LED's emission arrows, say) sit beside that pin's wire, not across it.
        for (const p of s.geo.pins || []) {
          if (p.side === "WEST") x1 = Math.max(x1, p.base[0]);
          else if (p.side === "EAST") x2 = Math.min(x2, p.base[0]);
          else if (p.side === "NORTH") y1 = Math.max(y1, p.base[1]);
          else if (p.side === "SOUTH") y2 = Math.min(y2, p.base[1]);
        }
        if (x1 < x2 && y1 < y2) bodies.push({ sid, name: s.sym.name, r: { x: s.x + x1, y: s.y + y1, w: x2 - x1, h: y2 - y1 } });
      }
    }
    const reported = new Set();
    const bodiesNear = boxIndex(bodies, (b) => rectBox(b.r));
    for (const sg of segs) {
      for (const bi of bodiesNear(...segBox(sg))) {
        const b = bodies[bi];
        if (!crossesRect(sg.a, sg.b, b.r)) continue;
        // A face attachment ends on the body edge by design; that is not a crossing.
        const k = `${sg.conn.id}|${b.sid}`;
        if (reported.has(k)) continue;
        reported.add(k);
        add("wire-through-body", "error", `A ${sg.conn.type} wire on net ${sg.conn.net?.name || "?"} crosses ${b.name}.`, [(sg.a[0] + sg.b[0]) / 2, (sg.a[1] + sg.b[1]) / 2], { conn: sg.conn.id, sym: b.sid });
      }
    }
    for (const b of layout.bundles || []) {
      for (const run of [b.path]) for (let i = 1; i < run.length; i++) for (const body of bodies) {
        if (b.ends.some((en) => en.symId === body.sid) && !crossesRect(run[i - 1], run[i], body.r)) continue;
        if (crossesRect(run[i - 1], run[i], body.r)) add("wire-through-body", "error", `${b.bundle.name} crosses ${body.name}.`, run[i], { sym: body.sid });
      }
    }

    // text-clear: a wire drawn through a part's name, reference or pin caption hides it.
    const measure = opts.measure || ((t, size) => String(t).length * size * 0.6);
    const textBoxes = [];
    for (const [sid, s] of layout.symbols) {
      const g = s.geo;
      const boxOf = (text, x, y, anchor, size, baseline) => {
        const w = measure(text, size);
        const x1 = anchor === "middle" ? x - w / 2 : anchor === "end" ? x - w : x;
        const y1 = baseline === "central" ? y - size * 0.45 : y - size * 0.8;
        return { x: s.x + x1, y: s.y + y1, w, h: size * 0.9 };
      };
      if (g.ref?.text) textBoxes.push({ sid, what: `${s.sym.name} reference`, r: boxOf(g.ref.text, g.ref.x, g.ref.y, g.ref.anchor, 50) });
      (g.value?.lines || []).forEach((line, i) => textBoxes.push({ sid, what: `${s.sym.name} name`, r: boxOf(line, g.value.x, g.value.y + i * 66, g.value.anchor, 50) }));
      if (g.kind === "lib") for (const cap of g.captions || []) textBoxes.push({ sid, what: `${s.sym.name} caption "${cap.text}"`, r: boxOf(cap.text, cap.x, cap.y, cap.anchor, 40, cap.onWire ? "auto" : "central") });
    }
    const overlap = (a, b) => a.x < b.x + b.w - EPS && b.x < a.x + a.w - EPS && a.y < b.y + b.h - EPS && b.y < a.y + a.h - EPS;
    // Pin stubs count as part of a symbol's footprint on the sheet.
    const footprint = new Map(bodies.map((b) => [b.sid, b.r]));
    // Every drawn pin counts, including library pins with nothing in the graph (a coax shield).
    const allPins = [...layout.symbols].flatMap(([sid, sv]) => sv.geo.pins.map((pin) => ({ sid, pin, tip: [sv.x + pin.tip[0], sv.y + pin.tip[1]] })));
    for (const r of allPins) {
      const sid = r.sid, s = layout.symbols.get(sid), base = [s.x + r.pin.base[0], s.y + r.pin.base[1]];
      const f = footprint.get(sid);
      if (!f) continue;
      const x1 = Math.min(f.x, r.tip[0], base[0]), y1 = Math.min(f.y, r.tip[1], base[1]);
      const x2 = Math.max(f.x + f.w, r.tip[0], base[0]), y2 = Math.max(f.y + f.h, r.tip[1], base[1]);
      footprint.set(sid, { x: x1, y: y1, w: x2 - x1, h: y2 - y1 });
    }
    // part-overlap: bodies and pin stubs of two symbols sharing space.
    const ids = [...footprint.keys()];
    const footNear = boxIndex(ids, (sid) => rectBox(footprint.get(sid)));
    for (let i = 0; i < ids.length; i++) for (const j of footNear(...rectBox(footprint.get(ids[i]))).filter((k) => k > i)) {
      const A = footprint.get(ids[i]), B = footprint.get(ids[j]);
      const ox = Math.min(A.x + A.w, B.x + B.w) - Math.max(A.x, B.x), oy = Math.min(A.y + A.h, B.y + B.h) - Math.max(A.y, B.y);
      if (ox > EPS && oy > EPS) add("part-overlap", "error", `${layout.symbols.get(ids[i]).sym.name} and ${layout.symbols.get(ids[j]).sym.name} overlap.`, [Math.max(A.x, B.x) + ox / 2, Math.max(A.y, B.y) + oy / 2], { sym: ids[i] });
    }
    for (const tb of textBoxes) {
      const at = [tb.r.x + tb.r.w / 2, tb.r.y + tb.r.h / 2];
      const hit = segsNear(...rectBox(tb.r)).map((i) => segs[i]).find((sg) => crossesRect(sg.a, sg.b, tb.r));
      if (hit) add("text-clear", "warning", `The ${hit.conn.type} wire on net ${hit.conn.net?.name || "?"} runs through the ${tb.what}.`, at, { sym: tb.sid, conn: hit.conn.id });
      for (const k of footNear(...rectBox(tb.r))) {
        const sid = ids[k], f = footprint.get(sid);
        if (sid === tb.sid) continue;
        if (overlap(tb.r, f)) add("text-clear", "warning", `The ${tb.what} overlaps ${layout.symbols.get(sid).sym.name}.`, at, { sym: tb.sid });
      }
    }
    const textNear = boxIndex(textBoxes, (tb) => rectBox(tb.r));
    for (let i = 0; i < textBoxes.length; i++) for (const j of textNear(...rectBox(textBoxes[i].r)).filter((k) => k > i)) {
      const A = textBoxes[i], B = textBoxes[j];
      if (A.sid !== B.sid && overlap(A.r, B.r)) add("text-clear", "warning", `The ${A.what} overlaps the ${B.what}.`, [A.r.x, A.r.y], { sym: A.sid });
    }

    // mate-direct: a mated pair drawn far apart, or joined by a winding line, reads as a cable.
    for (const m of mates) {
      const e = layout.edges.get(m.id);
      if (!e || !e.sections.length) continue;
      const pts = e.sections.flat();
      const len = e.sections.reduce((acc, sec) => acc + sec.slice(1).reduce((t, p, i) => t + Math.hypot(p[0] - sec[i][0], p[1] - sec[i][1]), 0), 0);
      const bends = e.sections.reduce((acc, sec) => acc + Math.max(0, sec.length - 2), 0);
      if (bends > 0 || len > 800) {
        const sa = scene.symbols.get(m.a.symbolId), sb = scene.symbols.get(m.b.symbolId);
        add("mate-direct", "warning", `${label(sa, m.a)} ↔ ${label(sb, m.b)}: mate line is ${Math.round(len)} mil with ${bends} bend${bends === 1 ? "" : "s"}.`, pts[0], { conn: m.id });
      }
    }

    const summary = CHECKS.map(([id, title]) => ({ id, title, errors: findings.filter((f) => f.check === id && f.level === "error").length, warnings: findings.filter((f) => f.check === id && f.level === "warning").length }));
    return { findings, summary };
  }

  return { run, CHECKS };
});
