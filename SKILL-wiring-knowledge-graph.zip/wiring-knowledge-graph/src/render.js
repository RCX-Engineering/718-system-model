/* ============================================================================
 * SVG renderer
 *
 * Draws a laid-out scene with KiCad's schematic symbols and colour roles on
 * an open canvas: symbol bodies and pins, wires with junction dots,
 * hierarchical labels where signals cross an enclosure boundary, and
 * callouts for annotations.
 *
 * Output is an SVG string in mil units. Every drawn element carries data
 * attributes (net, connection, symbol, contact) so the page can highlight a
 * whole net or open the inspector for whatever was clicked.
 * ========================================================================== */

(function (root, factory) {
  const api = factory(root.KGLayout || (typeof require === "function" ? require("./layout.js") : null));
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.KGRender = api;
})(typeof self !== "undefined" ? self : this, function (Layout) {
  "use strict";

  const esc = (s) => String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const f = (v) => (Math.round(v * 10) / 10).toString();
  const pts = (list) => list.map(([x, y]) => `${f(x)},${f(y)}`).join(" ");
  const pathD = (list) => list.map(([x, y], i) => `${i ? "L" : "M"}${f(x)} ${f(y)}`).join("");

  function segmentsOf(sections) {
    const out = [];
    for (const sec of sections) for (let i = 1; i < sec.length; i++) out.push([sec[i - 1], sec[i]]);
    return out;
  }
  function longestHorizontal(sections) {
    let best = null;
    for (const [a, b] of segmentsOf(sections)) {
      if (Math.abs(a[1] - b[1]) > 0.5) continue;
      const len = Math.abs(a[0] - b[0]);
      if (!best || len > best.len) best = { a: a[0] < b[0] ? a : b, b: a[0] < b[0] ? b : a, len };
    }
    return best;
  }
  function midpointOfLongest(sections, t = 0.5) {
    let best = null;
    for (const [a, b] of segmentsOf(sections)) {
      const len = Math.hypot(a[0] - b[0], a[1] - b[1]);
      const [p, q] = a[0] < b[0] || (a[0] === b[0] && a[1] < b[1]) ? [a, b] : [b, a];
      if (!best || len > best.len) best = { len, x: p[0] + (q[0] - p[0]) * t, y: p[1] + (q[1] - p[1]) * t, horizontal: Math.abs(a[1] - b[1]) < 0.5 };
    }
    return best;
  }
  function intersectRect(sections, r) {
    const hits = [];
    const edges = [
      { side: "WEST", x: r.x, y1: r.y, y2: r.y + r.h }, { side: "EAST", x: r.x + r.w, y1: r.y, y2: r.y + r.h },
      { side: "NORTH", y: r.y, x1: r.x, x2: r.x + r.w }, { side: "SOUTH", y: r.y + r.h, x1: r.x, x2: r.x + r.w },
    ];
    for (const [a, b] of segmentsOf(sections)) {
      for (const e of edges) {
        if (e.x !== undefined && Math.abs(a[1] - b[1]) < 0.5) {
          if ((a[0] - e.x) * (b[0] - e.x) <= 0 && a[1] >= e.y1 && a[1] <= e.y2 && a[0] !== b[0]) hits.push({ x: e.x, y: a[1], side: e.side });
        } else if (e.y !== undefined && Math.abs(a[0] - b[0]) < 0.5) {
          if ((a[1] - e.y) * (b[1] - e.y) <= 0 && a[0] >= e.x1 && a[0] <= e.x2 && a[1] !== b[1]) hits.push({ x: a[0], y: e.y, side: e.side });
        }
      }
    }
    return hits;
  }

  /** Drop leading words of a contact name that the interface label already says ("USB-C GND" under "USB-C / 5V"). */
  function shortSub(sub, label) {
    const said = new Set(String(label).toLowerCase().split(/[\s\/·]+/).filter(Boolean));
    const words = String(sub).split(/\s+/);
    let k = 0;
    while (k < words.length - 1 && said.has(words[k].toLowerCase())) k++;
    return words.slice(k).join(" ");
  }

  // ------------------------------------------------------------------ pieces

  function drawBox(sym, g, x, y) {
    const out = [];
    const b = g.body;
    out.push(`<rect class="body" x="${f(x + b.x)}" y="${f(y + b.y)}" width="${f(b.w)}" height="${f(b.h)}"/>`);
    for (const pin of g.pins) {
      const c = pin.contact;
      const [tx, ty] = pin.tip, [bx, by] = pin.base;
      const attrs = `data-sym="${esc(sym.id)}" data-contact="${esc(c.key)}" data-net="${esc(c.net.key)}"`;
      out.push(`<g class="pin${pin.idle ? " idle" : ""}${pin.unplaced ? " unplaced" : ""}" ${attrs}>`);
      out.push(genderedPin(pin, x, y));
      const [nx, ny] = pin.name;
      const rot = pin.rotate ? ` transform="rotate(${pin.rotate} ${f(x + nx)} ${f(y + ny)})"` : "";
      const func = c.func && c.func !== c.name ? `<tspan class="pin-func"> ${esc(c.func)}</tspan>` : "";
      if (!pin.hideName) out.push(`<text class="pin-name" x="${f(x + nx)}" y="${f(y + ny)}" text-anchor="${pin.anchor}" dominant-baseline="central"${rot}>${esc(c.name)}${func}</text>`);
      if (c.number) {
        const [mx, my] = pin.num;
        const nrot = pin.side === "NORTH" || pin.side === "SOUTH" ? ` transform="rotate(-90 ${f(x + mx)} ${f(y + my)})"` : "";
        out.push(`<text class="pin-num" x="${f(x + mx)}" y="${f(y + my)}" text-anchor="middle"${nrot}>${esc(c.number)}</text>`);
      }
      out.push(`<rect class="pin-hit" x="${f(x + Math.min(tx, bx) - 30)}" y="${f(y + Math.min(ty, by) - 40)}" width="${f(Math.abs(tx - bx) + 60)}" height="${f(Math.abs(ty - by) + 80)}"/>`);
      out.push(`</g>`);
    }
    for (const cap of g.captions) out.push(`<text class="sec-cap" x="${f(x + cap.x)}" y="${f(y + cap.y)}" text-anchor="${cap.anchor}" dominant-baseline="central">${esc(cap.text)}</text>`);
    return out.join("");
  }

  /**
   * A box pin, drawn as KiCad draws a connector position of the stated gender: a male pin ends
   * in a filled blade at its mating end, a female one in an open socket arc (Conn_01xNN_Male and
   * _Female). The mating end is the pin tip, where a seated plug meets it nose to nose.
   */
  const BLADE_LEN = 34, BLADE_W = 10, SOCKET_R = 20;   // mils, from the KiCad symbols
  function genderedPin(pin, x, y) {
    const [tx, ty] = pin.tip, [bx, by] = pin.base;
    const len = Math.hypot(tx - bx, ty - by) || 1;
    const u = [(tx - bx) / len, (ty - by) / len], n = [-u[1], u[0]];
    const at = (d, w) => [x + tx - u[0] * d + n[0] * w, y + ty - u[1] * d + n[1] * w];
    const line = (end) => `<line class="pin-line" x1="${f(end[0])}" y1="${f(end[1])}" x2="${f(x + bx)}" y2="${f(y + by)}"/>`;
    if (pin.gender === "male") {
      const corners = [at(0, BLADE_W / 2), at(BLADE_LEN, BLADE_W / 2), at(BLADE_LEN, -BLADE_W / 2), at(0, -BLADE_W / 2)];
      return line(at(0, 0)) + `<polygon class="pin-blade" points="${pts(corners)}"/>`;
    }
    if (pin.gender === "female") {
      const p1 = at(0, SOCKET_R), back = at(SOCKET_R, 0), p2 = at(0, -SOCKET_R);
      const sweep = n[0] * -u[1] - n[1] * -u[0] > 0 ? 1 : 0;
      return line(back) + `<path class="pin-socket" d="M${f(p1[0])} ${f(p1[1])}A${SOCKET_R} ${SOCKET_R} 0 0 ${sweep} ${f(back[0])} ${f(back[1])}A${SOCKET_R} ${SOCKET_R} 0 0 ${sweep} ${f(p2[0])} ${f(p2[1])}"/>`;
    }
    return line(at(0, 0));
  }

  function drawLib(sym, g, x, y) {
    const out = [];
    for (const sh of g.shapes) {
      const cls = sh.fill === "outline" ? "lib-shape fill-outline" : sh.fill === "background" ? "lib-shape fill-bg" : "lib-shape";
      const sw = ` style="stroke-width:${f(Math.max(sh.width, 6))}"`;
      if (sh.type === "poly") out.push(`<polyline class="${cls}"${sw} points="${pts(sh.pts.map(([px, py]) => [x + px, y + py]))}"/>`);
      else if (sh.type === "circle") out.push(`<circle class="${cls}"${sw} cx="${f(x + sh.c[0])}" cy="${f(y + sh.c[1])}" r="${f(sh.r)}"/>`);
      else if (sh.type === "text") out.push(`<text class="lib-text" x="${f(x + sh.at[0])}" y="${f(y + sh.at[1])}" font-size="${f(sh.size)}" text-anchor="middle" dominant-baseline="central">${esc(sh.text)}</text>`);
    }
    for (const pin of g.pins) {
      const [tx, ty] = pin.tip, [bx, by] = pin.base;
      const c = pin.contact;
      const attrs = c ? `data-sym="${esc(sym.id)}" data-contact="${esc(c.key)}" data-net="${esc(c.net.key)}"` : `data-sym="${esc(sym.id)}"`;
      out.push(`<g class="pin" ${attrs}>`);
      out.push(`<line class="pin-line" x1="${f(x + tx)}" y1="${f(y + ty)}" x2="${f(x + bx)}" y2="${f(y + by)}"/>`);
      // Pin numbers come from the graph; a library pin number alone is not evidence of a real position.
      if (!g.numbersHidden && c?.number) {
        const horizontal = pin.side === "WEST" || pin.side === "EAST";
        const mx = (tx + bx) / 2, my = (ty + by) / 2;
        out.push(horizontal
          ? `<text class="pin-num" x="${f(x + mx)}" y="${f(y + my - 16)}" text-anchor="middle">${esc(c.number)}</text>`
          : `<text class="pin-num" x="${f(x + mx - 16)}" y="${f(y + my)}" text-anchor="end" dominant-baseline="central">${esc(c.number)}</text>`);
      }
      out.push(`<rect class="pin-hit" x="${f(x + Math.min(tx, bx) - 30)}" y="${f(y + Math.min(ty, by) - 40)}" width="${f(Math.abs(tx - bx) + 60)}" height="${f(Math.abs(ty - by) + 80)}"/>`);
      out.push(`</g>`);
    }
    for (const cap of g.captions) {
      out.push(`<text class="pin-cap${cap.onWire ? " on-wire" : ""}" x="${f(x + cap.x)}" y="${f(y + cap.y)}" text-anchor="${cap.anchor}" dominant-baseline="${cap.onWire ? "auto" : "central"}">${esc(cap.text)}</text>`);
    }
    return out.join("");
  }

  function drawFields(sym, g, x, y) {
    const out = [];
    const r = g.ref, v = g.value;
    if (r.text) out.push(`<text class="ref" x="${f(x + r.x)}" y="${f(y + r.y)}" text-anchor="${r.anchor}">${esc(r.text)}</text>`);
    const tspans = v.lines.map((line, i) => `<tspan x="${f(x + v.x)}" dy="${i ? 66 : 0}">${esc(line)}</tspan>`).join("");
    out.push(`<text class="val" x="${f(x + v.x)}" y="${f(y + v.y)}" text-anchor="${v.anchor}">${tspans}</text>`);
    return out.join("");
  }

  /**
   * A junction (splice) as KiCad draws a net junction: each conductor's stub runs from its pin end
   * to its joint's trunk, the trunk joins the stubs, and a dot marks every point where three or more
   * lines meet. Stubs and trunks take the colours of the wires they join.
   */
  function drawJunction(sym, g, x, y, strokeFor) {
    const out = [];
    const line = (pts, layers) => layers.map((L) => {
      const style = `stroke-width:${L.w}${L.color ? `;stroke:${L.color}` : ""}${L.dash ? `;stroke-dasharray:${L.dash}` : ""}`;
      return `<path class="${L.cls || "w-core"}" style="${style}" d="${pathD(pts.map(([px, py]) => [x + px, y + py]))}"/>`;
    }).join("");
    const netOf = new Map();
    for (const t of g.trunks) {
      const members = g.pins.filter((p) => p.joint === t.joint);
      const c = members[0]?.contact;
      if (!c) continue;
      netOf.set(t.joint, c.net.key);
      if (t.y2 > t.y1) out.push(`<g class="junction-trunk" data-sym="${esc(sym.id)}" data-net="${esc(c.net.key)}">${line([[t.x, t.y1], [t.x, t.y2]], strokeFor(c))}</g>`);
    }
    for (const pin of g.pins) {
      const c = pin.contact;
      const [tx, ty] = pin.tip;
      out.push(`<g class="pin junction-stub" data-sym="${esc(sym.id)}" data-contact="${esc(c.key)}" data-net="${esc(c.net.key)}">`);
      out.push(line([[tx, ty], [pin.reach, ty]], strokeFor(c)));
      out.push(`<rect class="pin-hit" x="${f(x + Math.min(tx, pin.reach) - 20)}" y="${f(y + ty - 30)}" width="${f(Math.abs(tx - pin.reach) + 40)}" height="60"/>`);
      out.push(`</g>`);
    }
    for (const d of g.dots) out.push(`<circle class="junction j-pin" data-net="${esc(netOf.get(d.joint) || "")}" cx="${f(x + d.x)}" cy="${f(y + d.y)}" r="30"/>`);
    return out.join("");
  }

  /**
   * Two strands along one route, crossing over each other every `pitch` mils, the way a twisted
   * pair is drawn. `first` and `last` give the side (+1 or -1, measured on the route's normal)
   * each strand must sit on where the route starts and ends; the twist count is chosen to match.
   * `startClear` and `endClear` keep that much of the route untwisted at each end, where a
   * conductor has to step across to its strand.
   */
  function twistedStrands(path, half, pitch, firstSide, lastSide, startClear = 0, endClear = 0) {
    const dedup = path.filter((p, i) => !i || Math.hypot(p[0] - path[i - 1][0], p[1] - path[i - 1][1]) > 0.5);
    // Merge runs that continue in a straight line, so each corner is a real turn.
    const pts = dedup.filter((p, i) => {
      if (!i || i === dedup.length - 1) return true;
      const a = dedup[i - 1], b = dedup[i + 1];
      return Math.abs((p[0] - a[0]) * (b[1] - p[1]) - (p[1] - a[1]) * (b[0] - p[0])) > 0.5;
    });
    if (pts.length < 2) return null;
    const segs = [];
    for (let i = 1; i < pts.length; i++) {
      const a = pts[i - 1], b = pts[i], L = Math.hypot(b[0] - a[0], b[1] - a[1]);
      const u = [(b[0] - a[0]) / L, (b[1] - a[1]) / L];
      segs.push({ a, b, L, u, n: [-u[1], u[0]] });
    }
    const MARGIN = 80, X = half;
    // Candidate crossings: every `pitch` along each segment, clear of its corners.
    const spots = segs.map((sg, i) => {
      const list = [];
      const lo = Math.max(MARGIN, i === 0 ? startClear : 0), hi = Math.max(MARGIN, i === segs.length - 1 ? endClear : 0);
      for (let t = lo + X + pitch / 2; t <= sg.L - hi - X; t += pitch) list.push(t);
      return list;
    });
    let count = spots.reduce((a, l) => a + l.length, 0);
    const wantOdd = firstSide !== lastSide;
    if ((count % 2 === 1) !== wantOdd) {
      // Drop the last crossing, or add one mid-way along the longest segment that has room.
      const withSpot = spots.map((l, i) => i).filter((i) => spots[i].length);
      if (withSpot.length) spots[withSpot[withSpot.length - 1]].pop();
      else {
        const k = segs.reduce((best, sg, i) => (sg.L > segs[best].L ? i : best), 0);
        if (segs[k].L < 2 * X + 20) return null;
        spots[k].push(segs[k].L / 2);
      }
    }
    const strand = (side0) => {
      let side = side0;
      const out = [];
      const off = (p, n, s) => [p[0] + n[0] * half * s, p[1] + n[1] * half * s];
      segs.forEach((sg, i) => {
        if (i === 0) out.push(off(sg.a, sg.n, side));
        for (const t of spots[i]) {
          const p1 = [sg.a[0] + sg.u[0] * (t - X), sg.a[1] + sg.u[1] * (t - X)];
          const p2 = [sg.a[0] + sg.u[0] * (t + X), sg.a[1] + sg.u[1] * (t + X)];
          out.push(off(p1, sg.n, side));
          side = -side;
          out.push(off(p2, sg.n, side));
        }
        const next = segs[i + 1];
        if (next) {
          // Mitred corner: offset along both normals.
          out.push([sg.b[0] + (sg.n[0] + next.n[0]) * half * side, sg.b[1] + (sg.n[1] + next.n[1]) * half * side]);
        } else out.push(off(sg.b, sg.n, side));
      });
      return out;
    };
    return { a: strand(firstSide), b: strand(-firstSide), n0: segs[0].n, n1: segs[segs.length - 1].n };
  }

  function wireStroke(conn, opts) {
    // Returns layered stroke specs, bottom first.
    const physical = opts.wireColors === "physical";
    const stripes = conn.color?.stripes || [];
    switch (conn.style) {
      case "coax":
        return [{ cls: "w-casing", w: 34 }, { cls: "w-coax", w: 24 }, { cls: "w-casing", w: 4 }];
      case "mate":
        // Contacts that mate meet pin to pin, as KiCad joins two connector symbols.
        return [{ cls: "w-mate", w: 6 }];
      case "join":
        return [{ cls: "w-join", w: 7, dash: "24 22" }];
      case "interface":
        return physical ? [{ cls: "w-casing", w: 16 }, { cls: "w-plain", w: 8 }] : [{ cls: "w-kicad", w: 8 }];
      case "tap":
        if (physical && stripes.length) {
          const layers = [{ cls: "w-casing", w: 22, dash: "40 16" }, { color: stripes[0].hex, w: 13 }];
          if (stripes[1]) layers.push({ color: stripes[1].hex, w: 13, dash: "46 46" });
          return layers;
        }
        return [{ cls: "w-kicad", w: 8, dash: "40 16" }];
      default:
        if (physical && stripes.length) {
          const layers = [{ cls: "w-casing", w: 21 }, { color: stripes[0].hex, w: 13 }];
          if (stripes[1]) layers.push({ color: stripes[1].hex, w: 13, dash: "46 46" });
          return layers;
        }
        return physical ? [{ cls: "w-casing", w: 16 }, { cls: "w-plain", w: 8 }] : [{ cls: "w-kicad", w: 8 }];
    }
  }

  // ------------------------------------------------------------------ main

  /**
   * Render the laid-out scene. `meta` describes the source graph; `opts` holds the
   * view switches (wireColors, netLabels, wireTags).
   */
  function renderSvg(scene, layout, meta, opts, measure) {
    const out = [];
    const bounds = layout.bounds;

    // Callouts sit above the drawing and point down at their targets.
    const callouts = [];
    for (const a of scene.annotations) {
      const pts = [];
      // Aim the leader past the net label, which sits at the start of the longest run.
      for (const c of a.connections) { const e = layout.edges.get(c.id); if (e) { const m = midpointOfLongest(e.sections, 0.78); if (m) pts.push([m.x, m.y]); } }
      for (const c of a.contacts) {
        const s = layout.symbols.get(c.symbolId);
        const pin = s?.geo.pins.find((p) => p.contact === c);
        if (pin) pts.push([s.x + pin.tip[0], s.y + pin.tip[1]]);
      }
      if (!pts.length) continue;
      const lines = Layout.wrapText(a.title, 34);
      const w = Math.max(...lines.map((l) => measure(l, 46))) + 220;
      const h = lines.length * 60 + 150;
      callouts.push({ a, pts, lines, w, h });
    }
    const calloutBand = callouts.length ? Math.max(...callouts.map((c) => c.h)) + 260 : 0;

    // Hierarchical labels hang outside their enclosure, so measure them before sizing the view.
    const ext = { x1: 0, x2: bounds.w };
    for (const iface of scene.interfaces) for (const port of iface.ports) {
      const pt = layout.ports.get(port.id);
      if (!pt) continue;
      const w = measure(`${port.label} · ${shortSub(port.sub, port.label)}`, 40) + 130;
      if (pt.side !== "EAST") ext.x1 = Math.min(ext.x1, pt.x - w - 60);
      else ext.x2 = Math.max(ext.x2, pt.x + w + 60);
    }
    // The view is the drawing itself: parts, wires, labels and callouts, with a working margin.
    const pad = 260;
    const content = { x: ext.x1 - pad, y: -calloutBand - pad, w: ext.x2 - ext.x1 + 2 * pad, h: bounds.h + calloutBand + 2 * pad };
    const vb = content;

    out.push(`<svg xmlns="http://www.w3.org/2000/svg" class="schematic" viewBox="${f(vb.x)} ${f(vb.y)} ${f(vb.w)} ${f(vb.h)}" data-vb="${f(vb.x)} ${f(vb.y)} ${f(vb.w)} ${f(vb.h)}">`);
    out.push(`<rect class="paper" x="${f(vb.x - vb.w)}" y="${f(vb.y - vb.h)}" width="${f(vb.w * 3)}" height="${f(vb.h * 3)}"/>`);

    // ---- groups --------------------------------------------------------------------------------
    out.push(`<g class="groups">`);
    const depth = (g) => { let d = 0, cur = g.group.parent; while (cur) { d++; cur = scene.groups.get(cur)?.parent; } return d; };
    for (const [gid, g] of [...layout.groups].sort((a, b) => depth(a[1]) - depth(b[1]))) {
      const d = depth(g);
      out.push(`<g class="group depth-${Math.min(d, 2)}" data-group="${esc(gid)}">`);
      out.push(`<rect class="group-frame" x="${f(g.x)}" y="${f(g.y)}" width="${f(g.w)}" height="${f(g.h)}" rx="${d ? 30 : 0}"/>`);
      out.push(`<text class="group-title" x="${f(g.x + 90)}" y="${f(g.y + 120)}">${esc(g.group.name)}</text>`);
      if (g.group.subtitle) out.push(`<text class="group-sub" x="${f(g.x + 90)}" y="${f(g.y + 190)}">${esc(g.group.subtitle)}</text>`);
      out.push(`</g>`);
    }
    out.push(`</g>`);

    // ---- annotation halos (under the wires) -----------------------------------------------------------
    out.push(`<g class="halos">`);
    for (const co of callouts) {
      for (const c of co.a.connections) {
        const e = layout.edges.get(c.id);
        if (e) for (const sec of e.sections) out.push(`<path class="halo" data-annotation="${esc(co.a.id)}" d="${pathD(sec)}"/>`);
      }
    }
    out.push(`</g>`);

    // ---- wires ------------------------------------------------------------------------------------------
    out.push(`<g class="wires">`);
    // Conductors inside a cable show only their bus entries; the jacket is drawn once as the bus.
    const entryRuns = new Map();
    for (const b of layout.bundles || []) for (const end of b.ends) for (const en of end.entries) {
      if (!entryRuns.has(en.conn.id)) entryRuns.set(en.conn.id, []);
      entryRuns.get(en.conn.id).push(en.pts);
    }
    const order = { join: 0, interface: 1, mate: 2, coax: 3, tap: 4, wire: 5 };
    const conns = [...layout.connections].sort((a, b) => (order[a.style] ?? 5) - (order[b.style] ?? 5));
    for (const c of conns) {
      const e = layout.edges.get(c.id);
      if (!e) continue;
      const layers = wireStroke(c, opts);
      const netKey = c.net ? c.net.key : "";
      out.push(`<g class="conn style-${esc(c.style)}${c.inferred ? " inferred" : ""}" data-conn="${esc(c.id)}" data-net="${esc(netKey)}">`);
      if (e.bus) for (const sec of e.sections) out.push(`<path class="trace" d="${pathD(sec)}"/>`);
      for (const sec of e.bus ? entryRuns.get(c.id) || [] : e.sections) {
        const d = pathD(sec);
        out.push(`<path class="hit" d="${d}"/>`);
        for (const L of layers) {
          const style = `stroke-width:${L.w}${L.color ? `;stroke:${L.color}` : ""}${L.dash ? `;stroke-dasharray:${L.dash}` : ""}`;
          out.push(`<path class="${L.cls || "w-core"}" style="${style}" d="${d}"/>`);
        }
      }
      for (const [jx, jy] of e.junctions) out.push(`<circle class="junction j-${esc(c.style)}" cx="${f(jx)}" cy="${f(jy)}" r="${c.style === "join" ? 18 : 30}"/>`);
      out.push(`</g>`);
    }
    // KiCad marks a junction wherever three or more items meet: a pin end taking two wires is one.
    const ends = new Map();
    for (const c of layout.connections) {
      const e = layout.edges.get(c.id);
      if (!e || e.docked || !e.sections.length) continue;
      const runs = e.bus ? entryRuns.get(c.id) || [] : e.sections;
      const pts = e.bus ? runs.map((r) => r[0]) : [runs[0][0], runs[runs.length - 1][runs[runs.length - 1].length - 1]];
      for (const [x, y] of pts) {
        const k = `${Math.round(x)},${Math.round(y)}`;
        if (!ends.has(k)) ends.set(k, { x, y, n: 0, net: c.net?.key || "" });
        ends.get(k).n++;
      }
    }
    for (const [sid, sv] of layout.symbols) for (const pin of sv.geo.pins) {
      if (!pin.contact) continue;
      const hit = ends.get(`${Math.round(sv.x + pin.tip[0])},${Math.round(sv.y + pin.tip[1])}`);
      if (hit && hit.n >= 2) out.push(`<circle class="junction j-pin" data-net="${esc(hit.net)}" cx="${f(hit.x)}" cy="${f(hit.y)}" r="30"/>`);
    }
    out.push(`</g>`);

    // A twisted pair: each conductor runs from its bus entry along the spine to its strand, and the
    // two strands twist around each other along the route.
    // A pair whose route turns close to an end is drawn narrower, so its conductors still step out
    // to their strands before the turn.
    const PAIR_HALF = 22, PAIR_HALF_TIGHT = 14, PAIR_PITCH = 360;
    function drawPair(b, HALF = PAIR_HALF) {
      const [A, B] = b.ends;
      const [c0, c1] = b.bundle.connections;
      // The pair leaves each end straight outward, whichever way the route then turns.
      const OUT = { WEST: [-1, 0], EAST: [1, 0], NORTH: [0, -1], SOUTH: [0, 1] };
      const oa = OUT[A.side], ob = OUT[B.side];
      if (!oa || !ob) return null;
      const p0 = b.path[0], pn = b.path[b.path.length - 1];
      const route = [[p0[0] - oa[0], p0[1] - oa[1]], ...b.path, [pn[0] - ob[0], pn[1] - ob[1]]];
      const probe = twistedStrands(route, HALF, PAIR_PITCH, 1, 1);
      if (!probe) return null;
      const joinAt = (end, conn) => { const p = end.entries.find((x) => x.conn === conn).pts; return p[p.length - 1]; };
      const proj = (end, n, conn) => { const j = joinAt(end, conn); return (j[0] - end.centre[0]) * n[0] + (j[1] - end.centre[1]) * n[1]; };
      // Each conductor takes the strand on its own side of where the pair starts. Where both enter
      // from one side (two pairs sharing a doubled crimp), each steps out to its strand at its own
      // distance, the nearer crossing the farther at right angles, so the two never share a line.
      const plan = (end, n) => {
        const q0 = proj(end, n, c0), q1 = proj(end, n, c1);
        if (q0 && q1 && Math.sign(q0) !== Math.sign(q1)) return { s0: Math.sign(q0), jog: [0, 0] };
        const sign = Math.sign(q0 || q1) || 1;
        const farIs0 = Math.abs(q0) >= Math.abs(q1);
        return { s0: farIs0 ? sign : -sign, jog: farIs0 ? [60, 30] : [30, 60] };
      };
      const pa = plan(A, probe.n0), pb = plan(B, probe.n1);
      // An end whose conductors step out to their strands keeps its first stretch untwisted.
      const STEP_CLEAR = 160;
      const tw = twistedStrands(route, HALF, PAIR_PITCH, pa.s0, pb.s0, pa.jog[0] ? STEP_CLEAR : 0, pb.jog[0] ? STEP_CLEAR : 0);
      if (!tw) return null;
      // Stepping out needs the pair to run straight out from that end for a while.
      const straight = (pts, o, atEnd) => {
        const [p, q] = atEnd ? [pts[pts.length - 1], pts[pts.length - 2]] : [pts[0], pts[1]];
        const d = [q[0] - p[0], q[1] - p[1]], dir = atEnd ? [-o[0], -o[1]] : o;
        return Math.abs(d[0] * dir[1] - d[1] * dir[0]) < 0.5 ? Math.abs(d[0] * dir[0] + d[1] * dir[1]) : 0;
      };
      // Each step lands on its strand before the strand first bends: the farther step plus the
      // pair's width must fit in the straight run, on both strands. Crossings are kept clear of
      // that run by STEP_CLEAR above.
      const room = (o, atEnd) => Math.min(straight(tw.a, o, atEnd), straight(tw.b, o, atEnd));
      const need = (jog) => Math.max(...jog) + 2 * HALF;
      // where the run is shorter than the usual steps, the steps shrink to fit it, keeping the
      // farther step twice the nearer
      const fit = (p, r) => {
        if (!p.jog[0] || r >= need(p.jog)) return true;
        const far = Math.floor(r - 2 * HALF - 4);
        if (far < 20) return false;
        p.jog = p.jog[0] > p.jog[1] ? [far, far / 2] : [far / 2, far];
        return true;
      };
      if (!fit(pa, room(oa, false)) || !fit(pb, room(ob, true))) return null;
      const parts = [];
      for (const [i, conn, strand] of [[0, c0, tw.a], [1, c1, tw.b]]) {
        const ja = joinAt(A, conn), jb = joinAt(B, conn);
        let body = strand.slice();
        if (pa.jog[i]) {
          const d = pa.jog[i], s0 = body[0];
          body = [[ja[0] + oa[0] * d, ja[1] + oa[1] * d], [s0[0] + oa[0] * d, s0[1] + oa[1] * d], ...body.slice(1)];
        }
        if (pb.jog[i]) {
          const d = pb.jog[i], sn = body[body.length - 1];
          body = [...body.slice(0, -1), [sn[0] + ob[0] * d, sn[1] + ob[1] * d], [jb[0] + ob[0] * d, jb[1] + ob[1] * d]];
        }
        const full = [ja, ...body, jb];
        const layers = wireStroke(conn, opts).map((L) => ({ ...L, w: Math.max(6, Math.round(L.w * 0.7)) }));
        parts.push(`<g class="pair-strand" data-conn="${esc(conn.id)}" data-net="${esc(conn.net?.key || "")}">`);
        for (const L of layers) {
          const style = `stroke-width:${L.w}${L.color ? `;stroke:${L.color}` : ""}${L.dash ? `;stroke-dasharray:${L.dash}` : ""}`;
          parts.push(`<path class="${L.cls || "w-core"}" style="${style}" d="${pathD(full)}"/>`);
        }
        parts.push(`</g>`);
      }
      return parts.join("");
    }

    // ---- buses: one thick line per cable jacket, with a KiCad bus label {member nets} ----------------
    // A twisted pair that cannot be drawn twisted falls back to a plain bus line; it is reported,
    // so the drawing never passes it off as a jacketed cable unnoticed.
    const pairFallbacks = [];
    out.push(`<g class="buses">`);
    for (const b of layout.bundles || []) {
      const runs = [b.path, ...b.ends.map((en) => en.spine)];
      const pair = b.bundle.style === "pair" && b.bundle.connections.length === 2 ? drawPair(b) || drawPair(b, PAIR_HALF_TIGHT) : null;
      if (b.bundle.style === "pair" && !pair) pairFallbacks.push({ id: b.bundle.id, name: b.bundle.name, at: b.path[0] });
      out.push(`<g class="bus${pair ? " pair" : ""}" data-bundle="${esc(b.bundle.id)}">`);
      for (const run of runs) out.push(`<path class="hit" d="${pathD(run)}"/>`);
      if (pair) out.push(pair);
      else for (const run of runs) out.push(`<path class="bus-line" d="${pathD(run)}"/>`);
      const L = b.label;
      if (L && isFinite(L.x)) {
        out.push(`<text class="bus-label" x="${f(L.x + 20)}" y="${f(L.y + L.h / 2)}" dominant-baseline="central">${esc(L.text)}</text>`);
      } else if (L) {
        const seg = longestHorizontal([b.path]);
        const [lx, ly] = seg ? [seg.a[0] + 40, seg.a[1] + 76] : [b.ends[0].spine[0][0] + 50, b.ends[0].spine[0][1] - 40];
        out.push(`<text class="bus-label" x="${f(lx)}" y="${f(ly)}">${esc(L.text)}</text>`);
      }
      out.push(`</g>`);
    }
    out.push(`</g>`);

    // ---- symbols --------------------------------------------------------------------------------------
    out.push(`<g class="symbols">`);
    for (const [sid, s] of layout.symbols) {
      const sym = s.sym;
      out.push(`<g class="symbol kind-${s.geo.kind}" data-sym="${esc(sid)}">`);
      out.push(`<rect class="sym-hit" x="${f(s.x)}" y="${f(s.y)}" width="${f(s.w)}" height="${f(s.h)}"/>`);
      const strokeFor = (c) => { const cn = layout.connections.find((q) => q.a === c || q.b === c); return cn ? wireStroke(cn, opts) : [{ cls: "w-kicad", w: 8 }]; };
      out.push(s.geo.junction ? drawJunction(sym, s.geo, s.x, s.y, strokeFor) : s.geo.kind === "box" ? drawBox(sym, s.geo, s.x, s.y) : drawLib(sym, s.geo, s.x, s.y));
      out.push(drawFields(sym, s.geo, s.x, s.y));
      // Pins with nothing attached get KiCad's open-pin circle.
      for (const pin of s.geo.pins) {
        const c = pin.contact;
        if (!c || !c.visible) continue;
        const wired = layout.connections.some((cn) => cn.a === c || cn.b === c);
        if (!wired && !pin.idle) out.push(`<circle class="open-pin" cx="${f(s.x + pin.tip[0])}" cy="${f(s.y + pin.tip[1])}" r="18"/>`);
      }
      out.push(`</g>`);
    }
    out.push(`</g>`);

    // ---- labels: net names, wire tags, interfaces ------------------------------------------------------
    out.push(`<g class="labels">`);
    // Labels on wires (net names, wire tags) sit on their own wire, clear of parts, other nets'
    // wires and each other.
    const segsAll = [];
    for (const c of layout.connections) {
      const e = layout.edges.get(c.id);
      if (!e) continue;
      for (const sec of e.bus ? entryRuns.get(c.id) || [] : e.sections) for (let k = 1; k < sec.length; k++) segsAll.push({ a: sec[k - 1], b: sec[k], net: c.net?.key || c.id });
    }
    for (const b of layout.bundles || []) for (const run of [b.path, ...b.ends.map((en) => en.spine)]) for (let k = 1; k < run.length; k++) segsAll.push({ a: run[k - 1], b: run[k], net: "" });
    const footprints = [...layout.symbols.values()].map((sv) => ({ x: sv.x, y: sv.y, w: sv.w, h: sv.h }));
    const placedLabels = [];
    const meets = (r, q) => r.x < q.x + q.w && q.x < r.x + r.w && r.y < q.y + q.h && q.y < r.y + r.h;
    const distToSeg = ([px, py], a, b) => {
      const dx = b[0] - a[0], dy = b[1] - a[1], L = dx * dx + dy * dy || 1;
      const t = Math.max(0, Math.min(1, ((px - a[0]) * dx + (py - a[1]) * dy) / L));
      return Math.hypot(px - a[0] - t * dx, py - a[1] - t * dy);
    };
    const segHits = (sg, r) => {
      const [x1, x2] = [Math.min(sg.a[0], sg.b[0]), Math.max(sg.a[0], sg.b[0])], [y1, y2] = [Math.min(sg.a[1], sg.b[1]), Math.max(sg.a[1], sg.b[1])];
      return x1 <= r.x + r.w && x2 >= r.x && y1 <= r.y + r.h && y2 >= r.y;
    };
    if (opts.netLabels) {
      const byNet = new Map();
      for (const c of layout.connections) {
        if (!c.net || c.bundle || c.style === "join" || c.style === "interface" || c.style === "mate") continue;
        const e = layout.edges.get(c.id);
        if (!e) continue;
        if (!byNet.has(c.net.key)) byNet.set(c.net.key, { net: c.net, segs: [] });
        for (const [a, b] of segmentsOf(e.sections)) if (Math.abs(a[1] - b[1]) < 0.5) byNet.get(c.net.key).segs.push(a[0] < b[0] ? [a, b] : [b, a]);
      }
      for (const { net, segs } of byNet.values()) {
        const w = measure(net.name, 44) + 36;
        segs.sort((p, q) => (q[1][0] - q[0][0]) - (p[1][0] - p[0][0]));
        let spot = null;
        for (const [a, b] of segs) {
          const len = b[0] - a[0];
          if (len < w + 90) continue;
          // Above the wire as KiCad places labels, else below; the band out to the next grid line
          // must hold no other net, so the label cannot be read as naming a neighbour.
          for (const below of [false, true]) {
            for (const x of [a[0] + 70, (a[0] + b[0] - w) / 2, b[0] - w - 20]) {
              const r = { x: x - 18, y: below ? a[1] + 12 : a[1] - 78, w, h: 58 };
              const band = { x: r.x, y: below ? a[1] + 4 : a[1] - 100, w, h: 96 };
              const host = (sg) => Math.abs(sg.a[1] - a[1]) < 0.5 && Math.abs(sg.b[1] - a[1]) < 0.5 && sg.net === net.key;
              // Its own net's other runs may not pass under it either: the label would cut the wire.
              if (footprints.some((q) => meets(r, q)) || placedLabels.some((q) => meets(r, q)) || segsAll.some((sg) => (sg.net !== net.key && segHits(sg, band)) || (!host(sg) && segHits(sg, r)))) continue;
              spot = { x, y: below ? a[1] + 56 : a[1] - 34, r };
              break;
            }
            if (spot) break;
          }
          if (spot) break;
        }
        if (!spot) continue;
        placedLabels.push(spot.r);
        out.push(`<g class="net-label" data-net="${esc(net.key)}"><rect x="${f(spot.r.x)}" y="${f(spot.r.y)}" width="${f(w)}" height="58" rx="8"/><text x="${f(spot.x)}" y="${f(spot.y)}">${esc(net.name)}</text></g>`);
      }
    }
    if (opts.wireTags) {
      for (const c of layout.connections) {
        if (c.bundle || (!c.color && !c.props?.gauge)) continue;
        const e = layout.edges.get(c.id);
        if (!e) continue;
        const text = [c.color?.label?.toUpperCase().replace(/\s+/g, ""), c.props?.gauge].filter(Boolean).join(" · ");
        const w = measure(text, 36) + 30;
        const own = c.net?.key || c.id;
        const segs = segmentsOf(e.sections).map(([a, b]) => ({ a, b, len: Math.hypot(a[0] - b[0], a[1] - b[1]), horizontal: Math.abs(a[1] - b[1]) < 0.5 })).filter((sg) => sg.len >= 300).sort((p, q) => q.len - p.len);
        let spot = null;
        for (const sg of segs) {
          for (const t of [0.5, 0.3, 0.7]) {
            const mx = sg.a[0] + (sg.b[0] - sg.a[0]) * t, my = sg.a[1] + (sg.b[1] - sg.a[1]) * t;
            const tries = sg.horizontal ? [[mx - w / 2, my + 30], [mx - w / 2, my - 80]] : [[mx + 30, my - 24], [mx - 30 - w, my - 24]];
            for (const [x, y] of tries) {
              const r = { x, y, w, h: 50 };
              // Keep other nets well clear, so the tag is nearest the wire it describes.
              const band = { x: r.x - 60, y: r.y - 60, w: r.w + 120, h: r.h + 120 };
              // A wide tag beside a vertical run reaches far from it; its centre must still lie
              // nearer its own wire than any other net's.
              const centre = [r.x + r.w / 2, r.y + r.h / 2], mine = distToSeg(centre, sg.a, sg.b);
              if (footprints.some((q) => meets(r, q)) || placedLabels.some((q) => meets(r, q)) || segsAll.some((o) => o.net !== own && (segHits(o, band) || distToSeg(centre, o.a, o.b) <= mine + 20))) continue;
              spot = r;
              break;
            }
            if (spot) break;
          }
          if (spot) break;
        }
        if (!spot) continue;
        placedLabels.push(spot);
        out.push(`<g class="wire-tag" data-conn="${esc(c.id)}" data-net="${esc(c.net?.key || "")}"><rect x="${f(spot.x)}" y="${f(spot.y)}" width="${f(w)}" height="50" rx="6"/><text x="${f(spot.x + 15)}" y="${f(spot.y + 36)}">${esc(text)}</text></g>`);
      }
    }
    // Hierarchical labels on enclosure ports.
    for (const iface of scene.interfaces) {
      for (const port of iface.ports) {
        const pt = layout.ports.get(port.id);
        if (!pt) continue;
        const text = `${port.label} · ${shortSub(port.sub, port.label)}`;
        const w = measure(text, 40) + 90;
        const west = pt.side !== "EAST";
        const x0 = west ? pt.x - w - 40 : pt.x + 40;
        const tipX = west ? pt.x - 40 : pt.x + 40;
        const shape = west
          ? `${f(x0)},${f(pt.y - 32)} ${f(tipX - 32)},${f(pt.y - 32)} ${f(tipX)},${f(pt.y)} ${f(tipX - 32)},${f(pt.y + 32)} ${f(x0)},${f(pt.y + 32)}`
          : `${f(tipX)},${f(pt.y)} ${f(tipX + 32)},${f(pt.y - 32)} ${f(x0 + w)},${f(pt.y - 32)} ${f(x0 + w)},${f(pt.y + 32)} ${f(tipX + 32)},${f(pt.y + 32)}`;
        out.push(`<g class="hier-label" data-net="${esc(port.contact.net.key)}" data-iface="${esc(iface.id)}"><line x1="${f(pt.x)}" y1="${f(pt.y)}" x2="${f(tipX)}" y2="${f(pt.y)}"/><polygon points="${shape}"/><text x="${f(west ? x0 + 24 : x0 + w - 24)}" y="${f(pt.y)}" text-anchor="${west ? "start" : "end"}" dominant-baseline="central">${esc(text)}</text></g>`);
      }
      // Crossing tags where a connection leaves the enclosure.
      if (!iface.crossings.length || !iface.group) continue;
      const g = layout.groups.get(iface.group);
      if (!g) continue;
      const hits = [];
      // A plug seated on a crossing contact carries the crossing on its own wires.
      const seated = new Map();
      for (const d of (layout.docks || new Map()).values()) for (const x of d.pairs) { seated.set(x.hostC, x.plugC); seated.set(x.plugC, x.hostC); }
      const via = iface.crossings.flatMap((c) => (seated.has(c) ? [c, seated.get(c)] : [c]));
      for (const c of via) {
        for (const conn of layout.connections) {
          if (conn.a !== c && conn.b !== c) continue;
          const e = layout.edges.get(conn.id);
          if (e) hits.push(...intersectRect(e.sections, g));
        }
      }
      if (!hits.length) continue;
      // Conductors sharing a bus cross the boundary at one point; mark it once.
      const seen = new Set();
      for (let i = hits.length - 1; i >= 0; i--) {
        const k = `${Math.round(hits[i].x)},${Math.round(hits[i].y)}`;
        if (seen.has(k)) hits.splice(i, 1); else seen.add(k);
      }
      hits.sort((a, b) => a.y - b.y || a.x - b.x);
      const mid = hits[Math.floor((hits.length - 1) / 2)];
      for (const h of hits) out.push(`<rect class="cross-mark" x="${f(h.x - 22)}" y="${f(h.y - 22)}" width="44" height="44"/>`);
      const text = iface.label;
      const w = measure(text, 40) + 60;
      const above = Math.min(...hits.map((h) => h.y)) - 120;
      const x = mid.side === "WEST" ? mid.x - w - 60 : mid.side === "EAST" ? mid.x + 60 : mid.x - w / 2;
      const y = mid.side === "NORTH" ? mid.y - 140 : mid.side === "SOUTH" ? mid.y + 80 : above - 30;
      out.push(`<g class="iface-tag" data-iface="${esc(iface.id)}"><rect x="${f(x)}" y="${f(y)}" width="${f(w)}" height="64" rx="32"/><text x="${f(x + w / 2)}" y="${f(y + 32)}" text-anchor="middle" dominant-baseline="central">${esc(text)}</text></g>`);
    }
    out.push(`</g>`);

    // ---- callouts ------------------------------------------------------------------------------------------
    out.push(`<g class="callouts">`);
    let nextX = -Infinity;
    for (const co of callouts) {
      const cx = co.pts.reduce((s, p) => s + p[0], 0) / co.pts.length;
      let x = Math.max(cx - co.w / 2, nextX + 120, ext.x1);
      const y = -calloutBand;
      nextX = x + co.w;
      // Pick the target and drop line that pass the fewest pin ends and parts on the way down.
      const tipsAll = [];
      for (const sv of layout.symbols.values()) for (const pin of sv.geo.pins) tipsAll.push([sv.x + pin.tip[0], sv.y + pin.tip[1]]);
      const boxes = [...layout.symbols.values()].map((sv) => ({ x: sv.x, y: sv.y, w: sv.w, h: sv.h }));
      const cost = (t, lxc) => {
        const legs = [[[lxc, y + co.h], [lxc, t[1] - 90]], [[lxc, t[1] - 90], [t[0], t[1] - 90]], [[t[0], t[1] - 90], [t[0], t[1] - 60]]];
        let n = 0;
        for (const [p, q] of legs) {
          const [x1, x2] = [Math.min(p[0], q[0]), Math.max(p[0], q[0])], [y1, y2] = [Math.min(p[1], q[1]), Math.max(p[1], q[1])];
          n += 10 * tipsAll.filter(([tx, ty]) => tx >= x1 - 30 && tx <= x2 + 30 && ty >= y1 - 30 && ty <= y2 + 30).length;
          n += boxes.filter((b) => !(t[0] >= b.x && t[0] <= b.x + b.w && t[1] >= b.y && t[1] <= b.y + b.h) && x1 <= b.x + b.w && x2 >= b.x && y1 <= b.y + b.h && y2 >= b.y).length;
        }
        return n;
      };
      let target = co.pts.slice().sort((a, b) => a[1] - b[1])[0], lx = Math.min(Math.max(target[0], x + 80), x + co.w - 80), best = Infinity;
      for (const t of co.pts) for (const d of [0, -60, 60, -140, 140, -240, 240]) {
        const lxc = Math.min(Math.max(t[0] + d, x + 80), x + co.w - 80);
        const c = cost(t, lxc) + Math.abs(d) / 1000;
        if (c < best) { best = c; target = t; lx = lxc; }
      }
      out.push(`<g class="callout" data-annotation="${esc(co.a.id)}">`);
      // The leader stops short of its target with an arrowhead, so it never reads as a wire into a pin.
      out.push(`<path class="leader" d="M${f(lx)} ${f(y + co.h)} L${f(lx)} ${f(target[1] - 90)} L${f(target[0])} ${f(target[1] - 90)} L${f(target[0])} ${f(target[1] - 60)}"/>`);
      out.push(`<path class="leader-head" d="M${f(target[0] - 22)} ${f(target[1] - 64)} L${f(target[0])} ${f(target[1] - 24)} L${f(target[0] + 22)} ${f(target[1] - 64)} Z"/>`);
      out.push(`<rect class="callout-box" x="${f(x)}" y="${f(y)}" width="${f(co.w)}" height="${f(co.h)}" rx="18"/>`);
      out.push(`<path class="callout-icon" d="M${f(x + 100)} ${f(y + 58)} l42 76 h-84 z"/><text class="callout-bang" x="${f(x + 100)}" y="${f(y + 124)}" text-anchor="middle">!</text>`);
      co.lines.forEach((l, i) => out.push(`<text class="callout-text" x="${f(x + 180)}" y="${f(y + 100 + i * 60)}">${esc(l)}</text>`));
      out.push(`<text class="callout-hint" x="${f(x + 180)}" y="${f(y + 100 + co.lines.length * 60 + 10)}">${esc(co.a.node.labels[0] || "Annotation")} · select for details</text>`);
      out.push(`</g>`);
    }
    out.push(`</g>`);

    out.push(`</svg>`);
    return { svg: out.join(""), viewBox: vb, content, pairFallbacks };
  }

  return { renderSvg };
});
