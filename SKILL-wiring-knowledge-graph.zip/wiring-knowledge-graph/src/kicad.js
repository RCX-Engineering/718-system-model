/* ============================================================================
 * KiCad symbol library reader
 *
 * Parses .kicad_sym s-expression text (KiCad 6 and later) into drawable symbol
 * models. Geometry is converted from millimetres to mils so it sits on
 * KiCad's 50 mil schematic grid, and kept Y-up exactly as in the library;
 * the renderer flips it when drawing.
 * ========================================================================== */

(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  else root.KGKicad = api;
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";

  const MM_TO_MIL = 1 / 0.0254;

  /** Tokenise and parse s-expressions into nested arrays of strings. */
  function parseSexpr(text) {
    let i = 0;
    const n = text.length;
    const stack = [[]];
    while (i < n) {
      const c = text[i];
      if (c === "(") { stack.push([]); i++; continue; }
      if (c === ")") {
        const done = stack.pop();
        if (!stack.length) throw new Error("Unbalanced ')' in symbol library");
        stack[stack.length - 1].push(done);
        i++;
        continue;
      }
      if (c === " " || c === "\n" || c === "\t" || c === "\r") { i++; continue; }
      if (c === '"') {
        let out = "";
        i++;
        while (i < n && text[i] !== '"') {
          if (text[i] === "\\" && i + 1 < n) { const e = text[i + 1]; out += e === "n" ? "\n" : e; i += 2; continue; }
          out += text[i++];
        }
        i++;
        stack[stack.length - 1].push({ s: out });
        continue;
      }
      let j = i;
      while (j < n && !" \n\t\r()\"".includes(text[j])) j++;
      stack[stack.length - 1].push(text.slice(i, j));
      i = j;
    }
    if (stack.length !== 1) throw new Error("Unbalanced '(' in symbol library");
    return stack[0];
  }

  const str = (a) => (a && typeof a === "object" && "s" in a ? a.s : a);
  const num = (a) => parseFloat(str(a));
  const mil = (a) => num(a) * MM_TO_MIL;
  const find = (list, head) => list.find((x) => Array.isArray(x) && x[0] === head);
  const findAll = (list, head) => list.filter((x) => Array.isArray(x) && x[0] === head);

  function strokeOf(item) {
    const s = find(item, "stroke");
    const w = s && find(s, "width");
    const width = w ? mil(w[1]) : 0;
    return width > 0 ? width : 6;
  }
  function fillOf(item) {
    const f = find(item, "fill");
    const t = f && find(f, "type");
    return t ? str(t[1]) : "none";
  }

  function readGraphic(item) {
    switch (item[0]) {
      case "rectangle": {
        const s = find(item, "start"), e = find(item, "end");
        return { type: "rect", x1: mil(s[1]), y1: mil(s[2]), x2: mil(e[1]), y2: mil(e[2]), width: strokeOf(item), fill: fillOf(item) };
      }
      case "polyline": {
        const pts = findAll(find(item, "pts"), "xy").map((p) => [mil(p[1]), mil(p[2])]);
        return { type: "polyline", pts, width: strokeOf(item), fill: fillOf(item) };
      }
      case "circle": {
        const c = find(item, "center"), r = find(item, "radius");
        return { type: "circle", cx: mil(c[1]), cy: mil(c[2]), r: mil(r[1]), width: strokeOf(item), fill: fillOf(item) };
      }
      case "arc": {
        const s = find(item, "start"), m = find(item, "mid"), e = find(item, "end");
        if (!m) return null;
        return { type: "arc", start: [mil(s[1]), mil(s[2])], mid: [mil(m[1]), mil(m[2])], end: [mil(e[1]), mil(e[2])], width: strokeOf(item), fill: fillOf(item) };
      }
      case "bezier": {
        const pts = findAll(find(item, "pts"), "xy").map((p) => [mil(p[1]), mil(p[2])]);
        return { type: "bezier", pts, width: strokeOf(item), fill: fillOf(item) };
      }
      case "text": {
        const at = find(item, "at");
        const eff = find(item, "effects");
        const size = eff && find(find(eff, "font") || [], "size");
        return { type: "text", text: str(item[1]), x: mil(at[1]), y: mil(at[2]), angle: num(at[3] || 0), size: size ? mil(size[1]) : 50 };
      }
    }
    return null;
  }

  function readPin(item) {
    const at = find(item, "at");
    const len = find(item, "length");
    const name = find(item, "name");
    const number = find(item, "number");
    return {
      etype: item[1],
      shape: item[2],
      x: mil(at[1]),
      y: mil(at[2]),
      angle: num(at[3] || 0),
      length: len ? mil(len[1]) : 100,
      name: name ? str(name[1]) : "",
      number: number ? str(number[1]) : "",
      hidden: item.includes("hide") || !!(find(item, "hide") && str(find(item, "hide")[1]) !== "no"),
    };
  }

  function readSymbol(item, libName) {
    const name = str(item[1]);
    const props = {};
    for (const p of findAll(item, "property")) {
      const at = find(p, "at") || ["at", 0, 0, 0];
      const eff = find(p, "effects") || [];
      const size = find(find(eff, "font") || [], "size");
      props[str(p[1])] = {
        value: str(p[2]),
        x: mil(at[1]), y: mil(at[2]), angle: num(at[3] || 0),
        size: size ? mil(size[1]) : 50,
        hidden: eff.includes("hide") || !!(find(eff, "hide") && str(find(eff, "hide")[1]) !== "no"),
      };
    }
    const pinNames = find(item, "pin_names");
    const pinNumbers = find(item, "pin_numbers");
    const extendsItem = find(item, "extends");
    const symbol = {
      lib: libName,
      name,
      id: `${libName}:${name}`,
      power: !!find(item, "power"),
      pinNamesHidden: !!pinNames && (pinNames.includes("hide") || !!(find(pinNames, "hide") && str(find(pinNames, "hide")[1]) !== "no")),
      pinNumbersHidden: !!pinNumbers && (pinNumbers.includes("hide") || !!(find(pinNumbers, "hide") && str(find(pinNumbers, "hide")[1]) !== "no")),
      pinNameOffset: pinNames && find(pinNames, "offset") ? mil(find(pinNames, "offset")[1]) : 20,
      props,
      graphics: [],
      pins: [],
      extends: extendsItem ? str(extendsItem[1]) : null,
    };
    for (const unit of findAll(item, "symbol")) {
      const m = /_(\d+)_(\d+)$/.exec(str(unit[1]));
      const unitNo = m ? +m[1] : 0, style = m ? +m[2] : 0;
      if (unitNo > 1 || style > 1) continue;
      for (const child of unit.slice(2)) {
        if (!Array.isArray(child)) continue;
        if (child[0] === "pin") symbol.pins.push(readPin(child));
        else { const g = readGraphic(child); if (g) symbol.graphics.push(g); }
      }
    }
    return symbol;
  }

  class Library {
    constructor() { this.libs = new Map(); }

    /** Add every symbol from one .kicad_sym text under the given library nickname. */
    addText(libName, text) {
      const tree = parseSexpr(text);
      const top = tree.find((x) => Array.isArray(x) && x[0] === "kicad_symbol_lib");
      if (!top) throw new Error(`${libName}: not a kicad_symbol_lib file`);
      if (!this.libs.has(libName)) this.libs.set(libName, new Map());
      const lib = this.libs.get(libName);
      let count = 0;
      for (const item of findAll(top, "symbol")) {
        const s = readSymbol(item, libName);
        lib.set(s.name, s);
        count++;
      }
      for (const s of lib.values()) {
        if (!s.extends) continue;
        const base = lib.get(s.extends);
        if (base) { s.graphics = base.graphics; s.pins = base.pins; s.pinNamesHidden = base.pinNamesHidden; s.pinNumbersHidden = base.pinNumbersHidden; }
      }
      return count;
    }

    get(libId) {
      if (!libId || typeof libId !== "string") return null;
      const [lib, name] = libId.includes(":") ? libId.split(":") : [null, libId];
      if (lib) return this.libs.get(lib)?.get(name) || null;
      for (const l of this.libs.values()) if (l.has(name)) return l.get(name);
      return null;
    }

    summary() {
      return [...this.libs.entries()].map(([name, map]) => ({ name, count: map.size, symbols: [...map.keys()] }));
    }
  }

  // ------------------------------------------------------------------ geometry

  /** Pin body end: the tip plus the pin length along its angle (Y-up). */
  function pinBodyEnd(pin) {
    const a = (pin.angle * Math.PI) / 180;
    return [pin.x + Math.cos(a) * pin.length, pin.y + Math.sin(a) * pin.length];
  }

  /** Bounds of the drawn body (graphics only), Y-up. */
  function bodyBounds(sym) {
    const b = { x1: Infinity, y1: Infinity, x2: -Infinity, y2: -Infinity };
    const add = (x, y) => { b.x1 = Math.min(b.x1, x); b.y1 = Math.min(b.y1, y); b.x2 = Math.max(b.x2, x); b.y2 = Math.max(b.y2, y); };
    for (const g of sym.graphics) {
      if (g.type === "rect") { add(g.x1, g.y1); add(g.x2, g.y2); }
      else if (g.type === "polyline" || g.type === "bezier") g.pts.forEach(([x, y]) => add(x, y));
      else if (g.type === "circle") { add(g.cx - g.r, g.cy - g.r); add(g.cx + g.r, g.cy + g.r); }
      else if (g.type === "arc") { arcPoints(g).forEach(([x, y]) => add(x, y)); }
      else if (g.type === "text") add(g.x, g.y);
    }
    if (b.x1 === Infinity) {
      for (const p of sym.pins) { const [x, y] = pinBodyEnd(p); add(x, y); }
    }
    if (b.x1 === Infinity) return { x1: 0, y1: 0, x2: 0, y2: 0 };
    return b;
  }

  /** Circle through three points; used to draw and bound arcs. */
  function arcCircle(g) {
    const [ax, ay] = g.start, [bx, by] = g.mid, [cx, cy] = g.end;
    const d = 2 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by));
    if (Math.abs(d) < 1e-9) return null;
    const ux = ((ax * ax + ay * ay) * (by - cy) + (bx * bx + by * by) * (cy - ay) + (cx * cx + cy * cy) * (ay - by)) / d;
    const uy = ((ax * ax + ay * ay) * (cx - bx) + (bx * bx + by * by) * (ax - cx) + (cx * cx + cy * cy) * (bx - ax)) / d;
    return { x: ux, y: uy, r: Math.hypot(ax - ux, ay - uy) };
  }
  function arcPoints(g, steps = 12) {
    const c = arcCircle(g);
    if (!c) return [g.start, g.end];
    const a0 = Math.atan2(g.start[1] - c.y, g.start[0] - c.x);
    const am = Math.atan2(g.mid[1] - c.y, g.mid[0] - c.x);
    const a1 = Math.atan2(g.end[1] - c.y, g.end[0] - c.x);
    const norm = (a) => ((a % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI);
    let sweep = norm(a1 - a0);
    if (norm(am - a0) > sweep) sweep -= 2 * Math.PI;
    const out = [];
    for (let i = 0; i <= steps; i++) {
      const a = a0 + (sweep * i) / steps;
      out.push([c.x + c.r * Math.cos(a), c.y + c.r * Math.sin(a)]);
    }
    return out;
  }

  return { parseSexpr, Library, bodyBounds, pinBodyEnd, arcCircle, arcPoints, MM_TO_MIL };
});
