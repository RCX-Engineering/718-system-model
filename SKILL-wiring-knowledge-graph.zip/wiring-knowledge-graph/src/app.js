/* ============================================================================
 * Viewer application
 *
 * Wires the engine to the page: reads the embedded graph, rules and KiCad
 * libraries; re-runs parse -> scene -> layout -> render whenever any of them
 * changes; and provides pan/zoom, net highlighting, the inspector, the
 * source and rules editors, file import, revisions and diagnostics.
 * ========================================================================== */

(function () {
  "use strict";

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
  const esc = (s) => String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

  // ------------------------------------------------------------------ persistent per-viewer drafts

  const store = {
    get(key) { try { return localStorage.getItem(key); } catch { return null; } },
    set(key, value) { try { localStorage.setItem(key, value); } catch { /* storage unavailable */ } },
    del(key) { try { localStorage.removeItem(key); } catch { /* storage unavailable */ } },
  };

  function hash(text) {
    let h = 0x811c9dc5;
    for (let i = 0; i < text.length; i++) { h ^= text.charCodeAt(i); h = Math.imul(h, 0x01000193); }
    return (h >>> 0).toString(16).padStart(8, "0").slice(0, 7);
  }

  /** JSON with short arrays and small objects kept on one line, so the rules stay readable. */
  function compactJson(value, indent = "") {
    const inner = indent + "  ";
    if (Array.isArray(value)) {
      const flat = JSON.stringify(value);
      if (flat.length <= 96 && value.every((v) => typeof v !== "object" || v === null)) return flat.replace(/","/g, "\", \"");
      return "[\n" + value.map((v) => inner + compactJson(v, inner)).join(",\n") + "\n" + indent + "]";
    }
    if (value && typeof value === "object") {
      const flat = JSON.stringify(value);
      if (flat.length <= 88 && !Object.values(value).some((v) => v && typeof v === "object" && !Array.isArray(v))) {
        return "{ " + Object.entries(value).map(([k, v]) => `${JSON.stringify(k)}: ${compactJson(v, inner)}`).join(", ") + " }";
      }
      return "{\n" + Object.entries(value).map(([k, v]) => `${inner}${JSON.stringify(k)}: ${compactJson(v, inner)}`).join(",\n") + "\n" + indent + "}";
    }
    return JSON.stringify(value);
  }

  // ------------------------------------------------------------------ state

  const pristinePage = "<!doctype html>\n" + document.documentElement.outerHTML;
  const embedded = {
    source: $("#graph-source").textContent,
    name: $("#graph-source").dataset.name || "embedded graph",
    rules: $("#rules-profile").textContent,
    libs: $$('script[type="application/x-kicad-sym"]').map((el) => ({ name: el.dataset.library, text: el.textContent })),
  };
  const draftKey = `kg-viewer:draft:${hash(embedded.source)}`;
  // Display options and configuration are remembered per embedded graph, so a page opens with the
  // defaults its graph and the viewer declare, not with choices made in another page.
  const optionsKey = `kg-viewer:options:${hash(embedded.source)}`;

  const state = {
    source: embedded.source,
    sourceName: embedded.name,
    rulesText: compactJson(JSON.parse(embedded.rules)),
    extraLibs: [],
    options: { physical: false, wireColors: "physical", showUnconnected: false, netLabels: true, wireTags: false, pairs: true },
    library: null,
    result: null,
    scene: null,
    layout: null,
    view: null,
    selection: null,
    focus: null,       // { label, ids: graph node ids, sourceHash } while one net or bus is shown alone
    runId: 0,
    parseDiagnostics: [],
    ruleError: null,
  };

  const savedOptions = store.get(optionsKey);
  if (savedOptions) { try { Object.assign(state.options, JSON.parse(savedOptions)); } catch { /* ignore */ } }
  const draft = store.get(draftKey);
  if (draft) {
    try {
      const d = JSON.parse(draft);
      if (d.source) { state.source = d.source; state.sourceName = d.name || state.sourceName; }
      if (d.rules) state.rulesText = d.rules;
    } catch { /* ignore a damaged draft */ }
  }

  // ------------------------------------------------------------------ text measurement

  const measureCtx = document.createElement("canvas").getContext("2d");
  const FONT_STACK = '"IBM Plex Mono", ui-monospace, "SFMono-Regular", Menlo, Consolas, monospace';
  const widthCache = new Map();
  function measure(text, size) {
    const key = size + "|" + text;
    if (widthCache.has(key)) return widthCache.get(key);
    measureCtx.font = `${size}px ${FONT_STACK}`;
    const w = measureCtx.measureText(String(text)).width;
    widthCache.set(key, w);
    return w;
  }

  // ------------------------------------------------------------------ libraries

  function buildLibrary() {
    const lib = new KGKicad.Library();
    for (const l of [...embedded.libs, ...state.extraLibs]) {
      try { lib.addText(l.name, l.text); }
      catch (err) { toast(`${l.name}: ${err.message}`, "error"); }
    }
    return lib;
  }

  // ------------------------------------------------------------------ pipeline

  // ELK runs in a worker where the page allows one, so the page stays live through a long
  // layout and a layout can be stopped at once; otherwise it runs in the page.
  let elk = null, elkInWorker = false;
  async function ensureElk() {
    if (elk) return elk;
    const start = Date.now();
    while (typeof ELK === "undefined") {
      if (Date.now() - start > 12000) throw new Error("The layout engine (elkjs) did not start in this browser. Reload the page.");
      await new Promise((r) => setTimeout(r, 60));
    }
    const worker = await workerElk();
    elk = worker || new ELK();
    elkInWorker = !!worker;
    return elk;
  }

  /** The page's own copy of elkjs started in a worker, or null where workers are not allowed. */
  let workerUrl = null;
  async function workerElk() {
    const text = document.getElementById("elk-source")?.textContent;
    if (!text || typeof Worker === "undefined" || typeof Blob === "undefined") return null;
    try {
      // The bundle's worker half listens for layouts once the bundle is first used inside a worker.
      workerUrl = workerUrl || URL.createObjectURL(new Blob([text, "\n;try { new self.ELK(); } catch (e) { /* the worker half is now listening */ }\n"], { type: "text/javascript" }));
      const engine = new ELK({ workerFactory: () => new Worker(workerUrl) });
      // A worker the page may not start never answers; a one-node layout proves this one runs.
      const probe = engine.layout({ id: "probe", children: [{ id: "n", width: 10, height: 10 }], edges: [] }).then(() => true, () => false);
      const ok = await Promise.race([probe, new Promise((r) => setTimeout(() => r(false), 5000))]);
      if (ok) return engine;
      try { engine.terminateWorker(); } catch { /* already gone */ }
    } catch { /* workers refused: lay out in the page */ }
    return null;
  }

  /** Stop a layout running in the worker; the next layout starts a fresh one. */
  function stopElk() {
    if (!elk || !elkInWorker) return;
    try { elk.terminateWorker(); } catch { /* already gone */ }
    elk = null;
  }

  function parseRules() {
    try {
      const rules = JSON.parse(state.rulesText);
      state.ruleError = null;
      return rules;
    } catch (err) {
      state.ruleError = err.message;
      return null;
    }
  }

  // A run stops when another starts (state.runId moves on): each stage checks before it begins.
  const STOPPED = Symbol("stopped");

  /** Let the page paint, then continue. */
  const breathe = () => new Promise((resolve) => {
    let done = false;
    const go = () => { if (!done) { done = true; setTimeout(resolve, 0); } };
    requestAnimationFrame(go);
    setTimeout(go, 60);   // a hidden page paints no frames
  });

  async function run({ relayout = true } = {}) {
    const id = ++state.runId;
    const live = () => { if (id !== state.runId) throw STOPPED; };
    try {
      if (relayout || !state.scene) {
        // A layout still running for a view no longer wanted is stopped, not waited for.
        if (state.layingOut) { stopElk(); state.layingOut = 0; }
        const rules = parseRules() || JSON.parse(embedded.rules);
        loading.begin(id);
        const stage = async (name) => { live(); loading.stage(name); await breathe(); live(); };
        await stage("read");
        const h = hash(state.source);
        if (!state.result || state.resultHash !== h) { state.result = KGCypher.load(state.source); state.resultHash = h; state.whole = null; }
        // A focus names graph nodes by id, so it lapses when the graph text changes.
        if (state.focus && state.focus.sourceHash !== h) state.focus = null;
        state.sheets = KGScene.sheetsOf(state.result.graph, rules);
        state.scope = validScope(state.scope, rules);
        loading.title();
        renderScope();
        renderFocusBar();
        renderUnitPick(rules);
        await stage("build");
        // A focus shows its nets across the whole graph; otherwise the chosen view.
        const view = state.focus ? { graph: KGScene.subgraph(state.result.graph, state.focus.ids, rules), netNames: state.focus.netNames } : scopeGraph(rules);
        const scene = KGScene.buildScene(view.graph, rules, state.library, { showUnconnected: state.options.showUnconnected, physical: state.options.physical, variants: state.options.variants || {}, pairs: state.options.pairs !== false, outsideNetNames: view.netNames, partial: !!view.partial });
        const wires = wireCount(scene);
        loading.size(scene, wires);
        const engine = await ensureElk();
        live();
        state.layingOut = id;
        const layout = await KGLayout.layoutScene(scene, engine, { measure, physical: state.options.physical, progress: stage });
        state.layingOut = 0;
        await stage("draw");
        state.scene = scene;
        state.layout = layout;
        state.tables = KGTables.buildTables(scene, scene.graph);
        state.checks = null;
        const pairToggle = document.getElementById("opt-pairs");
        if (pairToggle) pairToggle.closest("label").hidden = !scene.hasPairs;
        // What is drawn now; stopping a later run returns to it.
        state.shown = { scope: state.scope, focus: state.focus, unit: state.unit, variants: { ...(state.options.variants || {}) } };
        loading.learn(wires);
      }
      renderVariantPicks();
      draw();
      renderTables();
      renderIssues();
      renderStats();
      renderSymbolsPane();
      renderModelPane();
      if (state.selection) inspect(state.selection, { keep: true });
      else renderOverview();
      loading.end(id);
      $("#empty-view").hidden = true;
      // The drawing is shown first; its checks follow.
      if (!state.checks) {
        setStatus("busy", "Checking the drawing…");
        await breathe();
        live();
        state.checks = KGVerify.run(state.scene, state.layout, { measure });
        renderIssues();
      }
      setStatus("ok", "");
    } catch (err) {
      if (err === STOPPED || id !== state.runId) return;
      if (state.layingOut === id) state.layingOut = 0;
      loading.end(id);
      console.error(err);
      setStatus("error", err.message || String(err));
    }
  }

  /** Conductors in a scene: every drawn connection but mates and joins. */
  const wireCount = (scene) => scene.connections.filter((c) => c.style !== "mate" && c.style !== "join").length;

  // ------------------------------------------------------------------ loading view
  // Shown while a view is read, laid out and drawn: its size, each stage as it begins, the time
  // so far against an estimate from this browser's own pace, and a way to stop. It fades in only
  // when drawing takes more than a moment.

  const STAGES = [
    ["read", "Reading the graph"],
    ["build", "Choosing what to draw"],
    ["place", "Placing parts"],
    ["route", "Routing wires"],
    ["separate", "Separating wires that run side by side"],
    ["draw", "Drawing"],
  ];
  // Drawing time grows a little faster than the number of conductors drawn.
  const PACE_POWER = 1.15;
  const fmtSec = (s) => (s < 10 ? `${s.toFixed(1)} s` : s < 90 ? `${Math.round(s)} s` : `${Math.floor(s / 60)} min ${String(Math.round(s % 60)).padStart(2, "0")} s`);
  const loading = {
    id: 0, t0: 0, timer: null, estimate: 0,
    pace: (() => { const p = +store.get("kg-viewer:pace"); return p > 0 && p < 1000 ? p : 3; })(),
    estimateFor(wires) { return this.pace * Math.pow(Math.max(1, wires), PACE_POWER); },
    begin(id) {
      this.id = id; this.t0 = performance.now(); this.estimate = 0;
      this.title();
      $("#loading-size").textContent = "";
      $("#loading-stages").innerHTML = STAGES.map(([k, t]) => `<li data-stage="${k}">${esc(t)}</li>`).join("");
      $("#loading-bar").style.width = "0";
      $("#loading").hidden = false;
      clearInterval(this.timer);
      this.timer = setInterval(() => this.tick(), 250);
      this.tick();
    },
    title() { $("#loading-title").textContent = `Drawing ${viewLabel()}`; },
    stage(name) {
      let before = true;
      for (const li of $$("#loading-stages li")) {
        const now = li.dataset.stage === name;
        li.className = now ? "now" : before ? "done" : "";
        if (now) before = false;
      }
      this.tick();
    },
    size(scene, wires) {
      this.estimate = this.estimateFor(wires);
      $("#loading-size").textContent = `${wires.toLocaleString()} wires · ${scene.symbols.size.toLocaleString()} symbols`;
      this.tick();
    },
    tick() {
      const s = (performance.now() - this.t0) / 1000, est = this.estimate / 1000;
      $("#loading-time").textContent = est >= 2 ? `${fmtSec(s)} of about ${fmtSec(est)}` : fmtSec(s);
      $("#loading-bar").style.width = est ? `${Math.min(95, (s / est) * 100)}%` : "0";
    },
    // Each finished view refines this browser's pace; small views say too little to count.
    learn(wires) {
      const ms = performance.now() - this.t0;
      if (wires < 40 || ms < 300) return;
      this.pace = 0.5 * this.pace + 0.5 * (ms / Math.pow(wires, PACE_POWER));
      store.set("kg-viewer:pace", String(this.pace));
    },
    end(id) {
      if (id !== undefined && id !== this.id) return;
      clearInterval(this.timer);
      this.timer = null;
      $("#loading").hidden = true;
    },
  };

  /** Stop drawing: the view that was showing stays, with the choices that drew it. */
  function stopDrawing() {
    state.runId++;
    stopElk();
    state.layingOut = 0;
    loading.end();
    setStatus("ok", "");
    const back = state.shown;
    if (back) {
      state.scope = back.scope; state.focus = back.focus; state.unit = back.unit;
      state.options.variants = { ...back.variants };
      store.set(optionsKey, JSON.stringify(state.options));
      renderScope(); renderFocusBar(); renderVariantPicks();
      renderUnitPick(parseRules() || JSON.parse(embedded.rules));
      toast("Stopped. The view that was showing is kept.");
    } else {
      const ev = $("#empty-view");
      ev.textContent = "Drawing stopped. Choose a smaller view to draw.";
      ev.hidden = false;
    }
  }

  function graphTitle() {
    const named = state.scene?.model?.dataset?.props?.name;
    if (named) return String(named);
    const m = /^\s*\/\/\s*(.+)$/m.exec(state.source);
    return m ? m[1].trim() : state.sourceName;
  }

  function draw() {
    const { scene, layout, result } = state;
    const meta = {
      // the title block names the view drawn, as a sheet title names its sheet
      title: state.focus || state.scope?.kind !== "all" ? `${graphTitle()} · ${viewLabel()}` : graphTitle(),
      source: state.sourceName,
      revision: `rev ${hash(state.source)}`,
      counts: `${result.graph.nodes.size} nodes · ${result.graph.rels.size} relationships`,
      libraries: `KiCad ${[...state.library.libs.keys()].join(", ")}`,
    };
    const out = KGRender.renderSvg(scene, layout, meta, state.options, measure);
    state.pairFallbacks = out.pairFallbacks || [];
    const host = $("#sheet");
    const keepView = state.view && state.lastFrameKey === `${Math.round(out.viewBox.w)}x${Math.round(out.viewBox.h)}`;
    host.innerHTML = out.svg;
    state.svg = host.querySelector("svg");
    state.frame = out;
    state.lastFrameKey = `${Math.round(out.viewBox.w)}x${Math.round(out.viewBox.h)}`;
    state.svg.classList.toggle("kicad-wires", state.options.wireColors !== "physical");
    if (keepView) applyView(); else fit();
    if (state.selection) markSelection();
  }

  // ------------------------------------------------------------------ pan and zoom

  /** Fit the whole drawing in the canvas. */
  function fit() {
    const box = state.frame.content;
    state.view = { x: box.x, y: box.y, w: box.w, h: box.h };
    applyView();
  }

  function applyView() {
    if (!state.svg || !state.view) return;
    const host = $("#sheet");
    const rect = host.getBoundingClientRect();
    const aspect = rect.width / Math.max(1, rect.height);
    let { x, y, w, h } = state.view;
    if (w / h > aspect) { const nh = w / aspect; y -= (nh - h) / 2; h = nh; }
    else { const nw = h * aspect; x -= (nw - w) / 2; w = nw; }
    state.view = { x, y, w, h };
    state.svg.setAttribute("viewBox", `${x} ${y} ${w} ${h}`);
    $("#zoom-readout").textContent = `${Math.round((state.frame.content.w / w) * 100)}%`;
  }

  function zoomAt(factor, cx, cy) {
    const v = state.view;
    const rect = $("#sheet").getBoundingClientRect();
    const px = v.x + ((cx - rect.left) / rect.width) * v.w;
    const py = v.y + ((cy - rect.top) / rect.height) * v.h;
    const nw = Math.min(Math.max(v.w / factor, 600), state.frame.viewBox.w * 4);
    const k = nw / v.w;
    state.view = { x: px - (px - v.x) * k, y: py - (py - v.y) * k, w: nw, h: v.h * k };
    applyView();
  }

  function zoomTo(x, y, w, h) {
    const pad = Math.max(w, h) * 0.6 + 600;
    state.view = { x: x - pad, y: y - pad, w: w + 2 * pad, h: h + 2 * pad };
    applyView();
  }

  function setupCanvas() {
    const host = $("#sheet");
    const pointers = new Map();
    let drag = null, pinch = null, moved = false;

    host.addEventListener("wheel", (e) => {
      if (!state.view) return;
      e.preventDefault();
      const factor = Math.exp(-e.deltaY * (e.deltaMode === 1 ? 0.05 : 0.0016));
      zoomAt(factor, e.clientX, e.clientY);
    }, { passive: false });

    host.addEventListener("pointerdown", (e) => {
      if (!state.view) return;
      pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      host.setPointerCapture(e.pointerId);
      moved = false;
      if (pointers.size === 1) drag = { x: e.clientX, y: e.clientY, view: { ...state.view } };
      else if (pointers.size === 2) {
        const [a, b] = [...pointers.values()];
        pinch = { d: Math.hypot(a.x - b.x, a.y - b.y), view: { ...state.view }, cx: (a.x + b.x) / 2, cy: (a.y + b.y) / 2 };
        drag = null;
      }
    });
    host.addEventListener("pointermove", (e) => {
      if (!pointers.has(e.pointerId)) { hover(e); return; }
      pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      const rect = host.getBoundingClientRect();
      if (drag) {
        const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
        if (Math.abs(dx) + Math.abs(dy) > 3) { moved = true; hidePop(); }
        const k = drag.view.w / rect.width;
        state.view = { ...drag.view, x: drag.view.x - dx * k, y: drag.view.y - dy * k };
        applyView();
        host.classList.add("panning");
      } else if (pinch && pointers.size === 2) {
        moved = true;
        const [a, b] = [...pointers.values()];
        const d = Math.hypot(a.x - b.x, a.y - b.y);
        state.view = { ...pinch.view };
        zoomAt(d / pinch.d, pinch.cx, pinch.cy);
      }
    });
    const end = (e) => {
      pointers.delete(e.pointerId);
      host.classList.remove("panning");
      if (pointers.size < 2) pinch = null;
      if (pointers.size === 0) {
        if (!moved && e.type === "pointerup") click(e);
        drag = null;
      }
    };
    host.addEventListener("pointerup", end);
    host.addEventListener("pointercancel", end);
    host.addEventListener("pointerleave", () => clearHover());
    // Double-clicking a wire, pin, splice joint or cable shows its net (a cable: its nets) alone.
    host.addEventListener("dblclick", (e) => {
      const t = document.elementFromPoint(e.clientX, e.clientY) || e.target;
      const nets = netsAt(t);
      if (nets) { hidePop(); const v = preferredView(nets); enterFocus(v.nets, v.label); return; }
      if (!t.closest("[data-sym],[data-conn],[data-annotation]")) fit();
    });
    host.addEventListener("wheel", () => hidePop(), { passive: true });
    window.addEventListener("resize", () => applyView());
    new ResizeObserver(() => applyView()).observe(host);

    $("#fit").addEventListener("click", () => fit());
    $("#zoom-in").addEventListener("click", () => { const r = host.getBoundingClientRect(); zoomAt(1.4, r.left + r.width / 2, r.top + r.height / 2); });
    $("#zoom-out").addEventListener("click", () => { const r = host.getBoundingClientRect(); zoomAt(1 / 1.4, r.left + r.width / 2, r.top + r.height / 2); });
    host.addEventListener("keydown", (e) => {
      if (e.key === "0") fit();
      if (e.key === "+" || e.key === "=") $("#zoom-in").click();
      if (e.key === "-") $("#zoom-out").click();
      if (e.key === "Escape") {
        hidePop();
        if (state.selection) { state.selection = null; markSelection(); renderOverview(); }
        else if (state.focus) exitFocus();
      }
    });

    // Files dropped on the drawing.
    host.addEventListener("dragover", (e) => { e.preventDefault(); host.classList.add("drop"); });
    host.addEventListener("dragleave", () => host.classList.remove("drop"));
    host.addEventListener("drop", (e) => {
      e.preventDefault();
      host.classList.remove("drop");
      for (const file of e.dataTransfer.files) importFile(file, e.shiftKey ? "append" : "replace");
    });
  }

  // ------------------------------------------------------------------ hover and selection

  function highlightNet(net) {
    if (!state.svg) return;
    $$(".hl", state.svg).forEach((x) => x.classList.remove("hl"));
    state.svg.classList.toggle("dimmed", !!net);
    if (!net) return;
    if (net.startsWith("conn|")) {
      // One conductor alone: its own run and the two contacts it ends on.
      const c = state.scene?.connections.find((x) => x.id === net.slice(5));
      if (!c) return;
      $$(`[data-conn="${CSS.escape(c.id)}"]`, state.svg).forEach((x) => {
        x.classList.add("hl");
        // a strand of a twisted pair or cable: its jacket stays lit around it
        x.closest(".bus")?.classList.add("hl");
      });
      for (const end of [c.a, c.b]) {
        if (end?.symbolId) $$(`.pin[data-sym="${CSS.escape(end.symbolId)}"][data-contact="${CSS.escape(end.key)}"]`, state.svg).forEach((x) => x.classList.add("hl"));
      }
      return;
    }
    const bus = busOf(net);
    if (bus) {
      // A bus lights every net it carries, every conductor on them and every cable holding them.
      const keys = new Set(bus.members.flatMap((m) => m.nets.map((n) => n.key)));
      for (const k of keys) $$(`[data-net="${CSS.escape(k)}"]`, state.svg).forEach((x) => x.classList.add("hl"));
      for (const b of state.scene?.bundles || []) {
        if (b.connections.some((c) => keys.has(c.net?.key))) $$(`[data-bundle="${CSS.escape(b.id)}"]`, state.svg).forEach((x) => x.classList.add("hl"));
      }
      return;
    }
    const cable = cableOf(net);
    if (cable) {
      $$(`[data-bundle="${CSS.escape(cable.id)}"]`, state.svg).forEach((x) => x.classList.add("hl"));
      for (const c of cable.connections) $$(`[data-conn="${CSS.escape(c.id)}"]`, state.svg).forEach((x) => x.classList.add("hl"));
    } else {
      $$(`[data-net="${CSS.escape(net)}"]`, state.svg).forEach((x) => x.classList.add("hl"));
      // A cable carrying this net stays lit too.
      for (const b of state.scene?.bundles || []) {
        if (b.connections.some((c) => c.net?.key === net)) $$(`[data-bundle="${CSS.escape(b.id)}"]`, state.svg).forEach((x) => x.classList.add("hl"));
      }
    }
  }
  /** Highlight keys are net keys, or "cable|<bundle id>" for every conductor in one jacket. */
  /** A bus highlight key is "bus|<bus id>". */
  function busOf(key) {
    if (!key || !key.startsWith("bus|") || !state.scene) return null;
    return (state.scene.buses || []).find((b) => b.id === key.slice(4)) || null;
  }
  function cableOf(key) {
    if (!key || !key.startsWith("cable|") || !state.scene) return null;
    return (state.scene.bundles || []).find((b) => b.id === key.slice(6)) || null;
  }
  // Hovering marks only the conductor (or cable) under the pointer; tracing its net is a click away.
  let hoverEl = null;
  function hover(e) {
    const el = e.target.closest?.("[data-conn]") || e.target.closest?.("[data-bundle]") || null;
    if (el === hoverEl) return;
    hoverEl?.classList.remove("hover");
    hoverEl = el;
    el?.classList.add("hover");
  }
  /** Leaving the drawing (or the inspector's lists) restores the selection's highlight. */
  function clearHover() {
    hoverEl?.classList.remove("hover");
    hoverEl = null;
    highlightNet(selectedNet());
  }
  /**
   * What clicking a conductor again lights, in turn: the conductor, its net, the cable or pair
   * it runs in, the bus its net belongs to; one more click clears the selection.
   */
  /** What a selected conductor lights now, and what clicking it again lights. */
  function litLine(sel) {
    const levels = connLevels(sel.id);
    const name = (k) => {
      if (k.startsWith("conn|")) return "this conductor";
      if (k.startsWith("cable|")) { const b = (state.scene.bundles || []).find((x) => x.id === k.slice(6)); return `${b?.style === "pair" ? "the twisted pair" : "the cable"} ${b?.name || ""}`.trim(); }
      if (k.startsWith("bus|")) { const b = busOf(k); return `the bus ${b?.name || ""}`.trim(); }
      return `its net ${[...state.scene.nets.values()].find((x) => x.key === k)?.name || ""}`.trim();
    };
    const i = sel.level || 0;
    const next = levels[i + 1] ? `click it again to light ${esc(name(levels[i + 1]))}` : "click it again to clear";
    return `<p class="small muted">Lit: ${esc(name(levels[i] || ""))} · ${next}</p>`;
  }
  function connLevels(id) {
    const c = state.scene?.connections.find((x) => x.id === id);
    if (!c) return [];
    const levels = [`conn|${c.id}`];
    if (c.net && c.net.connections.length > 1) levels.push(c.net.key);
    const cable = (state.scene.bundles || []).find((b) => b.connections.includes(c));
    if (cable) levels.push(`cable|${cable.id}`);
    for (const { bus } of c.net?.buses || []) levels.push(`bus|${bus.id}`);
    // a step that lights no more conductors than the one before it is skipped
    const lit = (k) => {
      if (k.startsWith("conn|")) return [c.id];
      if (k.startsWith("cable|")) return ((state.scene.bundles || []).find((b) => b.id === k.slice(6))?.connections || []).map((x) => x.id);
      if (k.startsWith("bus|")) return (busOf(k)?.members || []).flatMap((m) => m.nets.flatMap((n) => n.connections.map((x) => x.id)));
      return c.net.connections.map((x) => x.id);
    };
    const out = [];
    let seen = "";
    for (const k of new Set(levels)) {
      const sig = [...new Set(lit(k))].sort().join(",");
      if (sig !== seen) { out.push(k); seen = sig; }
    }
    return out;
  }
  function selectedNet() {
    const s = state.selection;
    if (!s || !state.scene) return null;
    if (s.type === "contact") return state.scene.symbols.get(s.sym)?.contacts.get(s.key)?.net?.key || null;
    if (s.type === "connection") return connLevels(s.id)[s.level || 0] || null;
    if (s.type === "cable") return `cable|${s.id}`;
    if (s.type === "bus") return `bus|${s.id}`;
    return null;
  }

  function click(e) {
    // Pointer capture retargets pointerup to the canvas, so find what is under the pointer.
    const t = document.elementFromPoint(e.clientX, e.clientY) || e.target;
    const pin = t.closest("[data-contact]");
    const conn = t.closest("[data-conn]");
    const ann = t.closest("[data-annotation]");
    const iface = t.closest("[data-iface]");
    const sym = t.closest("[data-sym]");
    const group = t.closest("[data-group]");
    const bus = t.closest("[data-bundle]");
    let sel = null;
    if (conn && !pin) {
      // the same conductor again: light the next wider thing it belongs to, then clear
      const s = state.selection;
      const level = s?.type === "connection" && s.id === conn.dataset.conn ? (s.level || 0) + 1 : 0;
      if (level >= connLevels(conn.dataset.conn).length) { hidePop(); clearSelection(); return; }
      sel = { type: "connection", id: conn.dataset.conn, level };
    }
    else if (bus) sel = { type: "cable", id: bus.dataset.bundle };
    else if (ann) sel = { type: "annotation", id: ann.dataset.annotation };
    else if (pin) sel = { type: "contact", sym: pin.dataset.sym, key: pin.dataset.contact };
    else if (iface) sel = { type: "interface", id: iface.dataset.iface };
    else if (sym) sel = { type: "symbol", id: sym.dataset.sym };
    else if (group) sel = { type: "group", id: group.dataset.group };
    if (sel) inspect(sel);
    else { state.selection = null; markSelection(); renderOverview(); }
    showPop(e, t);
  }

  // ------------------------------------------------------------------ one net or bus alone

  /** The scene nets under a drawing element: a wire's or pin's net, or every net in a cable. */
  function netsAt(t) {
    const scene = state.scene;
    if (!scene || !t?.closest) return null;
    // a conductor drawn inside a cable is that conductor; the cable is its jacket line
    const bundleEl = t.closest("[data-conn]") ? null : t.closest("[data-bundle]");
    if (bundleEl) {
      const b = (scene.bundles || []).find((x) => x.id === bundleEl.dataset.bundle);
      if (!b) return null;
      return cableView(b);
    }
    const pin = t.closest("[data-contact]");
    if (pin) {
      const c = scene.symbols.get(pin.dataset.sym)?.contacts.get(pin.dataset.contact);
      return c?.net ? { nets: [c.net], kind: "net", label: `net ${c.net.name}` } : null;
    }
    const conn = t.closest("[data-conn]");
    if (conn) {
      const cn = scene.connections.find((x) => x.id === conn.dataset.conn);
      return cn?.net ? { nets: [cn.net], kind: "net", label: `net ${cn.net.name}` } : null;
    }
    const netEl = t.closest("[data-net]");
    if (netEl) {
      const n = [...scene.nets.values()].find((x) => x.key === netEl.dataset.net);
      return n ? { nets: [n], kind: "net", label: `net ${n.name}` } : null;
    }
    return null;
  }

  /** The bus a net belongs to, as a view of all its lines (a CAN bus: its CAN_H and CAN_L nets). */
  function busNets(net) {
    const b = (net?.buses || [])[0];
    if (!b) return null;
    const roles = b.bus.members.map((m) => m.role).filter(Boolean);
    return { nets: b.bus.members.flatMap((m) => m.nets), kind: "bus", roles, label: `bus ${b.bus.name}`, name: b.bus.name, busId: b.bus.id };
  }

  /** A cable's nets; a twisted pair of one bus (a CAN pair) stands for that bus. */
  function cableView(b) {
    const nets = [...new Set(b.connections.map((c) => c.net).filter(Boolean))];
    const bus = nets.length ? busNets(nets[0]) : null;
    if (bus && nets.every((n) => bus.nets.includes(n))) return bus;
    return { nets, kind: b.style === "pair" ? "pair" : "cable", label: `${b.style === "pair" ? "twisted pair" : "cable"} ${b.name}` };
  }

  /** What a double-click shows: a line that belongs to a bus shows the whole bus, both lines together. */
  function preferredView(found) {
    const bus = found?.kind === "net" && found.nets.length === 1 ? busNets(found.nets[0]) : null;
    return bus || found;
  }

  /** Graph nodes that make up these nets: conductors, pins, splices (and a part with no pins). */
  const netNodeIds = (nets, scene = state.scene) => KGScene.netMemberIds(nets, scene);

  // ------------------------------------------------------------------ views
  // What is drawn: one class of connection across the whole graph (the profile's units.classes),
  // one or more systems together (the profile's sheets: the conductors that serve each, with
  // everything they end on), or the whole graph. The profile's views.open names the first view.
  // A focus (one net, bus or unit) is drawn alone over whichever view is chosen.

  /** A scene of the whole graph in the current configuration, kept while nothing it depends on changes. */
  function wholeScene(rules) {
    const key = `${state.resultHash}|${hash(state.rulesText)}|${JSON.stringify(state.options.variants || {})}`;
    if (state.whole?.key !== key) state.whole = { key, scene: KGScene.buildScene(state.result.graph, rules, state.library, { variants: state.options.variants || {}, pairs: true }) };
    return state.whole.scene;
  }

  const classNames = (rules) => (rules.units?.classes || []).map((c) => c.name);

  function openScope(rules) {
    const o = rules.views?.open;
    if (o?.class && classNames(rules).includes(o.class)) {
      // a class with nothing in this graph opens the whole graph instead
      const whole = wholeScene(rules);
      if ([...whole.nets.values()].some((n) => n.connections.length && KGScene.netClass(n, rules) === o.class)) return { kind: "class", cls: o.class };
    }
    const list = [].concat(o?.systems || []).filter((x) => state.sheets.includes(x));
    if (list.length) return { kind: "systems", list };
    if (rules.sheets?.open === "first" && state.sheets.length) return { kind: "systems", list: [state.sheets[0]] };
    return { kind: "all" };
  }

  function validScope(sc, rules) {
    if (sc?.kind === "class" && classNames(rules).includes(sc.cls)) return sc;
    if (sc?.kind === "systems") { const list = sc.list.filter((x) => state.sheets.includes(x)); if (list.length) return { kind: "systems", list }; }
    if (sc?.kind === "all") return sc;
    return openScope(rules);
  }

  function scopeLabel(sc) {
    if (!sc) return "";
    if (sc.kind === "class") return `${sc.cls} connections`;
    if (sc.kind === "systems") return sc.list.length <= 2 ? sc.list.join(" + ") : `${sc.list[0]} + ${sc.list.length - 1} more`;
    return "Whole graph";
  }

  const viewLabel = () => (state.focus ? state.focus.label : scopeLabel(state.scope));

  /** The graph a view draws, and what the scene needs to name nets cut at its edge. */
  function scopeGraph(rules) {
    const G = state.result.graph, sc = state.scope;
    if (sc.kind === "systems") {
      const ids = new Set();
      for (const x of sc.list) for (const i of KGScene.sheetIds(G, rules, x)) ids.add(i);
      return { graph: KGScene.subgraph(G, [...ids], rules), partial: true };
    }
    if (sc.kind === "class") {
      const v = KGScene.classView(G, rules, state.library, sc.cls, { scene: wholeScene(rules) });
      return { graph: KGScene.subgraph(G, v.ids, rules), netNames: v.netNames };
    }
    return { graph: G };
  }

  /** Conductors in each class and each system, and in all, from the whole graph as configured. */
  function scopeCounts(rules) {
    const whole = wholeScene(rules);
    const cls = new Map(), sys = new Map();
    let all = 0;
    whole.connections.forEach((c, i) => {
      if (c.style === "mate" || c.style === "join") return;
      all++;
      const k = c.net ? KGScene.netClass(c.net, rules) : null;
      if (k) cls.set(k, (cls.get(k) || 0) + 1);
      const owner = c.node || c.rel;
      if (owner && rules.sheets?.key) for (const x of KGScene.sheetValues(owner, rules)) { if (!sys.has(x)) sys.set(x, []); sys.get(x).push(i); }
    });
    return { cls, sys, all };
  }

  function renderScope() {
    const rules = parseRules() || JSON.parse(embedded.rules);
    const any = classNames(rules).length || (state.sheets || []).length > 1;
    $("#scope").hidden = !any;
    $("#scope-name").textContent = scopeLabel(state.scope);
  }

  // The chooser: one class, or systems ticked together, or everything; Show draws the choice.
  const chooser = { pick: null, counts: null };

  function openChooser() {
    if (!state.result) return;
    const rules = parseRules() || JSON.parse(embedded.rules);
    chooser.pick = JSON.parse(JSON.stringify(state.scope));
    chooser.counts = scopeCounts(rules);
    const plural = (w) => (/s$/i.test(w) ? w : /y$/i.test(w) ? w.replace(/y$/i, "ies") : `${w}s`);
    const n = (k) => `${(k || 0).toLocaleString()} wires`;
    const row = (type, name, value, label, count, title = "") => `<label class="opt-row"${title ? ` title="${esc(title)}"` : ""}><input type="${type}" name="${name}" value="${esc(value)}"><span>${esc(label)}</span><span class="n">${n(count)}</span></label>`;
    const classes = classNames(rules), sysLabel = rules.sheets?.label || "System";
    const classRule = (c) => (rules.units?.classes || []).find((x) => x.name === c);
    const sysSet = (x) => chooser.counts.sys.get(x)?.length || 0;
    $("#scope-pop").innerHTML = `<div class="pop-body">
        ${classes.length ? `<h4>${esc(rules.views?.classHeading || "Connections across the whole graph")}</h4>
          ${classes.map((c) => row("radio", "scope-one", `class:${c}`, c, chooser.counts.cls.get(c), classRule(c)?.about || "")).join("")}` : ""}
        ${state.sheets.length > 1 ? `<h4>${esc(plural(sysLabel))}<span class="mini"><button type="button" class="link" data-act="all">All</button><button type="button" class="link" data-act="none">None</button></span></h4>
          <p class="pop-note">Tick one or more; they are drawn together.</p>
          ${state.sheets.map((x) => row("checkbox", "scope-sys", x, x, sysSet(x))).join("")}` : ""}
        <h4>Everything</h4>
        ${row("radio", "scope-one", "all", "Whole graph", chooser.counts.all)}
      </div>
      <div class="pop-foot"><span class="est" id="scope-est"></span><button class="btn" type="button" data-act="cancel">Cancel</button><button class="btn primary" type="button" data-act="show">Show</button></div>`;
    syncChooser();
    $("#scope-pop").hidden = false;
    $("#scope-btn").setAttribute("aria-expanded", "true");
    ($("#scope-pop input:checked") || $("#scope-pop input"))?.focus();
  }

  function closeChooser({ refocus = false } = {}) {
    $("#scope-pop").hidden = true;
    $("#scope-btn").setAttribute("aria-expanded", "false");
    if (refocus) $("#scope-btn").focus();
  }

  /** Tick what the pending choice holds, and say how large it is. */
  function syncChooser() {
    const p = chooser.pick;
    for (const el of $$("#scope-pop input")) {
      el.checked = el.name === "scope-sys" ? p.kind === "systems" && p.list.includes(el.value)
        : el.value === "all" ? p.kind === "all" : p.kind === "class" && el.value === `class:${p.cls}`;
    }
    const c = chooser.counts;
    let wires = 0;
    if (p.kind === "class") wires = c.cls.get(p.cls) || 0;
    else if (p.kind === "all") wires = c.all;
    else { const u = new Set(); for (const x of p.list) for (const i of c.sys.get(x) || []) u.add(i); wires = u.size; }
    const est = $("#scope-est"), show = $('#scope-pop [data-act="show"]');
    show.disabled = p.kind === "systems" && !p.list.length;
    if (show.disabled) { est.textContent = "Tick at least one."; est.className = "est"; return; }
    const secs = loading.estimateFor(wires) / 1000;
    est.className = `est${secs > 15 ? " large" : ""}`;
    est.textContent = secs > 15 ? `A large view: about ${fmtSec(secs)} to draw. It can be stopped while it draws.`
      : secs < 1.5 ? "Draws in a moment." : `About ${fmtSec(secs)} to draw.`;
  }

  /** Draw a view; systems drawn for another configuration switch to it, so none is empty. */
  function applyScope(sc) {
    state.scope = sc;
    state.focus = null;
    state.unit = null;
    state.selection = null;
    state.lastFrameKey = null;
    hidePop();
    if (sc.kind === "systems" && state.result) {
      const rules = parseRules() || JSON.parse(embedded.rules);
      let v = state.options.variants || {};
      for (const x of sc.list) v = KGScene.sheetChoices(state.result.graph, rules, x, v);
      state.options.variants = v;
      store.set(optionsKey, JSON.stringify(state.options));
    }
    return run({ relayout: true });
  }

  function setupScope() {
    $("#scope-btn").addEventListener("click", () => ($("#scope-pop").hidden ? openChooser() : closeChooser()));
    const pop = $("#scope-pop");
    pop.addEventListener("change", (e) => {
      const el = e.target;
      const p = chooser.pick;
      if (el.name === "scope-sys") {
        const list = p.kind === "systems" ? p.list.slice() : [];
        if (el.checked && !list.includes(el.value)) list.push(el.value);
        chooser.pick = { kind: "systems", list: el.checked ? list : list.filter((x) => x !== el.value) };
      } else if (el.value === "all") chooser.pick = { kind: "all" };
      else chooser.pick = { kind: "class", cls: el.value.slice(6) };
      syncChooser();
    });
    pop.addEventListener("click", (e) => {
      const act = e.target.closest("[data-act]")?.dataset.act;
      if (act === "all") { chooser.pick = { kind: "systems", list: state.sheets.slice() }; syncChooser(); }
      else if (act === "none") { chooser.pick = { kind: "systems", list: [] }; syncChooser(); }
      else if (act === "cancel") closeChooser({ refocus: true });
      else if (act === "show") {
        const p = chooser.pick;
        // systems keep the order they are listed in
        if (p.kind === "systems") p.list = state.sheets.filter((x) => p.list.includes(x));
        closeChooser({ refocus: true });
        applyScope(p);
      }
    });
    pop.addEventListener("keydown", (e) => { if (e.key === "Escape") { e.stopPropagation(); closeChooser({ refocus: true }); } });
    document.addEventListener("pointerdown", (e) => { if (!pop.hidden && !$("#scope").contains(e.target)) closeChooser(); });
    $("#loading-stop").addEventListener("click", () => stopDrawing());
  }

  // ------------------------------------------------------------------ units
  // A unit's connections: every net that reaches any contact of one part, drawn whole across the
  // graph (not cut at a system), optionally one class of them (the profile's units.classes).

  const ruleTest = (rule, props) => {
    for (const k of rule.keys || rule.netKeys || []) {
      const v = props?.[k];
      if (v === undefined || v === null) continue;
      const m = /^\/(.*)\/([a-z]*)$/.exec(rule.match || "");
      if (m ? new RegExp(m[1], m[2]).test(String(v)) : String(v) === String(rule.match)) return true;
    }
    return false;
  };

  function unitsOf(G, rules) {
    const S = rules.structure || {};
    const connRels = new Set(S.connectorRelationships || []);
    const owners = new Set([...G.rels.values()].filter((r) => connRels.has(r.type)).map((r) => r.start));
    const ex = rules.units?.exclude;
    const T = rules.text || {};
    const nameOf = (n) => String(T.nameKeys?.map((k) => n.props[k]).find((v) => v !== undefined) ?? n.props.id ?? n.id);
    return [...owners].map((id) => G.nodes.get(id)).filter((n) => n && !(ex && ruleTest(ex, n.props)))
      .map((n) => ({ id: n.id, key: String(n.props.id ?? n.id), name: nameOf(n), place: n.props.location }))
      .sort((a, b) => KGScene.compareNatural(a.name, b.name) || KGScene.compareNatural(a.key, b.key));
  }

  const classOfNet = (net, rules) => KGScene.netClass(net, rules);

  function renderUnitPick(rules) {
    const host = $("#unit-pick"), cls = $("#unit-class");
    if (!host || !state.result) return;
    const units = unitsOf(state.result.graph, rules);
    host.closest("label").hidden = !rules.units || units.length < 2;
    const sel = state.unit?.key || "";
    // the same name on several parts (one per configuration) is told apart by its id
    const dup = new Map(); for (const u of units) dup.set(u.name, (dup.get(u.name) || 0) + 1);
    host.innerHTML = `<option value="">—</option>` + units.map((u) => `<option value="${esc(u.key)}"${u.key === sel ? " selected" : ""}>${esc(u.name)}${dup.get(u.name) > 1 ? ` (${esc(u.key)})` : ""}</option>`).join("");
    const classes = (rules.units?.classes || []).map((c) => c.name);
    cls.closest("label").hidden = !state.unit;
    cls.innerHTML = `<option value="">All</option>` + classes.map((c) => `<option value="${esc(c)}"${c === state.unit?.cls ? " selected" : ""}>${esc(c)}</option>`).join("");
  }

  /** Show one unit's connections alone: its nets, whole, from a scene of the entire graph. */
  function enterUnit(key, cls) {
    if (!state.result) return;
    const rules = parseRules() || JSON.parse(embedded.rules);
    const node = [...state.result.graph.nodes.values()].find((n) => String(n.props.id ?? n.id) === key);
    if (!node) return;
    // a unit fitted only in another configuration switches to it, so its connections are drawn
    const V = rules.variants || {};
    const listed = (V.memberKeys || []).map((k) => node.props[k]).find((v) => v !== undefined);
    if (listed) {
      const mine = [].concat(listed).map(String);
      const { points } = KGScene.configure(state.result.graph, rules, state.options.variants || {});
      const next = { ...(state.options.variants || {}) };
      for (const pt of points) {
        const opts = pt.options.map((o) => String(o.id)).filter((o) => mine.includes(o));
        if (opts.length && !opts.includes(String(pt.selected))) next[pt.id] = opts[0];
      }
      state.options.variants = next;
      store.set(optionsKey, JSON.stringify(state.options));
    }
    const sc = wholeScene(rules);
    const syms = [...sc.symbols.values()].filter((s) => s.node.id === node.id);
    const nets = [...new Set(syms.flatMap((s) => [...s.contacts.values()].map((c) => c.net)).filter((n) => n && n.connections.length))]
      .filter((n) => !cls || classOfNet(n, rules) === cls);
    const name = syms[0]?.name || String(node.props.name ?? key);
    state.unit = { key, cls: cls || "" };
    const netNames = new Map();
    for (const s of sc.symbols.values()) for (const c of s.contacts.values()) if (c.pin && c.net) netNames.set(c.pin.id, c.net.name);
    const ids = new Set(netNodeIds(nets, sc));
    ids.add(node.id);
    state.focus = { label: `${cls ? `${cls.toLowerCase()} ` : ""}connections of ${name}${nets.length ? "" : " (none in this configuration)"}`, ids: [...ids], netNames, sourceHash: hash(state.source), unit: true };
    state.lastFrameKey = null;
    state.selection = null;
    return run();
  }

  function setupUnitPick() {
    const host = $("#unit-pick"), cls = $("#unit-class");
    if (!host) return;
    host.addEventListener("change", () => { if (host.value) enterUnit(host.value, cls.value); else { state.unit = null; exitFocus(); } });
    cls.addEventListener("change", () => { if (state.unit) enterUnit(state.unit.key, cls.value); });
  }

  function enterFocus(nets, label) {
    if (!nets?.length) return;
    // Pins kept only to complete a free connector are named by their net in the whole drawing.
    const netNames = new Map(state.focus?.netNames || []);
    for (const sym of state.scene.symbols.values()) for (const c of sym.contacts.values()) if (c.pin && c.net && !c.net.outside) netNames.set(c.pin.id, c.net.name);
    state.focus = { label, ids: netNodeIds(nets), netNames, sourceHash: hash(state.source) };
    state.lastFrameKey = null;
    return run();
  }

  function exitFocus() {
    state.focus = null;
    state.unit = null;
    state.lastFrameKey = null;
    hidePop();
    return run();
  }

  function renderFocusBar() {
    const bar = $("#focus-bar");
    if (!bar) return;
    bar.hidden = !state.focus;
    if (state.focus) {
      $("#focus-text").textContent = `Showing ${state.focus.label} alone`;
      $("#focus-exit").textContent = `Back to ${scopeLabel(state.scope)}`;
    }
  }

  /** A small card at the pointer with what can be shown alone from the clicked element. */
  function showPop(e, t) {
    const pop = $("#net-pop");
    if (!pop) return;
    const found = netsAt(t);
    if (!found) { hidePop(); return; }
    const bus = found.kind === "bus" ? found : found.nets.length === 1 ? busNets(found.nets[0]) : null;
    const conductors = found.nets.reduce((a, n) => a + n.connections.length, 0);
    // Each action either redraws what it names alone, or (for a bus) lights it in place.
    const alone = (v) => () => enterFocus(v.nets, v.label);
    const actions = bus
      ? [[`Show ${bus.name} alone${bus.roles.length > 1 ? ` (${bus.roles.join(" + ")})` : ""}`, alone(bus)],
         [`Highlight ${bus.name}`, () => highlightBus(bus.busId)],
         ...(found.kind === "net" ? [["Show this line only", alone(found)]] : [])]
      : [[`Show this ${found.kind} alone`, alone(found)]];
    state.popActions = actions.map(([, run]) => run);
    pop.innerHTML = `<div class="pop-title">${esc(found.label)}</div><div class="muted small">${conductors} conductor${conductors === 1 ? "" : "s"} · double-click to show ${bus ? `${esc(bus.name)} alone` : "it alone"}</div>
      <div class="pop-actions">${actions.map(([text], i) => `<button type="button" class="btn" data-pop="${i}">${esc(text)}</button>`).join("")}</div>`;
    const host = $(".canvas").getBoundingClientRect();
    pop.hidden = false;
    const w = pop.offsetWidth, h = pop.offsetHeight;
    pop.style.left = `${Math.min(Math.max(8, e.clientX - host.left + 14), host.width - w - 8)}px`;
    pop.style.top = `${Math.min(Math.max(8, e.clientY - host.top + 14), host.height - h - 8)}px`;
  }

  /** Select a bus where it is: every net it carries lights up, and the rest of the drawing stays. */
  function highlightBus(busId) {
    if (!(state.scene?.buses || []).some((b) => b.id === busId)) return;
    inspect({ type: "bus", id: busId });
  }

  function hidePop() {
    const pop = $("#net-pop");
    if (pop) pop.hidden = true;
  }

  function setupFocus() {
    $("#focus-exit")?.addEventListener("click", () => exitFocus());
    $("#net-pop")?.addEventListener("click", (e) => {
      const b = e.target.closest("[data-pop]");
      if (!b) return;
      const run = state.popActions?.[+b.dataset.pop];
      hidePop();
      if (run) run();
    });
    $("#net-pop")?.addEventListener("pointerdown", (e) => e.stopPropagation());
  }

  function markSelection() {
    if (!state.svg) return;
    $$(".sel", state.svg).forEach((x) => x.classList.remove("sel"));
    const s = state.selection;
    if (!s) { highlightNet(null); return; }
    let sel = [];
    if (s.type === "symbol") sel = $$(`.symbol[data-sym="${CSS.escape(s.id)}"]`, state.svg);
    else if (s.type === "contact") sel = $$(`.pin[data-sym="${CSS.escape(s.sym)}"][data-contact="${CSS.escape(s.key)}"]`, state.svg);
    else if (s.type === "connection") sel = $$(`[data-conn="${CSS.escape(s.id)}"]`, state.svg);
    else if (s.type === "annotation") sel = $$(`[data-annotation="${CSS.escape(s.id)}"]`, state.svg);
    else if (s.type === "group") sel = $$(`.group[data-group="${CSS.escape(s.id)}"]`, state.svg);
    else if (s.type === "interface") sel = $$(`[data-iface="${CSS.escape(s.id)}"]`, state.svg);
    else if (s.type === "cable") sel = $$(`[data-bundle="${CSS.escape(s.id)}"]`, state.svg);
    sel.forEach((x) => x.classList.add("sel"));
    highlightNet(selectedNet());
  }

  // ------------------------------------------------------------------ inspector

  function formatValue(v) {
    if (Array.isArray(v)) return v.length ? v.map((x) => `<span class="chip">${esc(x)}</span>`).join(" ") : '<span class="muted">empty list</span>';
    if (typeof v === "boolean") return `<span class="chip">${v}</span>`;
    if (typeof v === "number") return `<span class="num">${v}</span>`;
    const s = String(v);
    return s.length > 160 ? `<span class="long">${esc(s)}</span>` : esc(s);
  }

  function propTable(props) {
    const entries = Object.entries(props || {});
    if (!entries.length) return '<p class="muted small">No properties.</p>';
    return `<dl class="props">${entries.map(([k, v]) => `<dt${termTitle("props", k)}>${esc(k)}</dt><dd>${formatValue(v)}</dd>`).join("")}</dl>`;
  }

  // ------------------------------------------------------------------ the model's own vocabulary

  /** The graph's definition of a name (a label, relationship type or property), if it has one. */
  function termOf(kind, name) {
    return state.scene?.model?.terms?.[kind]?.get(String(name)) || null;
  }

  function termTitle(kind, name) {
    const t = termOf(kind, name);
    return t?.definition ? ` title="${esc(t.definition)}"` : "";
  }

  /** One line under an inspector heading: what the node's label means in this model. */
  function labelDef(labels) {
    const defs = (labels || []).map((l) => [l, termOf("labels", l)]).filter(([, t]) => t?.definition);
    return defs.length ? `<p class="def small">${defs.map(([l, t]) => `<b>${esc(l)}</b>: ${esc(t.definition)}`).join(" ")}</p>` : "";
  }

  /** A short, recognisable name for a mapping target: the standard, then its term. */
  function shortIri(u) {
    const s = String(u);
    const last = (x) => decodeURIComponent(x.replace(/[/#]+$/, "").split(/[/#]/).pop());
    const rules = [
      [/prostep\.org\/specifications\/kbl\//, "KBL"], [/prostep\.org\/specifications\/vec\//, "VEC"],
      [/kicad\.org/, "KiCad"], [/iec\.ch\/TC57\/CIM/, "CIM"], [/buildingsmart\.org/, "IFC"],
      [/saref\.etsi\.org\/saref4syst/, "SAREF4SYST"], [/skos\/core/, "SKOS"], [/ns\/prov/, "PROV-O"],
      [/ns\/dcat/, "DCAT"], [/purl\.org\/dc\/terms/, "Dublin Core"], [/rdf-schema/, "RDFS"],
    ];
    for (const [re, name] of rules) if (re.test(s)) return `${name} ${last(s).replace(/\.html?$/, "").replace(/^_/, "")}`;
    return last(s);
  }

  // The Dataset's rights statement (dcterms:rights) is shown under every view, so a shared
  // model always carries its own trademark and disclaimer notice.
  function renderNotice() {
    const el = $("#model-notice");
    if (!el) return;
    const d = state.scene?.model?.dataset?.props || {};
    el.textContent = d.rights ? String(d.rights) : "";
    // The model's own licence (dcterms:license) follows its rights statement, as a link.
    if (d.license) {
      if (d.rights) el.append(" ");
      const a = document.createElement("a");
      a.href = String(d.license); a.target = "_blank"; a.rel = "noopener";
      a.textContent = licenceName(d.license);
      el.append("Model license: ", a, ".");
    }
    el.hidden = !d.rights && !d.license;
  }

  /** A licence URL by its common name where it is a well-known one. */
  function licenceName(url) {
    const known = {
      "https://opendatacommons.org/licenses/by/1-0/": "ODC-By 1.0",
      "https://opendatacommons.org/licenses/odbl/1-0/": "ODbL 1.0",
      "https://opendatacommons.org/licenses/pddl/1-0/": "PDDL 1.0",
      "https://creativecommons.org/licenses/by/4.0/": "CC BY 4.0",
      "https://creativecommons.org/licenses/by-sa/4.0/": "CC BY-SA 4.0",
      "https://creativecommons.org/publicdomain/zero/1.0/": "CC0 1.0",
    };
    return known[String(url)] || String(url);
  }

  function renderModelPane() {
    renderNotice();
    const pane = $("#pane-model");
    if (!pane) return;
    const M = state.scene?.model;
    if (!M || (!M.dataset && !M.scheme)) {
      pane.innerHTML = '<p class="muted small">This graph does not describe itself: it has no Dataset, Method or vocabulary nodes. The toolkit\'s SKILL.md, "Model metadata", shows how to add them.</p>';
      return;
    }
    const d = M.dataset?.props || {};
    const sc = M.scheme?.props || {};
    const list = (xs) => (xs && xs.length ? `<ul class="plain">${xs.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>` : "");
    const maps = (t) => ["exact", "close", "broad", "narrow", "related"].map((k) => (t[`${k}_match`] || []).length
      ? `<div class="maps"><span class="muted small">${k}</span> ${t[`${k}_match`].map((u) => `<a class="map-link" href="${esc(u)}" target="_blank" rel="noopener" title="${esc(u)}">${esc(shortIri(u))}</a>`).join(" ")}</div>` : "").join("");
    const facts = (t) => [
      t.from_labels ? `${esc(t.from_labels.join(" | "))} → ${esc((t.to_labels || []).join(" | "))}` : "",
      t.applies_to ? `on ${esc(t.applies_to.join(", "))}` : "",
      t.value_type ? `${esc(t.value_type)}${t.required ? ", required" : ""}` : "",
    ].filter(Boolean).join(" · ");
    const group = (title, kind) => {
      const terms = [...(M.terms[kind]?.values() || [])].sort((a, b) => KGScene.compareNatural(a.name, b.name));
      if (!terms.length) return "";
      return `<details class="term-group" open><summary>${title} <span class="count">${terms.length}</span></summary><dl class="terms">${terms.map((t) => `
        <dt data-term="${esc(`${t.name} ${t.definition || ""}`.toLowerCase())}"><code>${esc(t.name)}</code> <span class="term-status${t.status === "new" ? " is-new" : ""}">${esc(t.status || "")}</span></dt>
        <dd data-term="${esc(`${t.name} ${t.definition || ""}`.toLowerCase())}">${esc(t.definition || "")}${t.usage ? `<div class="muted small">${esc(t.usage)}</div>` : ""}${facts(t) ? `<div class="small facts">${facts(t)}</div>` : ""}${t.values ? list(t.values) : ""}${maps(t)}</dd>`).join("")}</dl></details>`;
    };
    pane.innerHTML = `
      <header class="insp-head"><span class="kicker">Model</span><h2>${esc(d.name || sc.name || "")}</h2>
      <p class="small muted">${d.issued ? `Issued ${esc(d.issued)}` : ""}${M.scheme ? `${d.issued ? " · " : ""}uses the vocabulary <b>${esc(sc.name || "")}</b>` : ""}</p></header>
      ${d.description ? `<section><p>${esc(d.description)}</p>${d.scope ? `<p class="small muted">${esc(d.scope)}</p>` : ""}</section>` : ""}
      ${d.rights || d.license ? `<section><h3>Rights</h3>${d.license ? `<p class="small">License: <a href="${esc(d.license)}" target="_blank" rel="noopener">${esc(licenceName(d.license))}</a></p>` : ""}${d.rights ? `<p class="small">${esc(d.rights)}</p>` : ""}</section>` : ""}
      ${M.sources.length ? `<section><h3>Sources</h3>${M.sources.map((n) => `<div class="source"><b>${esc(n.props.name || "")}</b>${n.props.description ? `<p class="small">${esc(n.props.description)}</p>` : ""}<p class="small muted">${[n.props.publisher, n.props.pages && `pages ${n.props.pages}`, n.props.format].filter(Boolean).map(esc).join(" · ")}</p></div>`).join("")}</section>` : ""}
      ${M.methods.length ? `<section><h3>Methods <span class="count">${M.methods.length}</span></h3>${M.methods.map((n) => `<details class="method"><summary>${esc(n.props.name || n.props.id)}</summary><p class="small">${esc(n.props.description || "")}</p>${(n.props.parameters || []).length ? `<h4>Parameters</h4>${list(n.props.parameters)}` : ""}${(n.props.limitations || []).length ? `<h4>Limitations</h4>${list(n.props.limitations)}` : ""}${(n.props.produces || []).length ? `<h4>Produces</h4><p>${n.props.produces.map((x) => `<span class="chip">${esc(x)}</span>`).join(" ")}</p>` : ""}</details>`).join("")}</section>` : ""}
      ${M.scheme ? `<section><h3>Vocabulary</h3><p class="small">${esc(sc.description || "")}</p>${sc.naming_rule ? `<p class="small muted">${esc(sc.naming_rule)}</p>` : ""}<p class="small muted">Defined in <code>${esc(sc.schema_file || "")}</code> · namespace <code>${esc(sc.namespace || "")}</code> · status: adopted is a standard's own term, adapted is a standard's term fitted to a property graph, new is defined here.</p>
        <input type="search" id="term-filter" class="term-filter" placeholder="Filter terms" aria-label="Filter terms">
        ${group("Node labels", "labels")}${group("Relationship types", "rels")}${group("Properties", "props")}${group("Value sets", "valueSets")}</section>` : ""}`;
    const f = $("#term-filter");
    if (f) f.addEventListener("input", () => {
      const q = f.value.trim().toLowerCase();
      $$("[data-term]", pane).forEach((el) => { el.hidden = !!q && !el.dataset.term.includes(q); });
    });
  }

  function lineLinks(lines) {
    return (lines || []).map((l) => `<button class="link line-link" data-line="${l}">line ${l}</button>`).join(" ");
  }

  function nodeLabel(n) {
    return esc(n.props.name ?? n.props.id ?? n.props.ref ?? `#${n.id}`);
  }

  function nameOfNode(n) { return String(n?.props?.name ?? n?.props?.id ?? ""); }
  function endNameOf(sid) { const s = state.scene.symbols.get(sid); return s ? s.ref || s.name : sid; }

  function relList(node) {
    const g = state.result.graph;
    const rows = [];
    for (const r of g.relsOf(node.id, "out")) rows.push({ r, dir: "→", other: g.nodes.get(r.end) });
    for (const r of g.relsOf(node.id, "in")) rows.push({ r, dir: "←", other: g.nodes.get(r.start) });
    if (!rows.length) return '<p class="muted small">No relationships.</p>';
    rows.sort((a, b) => a.r.type.localeCompare(b.r.type));
    const shown = rows.slice(0, 80);
    return `<ul class="rels">${shown.map(({ r, dir, other }) => `<li><span class="rel-type"${termTitle("rels", r.type)}>${dir} ${esc(r.type)}</span> <button class="link node-link" data-node="${other.id}">${nodeLabel(other)}</button>${Object.keys(r.props).length ? `<span class="rel-props">${esc(Object.entries(r.props).map(([k, v]) => `${k}: ${Array.isArray(v) ? v.join("/") : v}`).join(", "))}</span>` : ""}</li>`).join("")}</ul>${rows.length > shown.length ? `<p class="muted small">${rows.length - shown.length} more not shown.</p>` : ""}`;
  }

  /** Links to the buses that carry a net, with the role the net plays on each. */
  function busChips(net) {
    return (net?.buses || []).map(({ bus, role }) => ` <button class="link bus-link" data-bus="${esc(bus.id)}" title="Highlight the whole bus">${esc(bus.name)}</button>${role ? ` <span class="muted small">${esc(role)}</span>` : ""}`).join("");
  }

  function swatch(conn) {
    if (!conn?.color) return "";
    const s = conn.color.stripes;
    const bg = s.length > 1 ? `linear-gradient(135deg, ${s[0].hex} 0 50%, ${s[1].hex} 50% 100%)` : s[0].hex;
    return `<span class="swatch" style="background:${bg}" title="${esc(conn.color.label)}"></span>`;
  }

  function findContact(symId, key) {
    return state.scene.symbols.get(symId)?.contacts.get(key) || null;
  }

  function inspect(sel, { keep = false } = {}) {
    state.selection = sel;
    markSelection();
    const pane = $("#pane-inspect");
    const { scene, layout } = state;
    let html = "";
    if (sel.type === "symbol") {
      const sym = scene.symbols.get(sel.id);
      if (!sym) return clearSelection();
      const contacts = [...sym.contacts.values()].filter((c) => c.visible);
      html = `
        <header class="insp-head"><span class="kicker">${esc(sym.node.labels.join(" · "))}</span>
        <h2>${sym.ref ? `<span class="refdes">${esc(sym.ref)}</span> ` : ""}${esc(sym.name)}</h2>
        <p class="small muted">${sym.junction ? `Drawn as a junction${sym.alsoNodes?.length ? `, together with ${sym.alsoNodes.map((n) => `<button class="link node-link" data-node="${n.id}">${esc(nameOfNode(n))}</button>`).join(", ")}` : ""}` : sym.kind === "lib" ? `KiCad symbol <code>${esc(sym.libId)}</code>` : "Generated box symbol (no library symbol matched)"} · defined ${lineLinks(sym.node.lines)}</p></header>
        ${labelDef(sym.node.labels)}
        ${unitLinks(sym)}
        <section><h3>Properties</h3>${propTable(sym.node.props)}</section>
        <section><h3>Drawn contacts <span class="count">${contacts.length}</span></h3><ul class="contacts">${contacts.map((c) => `<li><button class="link contact-link" data-sym="${esc(sym.id)}" data-key="${esc(c.key)}">${esc(c.name)}</button>${c.number ? ` <span class="pin-no">${esc(c.number)}</span>` : ""}${c.func && c.func !== c.name ? ` <span class="muted">${esc(c.func)}</span>` : ""} <span class="net-chip">${esc(c.net.name)}</span>${c.net.outside ? ' <span class="muted small">not shown</span>' : ""}</li>`).join("")}</ul></section>
        <section><h3>Relationships</h3>${relList(sym.node)}</section>`;
    } else if (sel.type === "contact") {
      const c = findContact(sel.sym, sel.key);
      if (!c) return clearSelection();
      const sym = scene.symbols.get(sel.sym);
      const members = c.net.contacts.filter((x) => x.visible || x.logical);
      const conns = c.net.connections;
      html = `
        <header class="insp-head"><span class="kicker">${c.pin ? esc(c.pin.labels.join(" · ")) : "Contact"} on <button class="link sym-link" data-sym="${esc(sym.id)}">${esc(sym.ref || sym.name)}</button></span>
        <h2>${esc(c.name)}${c.number ? ` <span class="pin-no">${esc(c.number)}</span>` : ""}</h2>
        <p class="small muted">${c.section ? `${esc(c.section.name)} · ` : ""}${esc(physicalText(c))} · net <span class="net-chip">${esc(c.net.name)}</span>${busChips(c.net)}${c.pin ? ` · defined ${lineLinks(c.pin.lines)}` : c.junctionNode ? ` · a conductor ending on ${esc(nameOfNode(c.junctionNode))}` : c.synthetic ? " · contact derived from the connections that reach this part" : ""}</p></header>
        ${c.pin ? `${labelDef(c.pin.labels)}<section><h3>Properties</h3>${propTable(c.pin.props)}</section>` : ""}
        <p class="focus-links">${focusLinks([c.net])}</p>
        <section><h3>Net ${esc(c.net.name)} <span class="count">${members.length}</span></h3><ul class="contacts">${members.map((m) => { const s = scene.symbols.get(m.symbolId); return `<li>${s ? `<span class="muted small">${esc(s.ref || s.name)}</span> ` : ""}${m.visible && s ? `<button class="link contact-link" data-sym="${esc(m.symbolId)}" data-key="${esc(m.key)}">${esc(m.name)}</button>` : `<span>${esc(m.name)}</span> <span class="muted small">${m.logical ? "logical signal" : "hidden"}</span>`}</li>`; }).join("")}</ul></section>
        <section><h3>Connections</h3><ul class="rels">${conns.map((cn) => `<li>${swatch(cn)}<button class="link conn-link" data-conn="${esc(cn.id)}">${esc(cn.type)}${cn.props?.id ? ` ${esc(cn.props.id)}` : ""}</button>${cn.inferred ? ' <span class="muted small">inferred</span>' : ""}</li>`).join("")}</ul></section>
        ${c.pin ? `<section><h3>Relationships</h3>${relList(c.pin)}</section>` : ""}`;
    } else if (sel.type === "connection") {
      const cn = scene.connections.find((x) => x.id === sel.id);
      if (!cn) return clearSelection();
      const end = (c) => { if (!c) return ""; const s = scene.symbols.get(c.symbolId); return `<button class="link contact-link" data-sym="${esc(c.symbolId)}" data-key="${esc(c.key)}">${esc(s ? s.ref || s.name : "")} · ${esc(c.name)}</button>`; };
      html = `
        <header class="insp-head"><span class="kicker">${cn.node ? `Conductor · ${esc(cn.node.labels.join(" · "))}` : cn.rel ? "Relationship" : cn.inferred ? "Inferred connection" : "Connection"} · ${esc(cn.style)}</span>
        <h2>${swatch(cn)}${esc(cn.type)}${cn.props?.id ? ` <code>${esc(cn.props.id)}</code>` : ""}</h2>
        <p class="small muted">${end(cn.a)} → ${cn.port ? esc(cn.port.label + " · " + cn.port.sub) : end(cn.b)} · net <span class="net-chip">${esc(cn.net?.name || "")}</span>${busChips(cn.net)}${cn.node ? ` · defined ${lineLinks(cn.node.lines)}` : cn.rel ? ` · defined ${lineLinks(cn.rel.lines)}` : ""}</p></header>
        ${litLine(sel)}
        ${cn.net ? `<p class="focus-links">${focusLinks([cn.net])}</p>` : ""}
        ${cn.inferred ? '<p class="note">The graph does not state this link. It follows from both contacts sharing a signal inside one sub-assembly, so it is drawn dashed.</p>' : ""}
        ${cn.node ? labelDef(cn.node.labels) : cn.rel ? (termOf("rels", cn.rel.type)?.definition ? `<p class="def small"><b>${esc(cn.rel.type)}</b>: ${esc(termOf("rels", cn.rel.type).definition)}</p>` : "") : ""}
        <section><h3>Properties</h3>${propTable(cn.props)}</section>
        ${cn.bundle ? `<section><h3>${cn.bundle.style === "pair" ? "Twisted pair" : "Cable"}</h3><p><button class="link cable-link" data-bundle="${esc(cn.bundle.id)}">${esc(cn.bundle.name)}</button> <span class="muted small">${cn.bundle.style === "pair" ? `${cn.groupRole ? `this conductor is ${esc(cn.groupRole)}; ` : ""}${cn.bundle.connections.length} conductors twisted together` : `one jacket, ${cn.bundle.connections.length} conductors`}</span></p></section>`
          : cn.group ? `<section><h3>${cn.groupRole ? "Group" : "Harness"}</h3><p>${esc(scene.wireGroups.get(String(cn.group))?.name || cn.group)}${cn.groupRole ? ` <span class="muted small">${esc(cn.groupRole)}</span>` : ""}</p></section>` : ""}
        ${cn.node ? `<section><h3>Relationships</h3>${relList(cn.node)}</section>` : ""}`;
    } else if (sel.type === "cable") {
      const b = (scene.bundles || []).find((x) => x.id === sel.id);
      if (!b) return clearSelection();
      const endName = (sid) => { const s = scene.symbols.get(sid); return s ? s.ref || s.name : sid; };
      html = `
        <header class="insp-head"><span class="kicker">${esc(b.node.labels.join(" · "))} · ${b.style === "pair" ? "twisted pair" : "jacketed cable"}</span>
        <h2>${esc(b.name)}</h2>
        <p class="small muted">${esc(endName(b.ends[0]))} ↔ ${esc(endName(b.ends[1]))} · ${b.connections.length} conductors, ${b.style === "pair" ? "drawn twisted together along one route" : "drawn as one bus"} · defined ${lineLinks(b.node.lines)}</p></header>
        <p class="focus-links">${(() => { const v = cableView(b); return v.kind === "bus" ? `<button class="link focus-link" data-focus="bus" data-bus="${esc(v.busId)}">Show ${esc(v.name)} alone${v.roles.length > 1 ? ` (${esc(v.roles.join(" + "))})` : ""}</button> · <button class="link bus-link" data-bus="${esc(v.busId)}" title="Light every net of the bus without hiding the rest">Highlight ${esc(v.name)}</button>` : `<button class="link focus-link" data-focus="cable" data-bundle="${esc(b.id)}">Show ${b.style === "pair" ? "this pair" : "this cable"} alone</button>`; })()}</p>
        ${labelDef(b.node.labels)}
        <section><h3>Conductors</h3><ul class="rels">${b.connections.map((cn) => `<li>${swatch(cn)}<button class="link conn-link" data-conn="${esc(cn.id)}">${esc(cn.props?.id ?? `${cn.a.name} → ${cn.b.name}`)}</button>${cn.groupRole ? ` <span class="muted small">${esc(cn.groupRole)}</span>` : ""} <span class="net-chip">${esc(cn.net?.name || "")}</span>${busChips(cn.net)}</li>`).join("")}</ul></section>
        <section><h3>Properties</h3>${propTable(b.node.props)}</section>
        <section><h3>Relationships</h3>${relList(b.node)}</section>`;
    } else if (sel.type === "bus") {
      const bus = (scene.buses || []).find((x) => x.id === sel.id);
      if (!bus) return clearSelection();
      const pairs = (scene.bundles || []).filter((bd) => bd.style === "pair" && bd.connections.some((c) => bus.members.some((m) => m.nets.includes(c.net))));
      html = `
        <header class="insp-head"><span class="kicker">${esc(bus.node.labels.join(" · "))}${bus.node.props.protocol ? ` · ${esc(bus.node.props.protocol)}` : ""}</span>
        <h2>${esc(bus.name)}</h2>
        <p class="small muted">Every net this bus carries is lit on the drawing · defined ${lineLinks(bus.node.lines)}</p></header>
        <p class="focus-links"><button class="link focus-link" data-focus="bus" data-bus="${esc(bus.id)}">Show this bus alone</button></p>
        ${labelDef(bus.node.labels)}
        <section><h3>Nets</h3><ul class="rels">${bus.members.map((m) => `<li><span class="rel-type">${esc(m.role || "")}</span> <span class="net-chip">${esc(m.nets[0]?.name || String(m.netNode?.props?.name ?? ""))}</span> <span class="muted small">${m.nets.reduce((a, n) => a + n.connections.length, 0)} conductors</span></li>`).join("")}</ul></section>
        ${pairs.length ? `<section><h3>Twisted pairs <span class="count">${pairs.length}</span></h3><ul class="rels">${pairs.map((bd) => `<li><button class="link cable-link" data-bundle="${esc(bd.id)}">${esc(bd.node.props.id ?? bd.name)}</button> <span class="muted small">${esc(endNameOf(bd.ends[0]))} ↔ ${esc(endNameOf(bd.ends[1]))}</span></li>`).join("")}</ul></section>` : ""}
        <section><h3>Properties</h3>${propTable(bus.node.props)}</section>
        <section><h3>Relationships</h3>${relList(bus.node)}</section>`;
    } else if (sel.type === "annotation") {
      const a = scene.annotations.find((x) => x.id === sel.id);
      if (!a) return clearSelection();
      html = `
        <header class="insp-head"><span class="kicker warn">${esc(a.node.labels.join(" · "))}</span>
        <h2>${esc(a.title)}</h2>
        <p class="small muted">Points at ${a.connections.length} wires and ${a.contacts.length} contacts · defined ${lineLinks(a.node.lines)}</p></header>
        <section class="long-props">${propTable(a.node.props)}</section>
        <section><h3>Relationships</h3>${relList(a.node)}</section>`;
    } else if (sel.type === "group") {
      const g = scene.groups.get(sel.id);
      if (!g) return clearSelection();
      html = `
        <header class="insp-head"><span class="kicker">${esc(g.node.labels.join(" · "))} · container</span>
        <h2>${esc(g.name)}</h2><p class="small muted">defined ${lineLinks(g.node.lines)}</p></header>
        <section><h3>Properties</h3>${propTable(g.node.props)}</section>
        <section><h3>Contains</h3><ul class="contacts">${g.symbols.map((sid) => { const s = scene.symbols.get(sid); return `<li><button class="link sym-link" data-sym="${esc(sid)}">${s.ref ? `<span class="refdes small">${esc(s.ref)}</span> ` : ""}${esc(s.name)}</button></li>`; }).join("")}${g.groups.map((gid) => `<li><button class="link group-link" data-group="${esc(gid)}">${esc(scene.groups.get(gid)?.name)}</button></li>`).join("")}</ul></section>
        <section><h3>Relationships</h3>${relList(g.node)}</section>`;
    } else if (sel.type === "interface") {
      const i = scene.interfaces.find((x) => x.id === sel.id);
      if (!i) return clearSelection();
      html = `
        <header class="insp-head"><span class="kicker">Exposed interface</span><h2>${esc(i.label)}</h2>
        <p class="small muted">${esc(i.target.props.name || "")} · defined ${lineLinks(i.target.lines)}</p></header>
        <section><h3>Properties</h3>${propTable(i.target.props)}</section>
        <section><h3>Contacts</h3><ul class="contacts">${i.contacts.map((c) => `<li><button class="link contact-link" data-sym="${esc(c.symbolId)}" data-key="${esc(c.key)}">${esc(c.name)}</button> <span class="net-chip">${esc(c.net.name)}</span></li>`).join("")}</ul></section>`;
    } else if (sel.type === "node") {
      const n = state.result.graph.nodes.get(sel.id);
      if (!n) return clearSelection();
      const sym = [...scene.symbols.values()].find((s) => s.node === n);
      if (sym && !keep) return inspect({ type: "symbol", id: sym.id });
      for (const s of scene.symbols.values()) for (const c of s.contacts.values()) if (c.pin === n && c.visible && !keep) return inspect({ type: "contact", sym: s.id, key: c.key });
      html = `
        <header class="insp-head"><span class="kicker">${esc(n.labels.join(" · "))} · not drawn</span><h2>${nodeLabel(n)}</h2>
        <p class="small muted">defined ${lineLinks(n.lines)}</p></header>
        ${labelDef(n.labels)}
        <section><h3>Properties</h3>${propTable(n.props)}</section>
        <section><h3>Relationships</h3>${relList(n)}</section>`;
    }
    pane.innerHTML = html;
    if (!keep) showTab("inspect");
  }

  /** Where the graph puts this contact physically, in its own terms. */
  function physicalText(c) {
    if (c.pos) return `at ${c.pos.x} × ${c.pos.y} mm${c.pin?.props.position_frame ? ` in ${c.pin.props.position_frame}` : ""}`;
    const side = { WEST: "left", EAST: "right", NORTH: "top", SOUTH: "bottom" }[c.sideHint];
    if (side && c.order !== undefined && c.order !== null) return `${side} side, position ${c.order}`;
    if (side) return `${side} side`;
    return "no physical location in the graph";
  }

  /** Inspector links that show a net, or its bus, alone. */
  function focusLinks(nets) {
    const net = nets[0];
    const bus = busNets(net);
    const netLink = `<button class="link focus-link" data-focus="net" data-net-key="${esc(net.key)}">${bus ? "Show this line only" : "Show this net alone"}</button>`;
    const busLink = bus ? `<button class="link focus-link" data-focus="bus" data-bus="${esc(net.buses[0].bus.id)}">Show ${esc(bus.name)} alone${bus.roles.length > 1 ? ` (${esc(bus.roles.join(" + "))})` : ""}</button> · <button class="link bus-link" data-bus="${esc(net.buses[0].bus.id)}" title="Light every net of the bus without hiding the rest">Highlight ${esc(bus.name)}</button>` : "";
    return `${bus ? `${busLink} · ${netLink}` : netLink}${state.focus ? ` · <button class="link focus-link" data-focus="exit">Back to ${esc(scopeLabel(state.scope))}</button>` : ""}`;
  }

  function clearSelection() { state.selection = null; markSelection(); renderOverview(); }

  function renderOverview() {
    const { scene, result } = state;
    if (!scene) return;
    const groups = [...scene.wireGroups.values()];
    const symbolsSorted = [...scene.symbols.values()].filter((s) => state.layout.symbols.has(s.id)).sort((a, b) => KGScene.compareNatural(a.ref || a.name, b.ref || b.name));
    const styles = [
      ["wire", "Wire", "Conductor, drawn in its recorded colour"],
      ["bus", "Cable", "Conductors in one jacket: a KiCad bus with 45° entries"],
      ["pair", "Twisted pair", "Two conductors twisted together along one route"],
      ["mate", "Mated contacts", "Plug seated in its receptacle, pin to pin"],
      ["coax", "RF cable", "Coaxial cable"],
      ["tap", "Tap", "Tap onto an existing conductor"],
      ["join", "Inferred", "Link implied by the graph, not stated"],
      ["unplaced", "Dashed pin", "Position on the part not recorded in the graph"],
    ].filter(([k]) => (k === "bus" ? (state.layout.bundles || []).some((b) => b.bundle.style !== "pair")
      : k === "pair" ? (state.layout.bundles || []).some((b) => b.bundle.style === "pair")
      : k === "unplaced" ? [...state.layout.symbols.values()].some((sv) => sv.geo.pins.some((pp) => pp.unplaced))
      : scene.connections.some((c) => c.style === k)));
    $("#pane-inspect").innerHTML = `
      <header class="insp-head"><span class="kicker">${state.focus ? `Drawing · ${esc(state.focus.label)} alone` : "Drawing"}</span><h2>${esc(graphTitle())}</h2>
      ${state.focus ? `<p class="focus-links"><button class="link focus-link" data-focus="exit">Back to ${esc(scopeLabel(state.scope))}</button></p>` : ""}
      <p class="small muted">${result.graph.nodes.size} nodes · ${result.graph.rels.size} relationships · ${state.layout.symbols.size} parts drawn · ${[...scene.nets.values()].filter((n) => n.connections.length).length} nets. Select anything on the drawing to inspect it; click a wire again to trace its net, then its cable or bus.</p></header>
      ${(scene.buses || []).length ? `<section><h3>Buses</h3><ul class="contacts">${scene.buses.map((b) => `<li><button class="link bus-link" data-bus="${esc(b.id)}">${esc(b.name)}</button>${b.node.props.protocol ? ` <span class="muted small">${esc(b.node.props.protocol)}</span>` : ""}</li>`).join("")}</ul></section>` : ""}
      ${groups.length ? `<section><h3>Harnesses</h3><ul class="legend">${groups.map((g) => `<li data-group-key="${esc(g.key)}">${[...new Map(g.connections.filter((c) => c.color).map((c) => [c.color.label.toLowerCase(), c])).values()].map(swatch).join("")}<span>${esc(g.name)}</span><span class="count">${g.connections.length}</span></li>`).join("")}</ul></section>` : ""}
      ${styles.length ? `<section><h3>Line styles</h3><ul class="legend styles">${styles.map(([k, name, desc]) => `<li><svg viewBox="0 0 60 16" class="style-sample style-${k}"><line x1="2" y1="8" x2="58" y2="8"/><line class="core" x1="2" y1="8" x2="58" y2="8"/></svg><span>${name}</span><span class="muted small">${desc}</span></li>`).join("")}</ul></section>` : ""}
      <section><h3>Parts</h3><ul class="contacts">${symbolsSorted.map((s) => `<li><button class="link sym-link" data-sym="${esc(s.id)}">${s.ref ? `<span class="refdes small">${esc(s.ref)}</span> ` : ""}${esc(s.name)}</button></li>`).join("")}</ul></section>
      ${scene.annotations.length ? `<section><h3>Annotations</h3><ul class="contacts">${scene.annotations.map((a) => `<li><button class="link ann-link" data-annotation="${esc(a.id)}">${esc(a.title)}</button></li>`).join("")}</ul></section>` : ""}`;
  }

  /** For a part: show all its connections, or one class of them, across the whole graph. */
  function unitLinks(sym) {
    const rules = parseRules() || JSON.parse(embedded.rules);
    if (!rules.units || sym.junction) return "";
    const key = String(sym.node.props.id ?? sym.node.id);
    if (!unitsOf(state.result.graph, rules).some((u) => u.key === key)) return "";
    const cls = (rules.units.classes || []).map((c) => c.name);
    return `<p class="focus-links"><button class="link unit-link" data-unit="${esc(key)}" data-cls="">All its connections</button>${cls.map((c) => ` · <button class="link unit-link" data-unit="${esc(key)}" data-cls="${esc(c)}">${esc(c)}</button>`).join("")}</p>`;
  }

  function setupInspectorLinks() {
    document.addEventListener("click", (e) => {
      const b = e.target.closest("button.link");
      if (!b) return;
      if (b.dataset.line) { goToLine(+b.dataset.line); return; }
      if (b.classList.contains("focus-link")) {
        const sc = state.scene;
        if (b.dataset.focus === "exit") exitFocus();
        else if (b.dataset.focus === "net") { const n = [...sc.nets.values()].find((x) => x.key === b.dataset.netKey); if (n) enterFocus([n], `net ${n.name}`); }
        else if (b.dataset.focus === "bus") { const bus = (sc.buses || []).find((x) => x.id === b.dataset.bus); if (bus) enterFocus(bus.members.flatMap((m) => m.nets), `bus ${bus.name}`); }
        else if (b.dataset.focus === "cable") { const bd = (sc.bundles || []).find((x) => x.id === b.dataset.bundle); if (bd) enterFocus([...new Set(bd.connections.map((c) => c.net).filter(Boolean))], `${bd.style === "pair" ? "twisted pair" : "cable"} ${bd.name}`); }
        return;
      }
      if (b.classList.contains("unit-link")) { enterUnit(b.dataset.unit, b.dataset.cls); return; }
      if (b.classList.contains("finding-link")) { showFinding(state.checks.findings[+b.dataset.finding]); return; }
      if (b.classList.contains("sym-link")) { inspect({ type: "symbol", id: b.dataset.sym }); focusOn({ type: "symbol", id: b.dataset.sym }); }
      else if (b.classList.contains("contact-link")) { inspect({ type: "contact", sym: b.dataset.sym, key: b.dataset.key }); focusOn({ type: "symbol", id: b.dataset.sym }); }
      else if (b.classList.contains("conn-link")) inspect({ type: "connection", id: b.dataset.conn });
      else if (b.classList.contains("node-link")) inspect({ type: "node", id: +b.dataset.node });
      else if (b.classList.contains("group-link")) inspect({ type: "group", id: b.dataset.group });
      else if (b.classList.contains("cable-link")) inspect({ type: "cable", id: b.dataset.bundle });
      else if (b.classList.contains("bus-link")) inspect({ type: "bus", id: b.dataset.bus });
      else if (b.classList.contains("ann-link")) inspect({ type: "annotation", id: b.dataset.annotation });
    });
    $("#pane-inspect").addEventListener("mouseover", (e) => {
      const li = e.target.closest("[data-group-key]");
      if (!state.svg) return;
      $$(".hl", state.svg).forEach((x) => x.classList.remove("hl"));
      state.svg.classList.toggle("dimmed", !!li);
      if (!li) return;
      const g = state.scene.wireGroups.get(li.dataset.groupKey);
      for (const c of g.connections) $$(`[data-conn="${CSS.escape(c.id)}"]`, state.svg).forEach((x) => x.classList.add("hl"));
    });
    $("#pane-inspect").addEventListener("mouseleave", () => clearHover());
  }

  /** Take the drawing to a check's finding and ring the spot. */
  function showFinding(f) {
    if (!f?.at) return;
    setView("drawing");
    zoomTo(f.at[0] - 150, f.at[1] - 150, 300, 300);
    $$(".finding-mark", state.svg).forEach((x) => x.remove());
    const ring = document.createElementNS("http://www.w3.org/2000/svg", "circle");
    ring.setAttribute("class", "finding-mark");
    ring.setAttribute("cx", f.at[0]); ring.setAttribute("cy", f.at[1]); ring.setAttribute("r", 90);
    state.svg.appendChild(ring);
  }

  function focusOn(sel) {
    const s = state.layout.symbols.get(sel.id);
    if (s) zoomTo(s.x, s.y, s.w, s.h);
  }

  // ------------------------------------------------------------------ source, rules, symbols, issues

  function goToLine(n) {
    showTab("source");
    const ta = $("#source-text");
    const lines = ta.value.split("\n");
    const startPos = lines.slice(0, n - 1).reduce((a, l) => a + l.length + 1, 0);
    const endPos = startPos + (lines[n - 1] || "").length;
    ta.focus();
    ta.setSelectionRange(startPos, endPos);
    const lh = parseFloat(getComputedStyle(ta).lineHeight) || 18;
    ta.scrollTop = Math.max(0, (n - 4) * lh);
  }

  let sourceTimer = null;
  function setupEditors() {
    const ta = $("#source-text");
    ta.value = state.source;
    ta.addEventListener("input", () => {
      clearTimeout(sourceTimer);
      $("#source-state").textContent = "Editing…";
      sourceTimer = setTimeout(() => {
        state.source = ta.value;
        saveDraft();
        run();
      }, 650);
    });
    const rules = $("#rules-text");
    rules.value = state.rulesText;
    let rulesTimer = null;
    rules.addEventListener("input", () => {
      clearTimeout(rulesTimer);
      rulesTimer = setTimeout(() => {
        state.rulesText = rules.value;
        const ok = parseRules();
        $("#rules-state").textContent = ok ? "Rules applied" : `Not applied: ${state.ruleError}`;
        $("#rules-state").className = ok ? "state ok" : "state error";
        if (ok) { saveDraft(); run(); }
      }, 650);
    });
    $("#rules-reset").addEventListener("click", () => { state.rulesText = compactJson(JSON.parse(embedded.rules)); rules.value = state.rulesText; saveDraft(); run(); $("#rules-state").textContent = "Rules reset"; });

    $("#source-revert").addEventListener("click", () => {
      state.source = embedded.source;
      state.sourceName = embedded.name;
      ta.value = state.source;
      store.del(draftKey);
      run();
      toast("Showing the embedded graph again");
    });
    $("#source-copy").addEventListener("click", () => copyText(state.source, "Cypher copied"));
    $("#page-copy").addEventListener("click", () => copyText(pageWithGraph(), "Page copied with this graph embedded"));
    $("#svg-copy").addEventListener("click", () => copyText(standaloneSvg(), "SVG copied"));

    $("#import-file").addEventListener("change", (e) => { for (const f of e.target.files) importFile(f, "replace"); e.target.value = ""; });
    $("#revision-file").addEventListener("change", (e) => { for (const f of e.target.files) importFile(f, "append"); e.target.value = ""; });
    $("#library-file").addEventListener("change", (e) => { for (const f of e.target.files) importFile(f, "library"); e.target.value = ""; });
  }

  function saveDraft() {
    const changed = state.source !== embedded.source || state.rulesText !== compactJson(JSON.parse(embedded.rules));
    if (changed) store.set(draftKey, JSON.stringify({ source: state.source, name: state.sourceName, rules: state.rulesText }));
    else store.del(draftKey);
    renderDraftBanner();
  }

  function renderDraftBanner() {
    const edited = state.source !== embedded.source;
    $("#draft-banner").hidden = !edited;
    $("#source-state").textContent = edited ? `Edited · ${state.sourceName}` : `Embedded · ${state.sourceName}`;
  }

  async function importFile(file, mode) {
    const text = await file.text();
    const ext = (file.name.split(".").pop() || "").toLowerCase();
    if (ext === "kicad_sym" || mode === "library") {
      const name = file.name.replace(/\.kicad_sym$/i, "");
      try {
        new KGKicad.Library().addText(name, text);
        state.extraLibs = state.extraLibs.filter((l) => l.name !== name).concat({ name, text });
        state.library = buildLibrary();
        toast(`Added KiCad library ${name}`);
        run();
      } catch (err) { toast(`${file.name}: ${err.message}`, "error"); }
      return;
    }
    if (ext === "json") {
      try { JSON.parse(text); state.rulesText = text; $("#rules-text").value = text; saveDraft(); run(); toast(`Rules loaded from ${file.name}`); }
      catch (err) { toast(`${file.name}: ${err.message}`, "error"); }
      return;
    }
    if (mode === "append") {
      const header = `\n\n// ── Revision: ${file.name} ─────────────────────────────────────\n`;
      state.source = state.source.replace(/\s*$/, "") + header + text;
      toast(`Applied revision ${file.name}`);
    } else {
      state.source = text;
      state.sourceName = file.name;
      toast(`Loaded ${file.name}`);
    }
    $("#source-text").value = state.source;
    state.selection = null;
    saveDraft();
    run();
  }

  function pageWithGraph() {
    const safe = state.source.replace(/<\/script/gi, "<\\/script");
    const re = /(<script type="text\/x-cypher" id="graph-source" data-name=")([^"]*)(">)([\s\S]*?)(<\/script>)/;
    let page = pristinePage.replace(re, (_, a, _name, b, _body, c) => `${a}${esc(state.sourceName)}${b}${safe}${c}`);
    const rulesSafe = state.rulesText.replace(/<\/script/gi, "<\\/script");
    page = page.replace(/(<script type="application\/json" id="rules-profile">)([\s\S]*?)(<\/script>)/, (_, a, _b, c) => `${a}${rulesSafe}${c}`);
    // The copy describes the graph it carries: title, page metadata and the plain-text guide at
    // the top of the file (as tools/build.py writes them), all from that graph's Dataset node.
    const d = state.scene?.model?.dataset?.props || {};
    const title = String(d.name || state.sourceName);
    page = page.replace(/<title>[\s\S]*?<\/title>/, `<title>${esc(title)}</title>`);
    const meta = { "@context": "https://schema.org", "@type": "Dataset", name: title, encodingFormat: "text/x-cypher", description: String(d.description || title) };
    if (d.license) meta.license = String(d.license);
    if (d.issued) meta.datePublished = String(d.issued);
    page = page.replace(/<meta name="description" content="[^"]*">/, `<meta name="description" content="${esc(`${meta.description} Contains its openCypher knowledge graph as plain text (script#graph-source).`)}">`);
    page = page.replace(/(<script type="application\/ld\+json">)[\s\S]*?(<\/script>)/, (_, a, c) => `${a}${JSON.stringify(meta).replace(/<\//g, "<\\/")}${c}`);
    return page.replace(/^<!doctype html>\n/i, `<!doctype html>\n${pageGuide(state.source, title, d)}`);
  }

  /** The plain-text guide that opens a page file: what it holds and every licence that applies. */
  function pageGuide(source, title, d) {
    const labels = {};
    for (const m of source.matchAll(/^CREATE \(\w*:(\w+) \{/gm)) labels[m[1]] = (labels[m[1]] || 0) + 1;
    const nodes = Object.values(labels).reduce((a, b) => a + b, 0);
    const rels = [...source.matchAll(/^MATCH .* CREATE \(\w+\)-\[:/gm)].length;
    const lic = d.license ? `${licenceFullName(d.license)}${licenceFullName(d.license) === String(d.license) ? "" : `, ${d.license}`}` : "not stated in the graph";
    const paras = [
      title,
      "",
      'FOR AI AGENTS AND OTHER TOOLS: this file contains a complete openCypher knowledge graph (a labeled property graph) stored as plain text. It is the <script type="text/x-cypher" id="graph-source"> element near the end of the file, and it is the single source of everything this page draws. Read it directly rather than interpreting the drawing.',
      "",
      "To extract it, take the text between that opening tag and the next <\/script>; it is embedded verbatim, with no escaping. It is one openCypher statement per line: CREATE statements make the nodes, then MATCH ... CREATE statements add the relationships, matching their two ends by id. Lines starting with // are comments.",
      "",
      `It holds ${nodes} node statements and ${rels} relationship statements. Labels: ${Object.entries(labels).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k} (${v})`).join(", ")}.`,
      "",
      ...(/^CREATE \(\w*:Pin \{[^\n]*connector: '/m.test(source) ? ["Some links are properties rather than relationships: a Pin's connector property holds the id of its Connector.", ""] : []),
      'The graph describes itself: a Dataset node (DCAT) states what it covers and its license and rights, Method nodes (PROV) state how it was built, and a ConceptScheme of Term nodes (SKOS) defines every label, relationship type and property it uses, with mappings to KiCad, KBL (VDA 4964), VEC (VDA 4968) and other standards. The viewer\'s drawing rules are the JSON in <script id="rules-profile">, and the KiCad symbol libraries are the <script type="application/x-kicad-sym"> elements.',
      ...(d.description ? ["", `About the model: ${d.description}`] : []),
      "",
      "Licenses:",
      `- Knowledge graph (the graph-source element): ${lic}.`,
      "- Viewer software (the application and engine scripts, page markup and styles): Apache License 2.0, https://www.apache.org/licenses/LICENSE-2.0.",
      "- elkjs 0.12.0, Eclipse Layout Kernel (Kiel University and others, github.com/kieler/elkjs): EPL-2.0 OR GPL-3.0-or-later, used here under EPL-2.0.",
      "- KiCad symbol library (KiCad Library Team and contributors, github.com/KiCad/kicad-symbols), converted to .kicad_sym: CC-BY-SA-4.0 WITH KiCad-libraries-exception. Drawings made with the symbols are not bound by the share-alike terms.",
      "- IBM Plex Sans, Sans Condensed and Mono (IBM Corp.), latin subset: SIL Open Font License 1.1.",
      "",
      'The full texts of the Apache-2.0, EPL-2.0 and SIL OFL 1.1 licenses are the <script type="text/plain"> elements with ids license-apache-2.0, license-epl-2.0 and license-ofl-1.1 at the end of the file.',
      ...(d.rights ? ["", `Notice: ${d.rights}`] : []),
    ];
    const wrap = (text, first, rest) => {
      const out = []; let line = first;
      for (const w of String(text).split(/\s+/).filter(Boolean)) {
        if (line.length + w.length + 1 > 98 && line.trim() && line.trim() !== "-") { out.push(line.trimEnd()); line = rest; }
        line += w + " ";
      }
      out.push(line.trimEnd());
      return out.join("\n");
    };
    const body = paras.map((t) => (!t ? "" : t.startsWith("- ") ? wrap(t.slice(2), "  - ", "    ") : wrap(t, "  ", "  "))).join("\n");
    // A comment may not contain two hyphens in a row.
    return `<!--\n${body.replace(/-{2,}/g, (m) => "- ".repeat(m.length))}\n-->\n`;
  }

  /** A licence URL by its full name where it is a well-known one. */
  function licenceFullName(url) {
    const known = {
      "https://opendatacommons.org/licenses/by/1-0/": "Open Data Commons Attribution License 1.0 (ODC-By 1.0)",
      "https://opendatacommons.org/licenses/odbl/1-0/": "Open Data Commons Open Database License 1.0 (ODbL 1.0)",
      "https://opendatacommons.org/licenses/pddl/1-0/": "Open Data Commons Public Domain Dedication and License 1.0 (PDDL 1.0)",
      "https://creativecommons.org/licenses/by/4.0/": "Creative Commons Attribution 4.0 International (CC BY 4.0)",
      "https://creativecommons.org/licenses/by-sa/4.0/": "Creative Commons Attribution-ShareAlike 4.0 International (CC BY-SA 4.0)",
      "https://creativecommons.org/publicdomain/zero/1.0/": "CC0 1.0 Universal",
    };
    return known[String(url)] || String(url);
  }

  function standaloneSvg() {
    const clone = state.svg.cloneNode(true);
    clone.setAttribute("viewBox", clone.dataset.vb);
    clone.classList.remove("dimmed");
    const css = $("#schematic-style").textContent;
    const vars = getComputedStyle(document.documentElement);
    const tokens = [...$("#schematic-style").textContent.matchAll(/var\((--[a-z0-9-]+)\)/g)].map((m) => m[1]);
    const resolved = [...new Set(tokens)].map((t) => `${t}:${vars.getPropertyValue(t).trim()}`).join(";");
    const style = document.createElementNS("http://www.w3.org/2000/svg", "style");
    style.textContent = `svg{${resolved}}` + css;
    clone.insertBefore(style, clone.firstChild);
    return new XMLSerializer().serializeToString(clone);
  }

  async function copyText(text, message) {
    try { await navigator.clipboard.writeText(text); toast(message); }
    catch {
      const ta = $("#copy-fallback");
      ta.hidden = false;
      ta.value = text;
      ta.focus();
      ta.select();
      toast("Clipboard blocked here; the text is selected below. Press Ctrl+C or Cmd+C.", "warn");
    }
  }

  function renderIssues() {
    const diags = [...state.result.diagnostics, ...state.scene.notes,
      ...(state.pairFallbacks || []).map((fb) => ({ level: "error", message: `${fb.name}: this twisted pair could not be drawn twisted, so it shows as a plain bus line.` }))];
    if (state.ruleError) diags.unshift({ level: "error", message: `Rules JSON is not valid, so the embedded rules are in use: ${state.ruleError}` });
    const counts = { error: 0, warning: 0, info: 0 };
    diags.forEach((d) => counts[d.level]++);
    const findings = state.checks?.findings || [];
    for (const f of findings) counts[f.level]++;
    const badge = $("#issues-badge");
    badge.textContent = counts.error + counts.warning || "";
    badge.hidden = !(counts.error + counts.warning);
    badge.className = `badge ${counts.error ? "error" : "warn"}`;
    const graphPart = diags.length
      ? `<ul class="issues">${diags.map((d) => `<li class="issue ${d.level}"><span class="lvl">${d.level}</span><div>${d.line ? `<button class="link line-link" data-line="${d.line}">line ${d.line}</button> ` : ""}${esc(d.message)}</div></li>`).join("")}</ul>`
      : '<p class="muted small">No problems found in the graph.</p>';
    // Drawing checks: the drawing audited against the graph and KiCad's conventions.
    const summary = state.checks?.summary || [];
    const checkPart = `<ul class="checks">${summary.map((c) => `<li class="${c.errors ? "error" : c.warnings ? "warning" : "pass"}"><span class="mark" aria-hidden="true">${c.errors || c.warnings ? "!" : "✓"}</span><span>${esc(c.title)}</span>${c.errors + c.warnings ? `<span class="count">${c.errors + c.warnings}</span>` : ""}</li>`).join("")}</ul>
      ${findings.length ? `<ul class="issues">${findings.map((f, i) => `<li class="issue ${f.level}"><span class="lvl">${f.level}</span><div>${f.at ? `<button class="link finding-link" data-finding="${i}">show</button> ` : ""}${esc(f.message)}</div></li>`).join("")}</ul>` : ""}`;
    $("#pane-issues").innerHTML = `<p class="small muted">${counts.error} errors · ${counts.warning} warnings · ${counts.info} notes</p>
      <section><h3>Graph</h3>${graphPart}</section>
      <section><h3>Drawing checks</h3><p class="small muted">The drawing is audited against the graph and KiCad's conventions each time it is laid out.</p>${checkPart}</section>`;
    const errs = state.result.diagnostics.filter((d) => d.level === "error").length;
    $("#source-state").className = `state ${errs ? "error" : "ok"}`;
    renderDraftBanner();
    if (errs) $("#source-state").textContent += ` · ${errs} error${errs > 1 ? "s" : ""}`;
  }

  function renderStats() {
    const { result, layout, scene } = state;
    $("#doc-title").textContent = graphTitle();
    $("#stats").innerHTML = [
      `${result.graph.nodes.size} nodes`,
      `${result.graph.rels.size} rels`,
      `${layout.symbols.size} parts`,
      `${[...scene.nets.values()].filter((n) => n.connections.length).length} nets`,
      `rev ${hash(state.source)}`,
    ].map((s) => `<span class="stat">${esc(s)}</span>`).join("");
  }

  function renderSymbolsPane() {
    const libs = state.library.summary();
    const used = [...state.scene.symbols.values()].filter((s) => state.layout.symbols.has(s.id)).sort((a, b) => KGScene.compareNatural(a.ref || a.name, b.ref || b.name));
    $("#symbols-list").innerHTML = `
      <section><h3>In this drawing</h3><table class="used"><tbody>${used.map((s) => `<tr><td>${s.ref ? `<span class="refdes">${esc(s.ref)}</span> ` : ""}${esc(s.name)}</td><td>${s.kind === "lib" ? `<code>${esc(s.libId)}</code>` : '<span class="muted">generated box</span>'}</td></tr>`).join("")}</tbody></table></section>
      <section><h3>Loaded libraries</h3><ul class="libs">${libs.map((l) => `<li><strong>${esc(l.name)}</strong> <span class="count">${l.count}</span><div class="small muted">${esc(l.symbols.slice(0, 14).join(", "))}${l.count > 14 ? ", …" : ""}</div></li>`).join("")}</ul></section>`;
  }

  // ------------------------------------------------------------------ chrome

  function showTab(name) {
    $$(".tab").forEach((t) => t.setAttribute("aria-selected", String(t.dataset.tab === name)));
    $$(".pane").forEach((p) => { p.hidden = p.id !== `pane-${name}`; });
    store.set("kg-viewer:tab", name);
  }

  function setupTabs() {
    $$(".tab").forEach((t) => t.addEventListener("click", () => showTab(t.dataset.tab)));
    showTab("inspect");
  }

  function setupToggles() {
    const bind = (id, key, relayout, get = (el) => el.checked, set = (el, v) => { el.checked = !!v; }) => {
      const el = $(id);
      set(el, state.options[key]);
      el.addEventListener("change", () => {
        state.options[key] = get(el);
        store.set(optionsKey, JSON.stringify(state.options));
        run({ relayout });
      });
    };
    bind("#opt-physical", "physical", true);
    bind("#opt-unconnected", "showUnconnected", true);
    bind("#opt-netlabels", "netLabels", false);
    bind("#opt-wiretags", "wireTags", false);
    bind("#opt-pairs", "pairs", true);
    bind("#opt-colours", "wireColors", false, (el) => (el.checked ? "physical" : "kicad"), (el, v) => { el.checked = v === "physical"; });

    const search = $("#search");
    search.addEventListener("input", () => { if (state.mode === "tables") renderTables(); });
    search.addEventListener("keydown", (e) => {
      if (e.key !== "Enter" || state.mode === "tables") return;
      const q = search.value.trim().toLowerCase();
      if (!q) return;
      const syms = [...state.scene.symbols.values()].filter((s) => state.layout.symbols.has(s.id));
      const hitSym = syms.find((s) => s.ref && s.ref.toLowerCase() === q) || syms.find((s) => s.name.toLowerCase().includes(q) || s.key.toLowerCase().includes(q));
      if (hitSym) { inspect({ type: "symbol", id: hitSym.id }); focusOn({ id: hitSym.id }); return; }
      for (const s of syms) for (const c of s.contacts.values()) {
        if (c.visible && (c.name.toLowerCase() === q || (c.func || "").toLowerCase() === q || c.net.name.toLowerCase() === q)) { inspect({ type: "contact", sym: s.id, key: c.key }); focusOn({ id: s.id }); return; }
      }
      toast(`Nothing drawn matches "${search.value}"`, "warn");
    });
  }

  // ------------------------------------------------------------------ configurations

  // Choices marked primary (the profile's variants.tierKeys) sit in the toolbar; the rest open in
  // the Options dialog. A graph whose choices carry no tier shows, in the toolbar, those that
  // change something in the view.

  function variantTiers(points, rules) {
    const V = rules.variants || {};
    const tierOf = (pt) => { for (const k of V.tierKeys || []) if (pt.node.props[k] !== undefined && pt.node.props[k] !== null) return String(pt.node.props[k]); return null; };
    const tiered = points.some((pt) => tierOf(pt) !== null);
    const primary = tiered ? points.filter((pt) => tierOf(pt) === String(V.primaryTier || "primary")) : points;
    return { tiered, primary, secondary: tiered ? points.filter((pt) => !primary.includes(pt)) : [] };
  }

  /** Variant ids that something in the view depends on. */
  function usedVariants() {
    const used = new Set();
    for (const n of state.scene.graph.nodes.values()) for (const v of [].concat(n.props.variants || [])) used.add(String(v));
    for (const r of state.scene.graph.rels.values()) for (const v of [].concat(r.props.variants || [])) used.add(String(v));
    return used;
  }

  const pickHtml = (pt, selected, used) => `<label class="pick" title="${esc([pt.node.props.notes, used ? "" : "Changes nothing in this view."].filter(Boolean).join(" "))}"><span>${esc(pt.name)}</span><select data-point="${esc(pt.id)}">${pt.options.map((o) => `<option value="${esc(o.id)}"${o.id === selected ? " selected" : ""}>${esc(o.name)}${o.id === pt.default ? " (default)" : ""}</option>`).join("")}</select></label>`;

  function renderVariantPicks() {
    const host = $("#variant-picks");
    if (!host || !state.scene) return;
    const rules = parseRules() || JSON.parse(embedded.rules);
    const points = state.scene.variationPoints || [];
    const used = usedVariants();
    const affects = (pt) => pt.options.some((o) => used.has(String(o.id)));
    const { tiered, primary, secondary } = variantTiers(points, rules);
    const inline = tiered ? primary : points.filter(affects);
    host.hidden = !inline.length;
    host.innerHTML = inline.map((pt) => pickHtml(pt, pt.selected, affects(pt))).join("");
    const btn = $("#options-btn");
    btn.hidden = !secondary.length;
    const changed = secondary.filter((pt) => pt.selected !== pt.default).length;
    $("#options-sum").textContent = changed ? `${changed} changed` : "Defaults";
  }

  function chooseVariants(next) {
    state.options.variants = next;
    store.set(optionsKey, JSON.stringify(state.options));
    if (state.unit) { enterUnit(state.unit.key, state.unit.cls); return; }      // the unit's nets in the new configuration
    run({ relayout: true });
  }

  function setupVariantPicks() {
    $("#variant-picks").addEventListener("change", (e) => {
      const sel = e.target.closest("select[data-point]");
      if (!sel) return;
      chooseVariants({ ...(state.options.variants || {}), [sel.dataset.point]: sel.value });
    });
  }

  // ------------------------------------------------------------------ options dialog
  // Every secondary choice, filtered by name; changes apply together, so a large view is drawn once.

  let optionDraft = null;

  function renderOptionsList() {
    const rules = parseRules() || JSON.parse(embedded.rules);
    const { secondary } = variantTiers(state.scene.variationPoints || [], rules);
    const used = usedVariants();
    const q = $("#options-filter").value.trim().toLowerCase();
    const shown = secondary.filter((pt) => !q || pt.name.toLowerCase().includes(q) || pt.options.some((o) => o.name.toLowerCase().includes(q)));
    const idle = secondary.filter((pt) => !pt.options.some((o) => used.has(String(o.id)))).length;
    $("#options-note").textContent = `${secondary.length} choices${idle ? `; the ${idle} greyed change nothing in this view` : ""}. Changes apply together.`;
    $("#options-list").innerHTML = shown.map((pt) => {
      const sel = optionDraft[pt.id] && pt.options.some((o) => o.id === optionDraft[pt.id]) ? optionDraft[pt.id] : pt.default;
      const affects = pt.options.some((o) => used.has(String(o.id)));
      return `<div class="od-row${sel !== pt.default ? " changed" : ""}${affects ? "" : " idle"}"><div class="nm"><b>${esc(pt.name)}</b>${pt.node.props.notes ? `<small>${esc(pt.node.props.notes)}</small>` : ""}</div>
        <select data-point="${esc(pt.id)}" aria-label="${esc(pt.name)}">${pt.options.map((o) => `<option value="${esc(o.id)}"${o.id === sel ? " selected" : ""}>${esc(o.name)}${o.id === pt.default ? " (default)" : ""}</option>`).join("")}</select></div>`;
    }).join("") || '<p class="small muted">No option matches.</p>';
  }

  function setupOptions() {
    const dlg = $("#options-dialog");
    $("#options-btn").addEventListener("click", () => {
      if (!state.scene) return;
      optionDraft = { ...(state.options.variants || {}) };
      $("#options-filter").value = "";
      renderOptionsList();
      dlg.showModal();
    });
    $("#options-filter").addEventListener("input", () => renderOptionsList());
    $("#options-list").addEventListener("change", (e) => {
      const sel = e.target.closest("select[data-point]");
      if (!sel) return;
      optionDraft[sel.dataset.point] = sel.value;
      const pt = (state.scene.variationPoints || []).find((x) => x.id === sel.dataset.point);
      sel.closest(".od-row").classList.toggle("changed", !!pt && sel.value !== pt.default);
    });
    $("#options-reset").addEventListener("click", () => {
      const rules = parseRules() || JSON.parse(embedded.rules);
      for (const pt of variantTiers(state.scene.variationPoints || [], rules).secondary) delete optionDraft[pt.id];
      renderOptionsList();
    });
    $("#options-cancel").addEventListener("click", () => dlg.close());
    $("#options-apply").addEventListener("click", () => {
      dlg.close();
      const before = JSON.stringify(state.options.variants || {});
      if (JSON.stringify(optionDraft) !== before) chooseVariants(optionDraft);
    });
  }

  // ------------------------------------------------------------------ tables view

  // state.mode is the drawing/tables switch; state.view is the drawing's viewport.
  function setView(view) {
    state.mode = view === "tables" ? "tables" : "drawing";
    store.set("kg-viewer:view", state.mode);
    $$(".segmented [data-view]").forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.view === state.mode)));
    document.body.classList.toggle("view-tables", state.mode === "tables");
    $("#tables").hidden = state.mode !== "tables";
    $("#search").placeholder = state.mode === "tables" ? "Filter the tables" : "Find part, pin or net";
    renderTables();
  }

  const tableSort = new Map(); // table id -> { key, dir }

  function renderTables() {
    const host = $("#tables");
    if (!host || state.mode !== "tables" || !state.tables) return;
    const q = $("#search").value.trim().toLowerCase();
    const scrollTop = host.scrollTop;
    const sections = state.tables.map((t) => {
      const sort = tableSort.get(t.id);
      let rows = t.rows.map((r, i) => ({ r, i }));
      if (q) rows = rows.filter(({ r }) => Object.values(r.cells).some((v) => String(v).toLowerCase().includes(q)));
      if (sort) rows.sort((a, b) => sort.dir * KGScene.compareNatural(String(a.r.cells[sort.key] ?? ""), String(b.r.cells[sort.key] ?? "")));
      const head = t.columns.map((c) => `<th scope="col"><button type="button" class="th-sort" data-table="${esc(t.id)}" data-key="${esc(c.key)}" aria-sort="${sort?.key === c.key ? (sort.dir > 0 ? "ascending" : "descending") : "none"}">${esc(c.label)}${sort?.key === c.key ? (sort.dir > 0 ? " ▲" : " ▼") : ""}</button></th>`).join("");
      const body = rows.map(({ r, i }) => `<tr data-table="${esc(t.id)}" data-row="${i}" class="${r.ref ? "linked" : ""}${r.cells.kind === "internal" ? " internal" : ""}">${t.columns.map((c) => `<td class="c-${esc(c.key)}">${esc(r.cells[c.key] ?? "")}</td>`).join("")}</tr>`).join("");
      return `<section class="ref-table" id="table-${esc(t.id)}">
        <header><h2>${esc(t.title)} <span class="count">${rows.length}${rows.length !== t.rows.length ? ` of ${t.rows.length}` : ""}</span></h2>
          <button class="btn" type="button" data-csv="${esc(t.id)}">Copy CSV</button></header>
        <p class="small muted">${esc(t.note)}</p>
        <div class="table-wrap"><table><thead><tr>${head}</tr></thead><tbody>${body || `<tr><td colspan="${t.columns.length}" class="muted">No rows match.</td></tr>`}</tbody></table></div>
      </section>`;
    }).join("");
    const nav = state.tables.map((t) => `<a href="#table-${esc(t.id)}" class="chip-link">${esc(t.title)}</a>`).join("");
    const shown = (state.scene.variationPoints || []).map((pt) => pt.options.find((o) => o.id === pt.selected)?.name).filter(Boolean);
    const config = shown.length ? `<p class="small muted table-config">Configuration: ${shown.map(esc).join(" · ")}. Change it with the pickers above.</p>` : "";
    host.innerHTML = `<nav class="table-nav" aria-label="Tables">${nav}</nav>${config}${sections}`;
    host.scrollTop = scrollTop;
  }

  function setupTables() {
    $$(".segmented [data-view]").forEach((b) => b.addEventListener("click", () => setView(b.dataset.view)));
    const host = $("#tables");
    host.addEventListener("click", (e) => {
      const nav = e.target.closest(".table-nav a");
      if (nav) { e.preventDefault(); host.querySelector(nav.getAttribute("href"))?.scrollIntoView({ block: "start" }); return; }
      const th = e.target.closest(".th-sort");
      if (th) {
        const cur = tableSort.get(th.dataset.table);
        tableSort.set(th.dataset.table, { key: th.dataset.key, dir: cur?.key === th.dataset.key ? -cur.dir : 1 });
        renderTables();
        return;
      }
      const csv = e.target.closest("[data-csv]");
      if (csv) { copyText(KGTables.toCsv(state.tables.find((t) => t.id === csv.dataset.csv)), "Table copied as CSV"); return; }
      const tr = e.target.closest("tr[data-row]");
      if (!tr) return;
      const row = state.tables.find((t) => t.id === tr.dataset.table)?.rows[+tr.dataset.row];
      if (!row?.ref) return;
      $$("tr.picked", host).forEach((x) => x.classList.remove("picked"));
      tr.classList.add("picked");
      const ref = row.ref;
      if (ref.type === "contact" && state.layout.symbols.has(ref.sym)) inspect({ type: "contact", sym: ref.sym, key: ref.key });
      else if (ref.type === "connection") inspect({ type: "connection", id: ref.id });
      else inspect({ type: "node", id: ref.id });
      showTab("inspect");
    });
    setView(store.get("kg-viewer:view") || "drawing");
  }

  function setStatus(kind, text) {
    const el = $("#status");
    el.hidden = kind === "ok";
    el.className = `status ${kind}`;
    el.textContent = text;
  }

  let toastTimer = null;
  function toast(message, kind = "ok") {
    const el = $("#toast");
    el.textContent = message;
    el.className = `toast show ${kind}`;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { el.className = "toast"; }, kind === "error" ? 6000 : 3200);
  }

  // ------------------------------------------------------------------ boot

  async function boot() {
    setupTabs();
    setupCanvas();
    setupEditors();
    setupToggles();
    setupInspectorLinks();
    setupFocus();
    setupTables();
    setupVariantPicks();
    setupScope();
    setupOptions();
    setupUnitPick();
    state.library = buildLibrary();
    renderDraftBanner();
    try { await Promise.race([document.fonts.ready, new Promise((r) => setTimeout(r, 2500))]); } catch { /* fonts API missing */ }
    widthCache.clear();
    await run();
    const last = store.get("kg-viewer:tab");
    if (last && last !== "inspect" && $(`#pane-${last}`)) showTab(last);
  }

  window.KGViewer = { state, run, inspect, fit, setView, focus: enterFocus, unfocus: exitFocus };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
